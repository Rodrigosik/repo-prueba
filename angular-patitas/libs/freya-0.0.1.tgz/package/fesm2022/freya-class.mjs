import * as i0 from '@angular/core';
import { signal, computed, inject, effect, Directive } from '@angular/core';
import { Validators, NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
class FreyControlForm {
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) ?? false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isValid = computed(() => this.formControl()?.valid ?? true, ...(ngDevMode ? [{ debugName: "isValid" }] : []));
    isInvalid = computed(() => this.formControl()?.invalid ?? false, ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    isTouched = computed(() => this.formControl()?.touched ?? false, ...(ngDevMode ? [{ debugName: "isTouched" }] : []));
    errors = computed(() => this.formControl()?.errors ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : []));
    ngControl = inject(NgControl, { optional: true });
    subscription = new Subscription();
    constructor() {
        // Sincronizar el estado de disabled cuando cambie el control
        effect(() => {
            const ctrl = this.formControl();
            if (ctrl) {
                this.disabled.set(ctrl.disabled);
            }
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    ngAfterContentInit() {
        if (this.ngControl?.control) {
            const ctrl = this.ngControl.control;
            this.formControl.set(ctrl);
            this.subscription.add(
            // Suscribirse a cambios de estado del control
            ctrl.statusChanges?.subscribe(() => {
                // Forzar re-evaluación de computeds
                this.formControl.set(ctrl);
            }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyControlForm, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, decorators: [{
            type: Directive,
            args: [{}]
        }], ctorParameters: () => [] });

class FreyControlValueAccessor {
    writeValue(value) { }
    onChange = () => { };
    registerOnChange(fn) {
        this.onChange = fn;
    }
    onTouched = () => { };
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) { }
}

/**
 * Generated bundle index. Do not edit.
 */

export { FreyControlForm, FreyControlValueAccessor };
//# sourceMappingURL=freya-class.mjs.map
