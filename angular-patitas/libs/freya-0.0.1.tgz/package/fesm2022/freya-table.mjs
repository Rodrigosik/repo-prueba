import * as i0 from '@angular/core';
import { inject, TemplateRef, Directive, input, output, ElementRef, Renderer2, contentChild, contentChildren, model, computed, signal, effect, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';

/**
 * Directive to define a cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyCellDefDirective, isStandalone: true, selector: "[freyCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to add sorting functionality to table columns.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef freyColumnSort>
 *     <span>Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyColumnSortDirective {
    freyColumnSort = input(...(ngDevMode ? [undefined, { debugName: "freyColumnSort" }] : []));
    sortStatus = output();
    isArrowUp = false;
    elementRef = inject(ElementRef);
    renderer2 = inject(Renderer2);
    // private readonly cdr = inject(ChangeDetectorRef);
    ngAfterContentInit() {
        const iconSort = this.renderer2.createElement('span');
        const icon = this.renderer2.createText('▼');
        this.renderer2.setStyle(iconSort, 'font-size', '10px');
        this.renderer2.setStyle(iconSort, 'padding-left', ' 10px');
        this.renderer2.appendChild(iconSort, icon);
        this.renderer2.listen(this.elementRef.nativeElement, 'click', () => {
            this.isArrowUp = !this.isArrowUp;
            this.renderer2.setProperty(iconSort, 'textContent', this.getArrowText());
            // this.cdr.markForCheck();
        });
        this.renderer2.appendChild(this.elementRef.nativeElement, iconSort);
    }
    getArrowText() {
        this.sortStatus.emit(this.isArrowUp);
        return this.isArrowUp ? '▲' : '▼';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.1.2", type: FreyColumnSortDirective, isStandalone: true, selector: "[freyColumnSort]", inputs: { freyColumnSort: { classPropertyName: "freyColumnSort", publicName: "freyColumnSort", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sortStatus: "sortStatus" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnSort]',
                    standalone: true,
                }]
        }], propDecorators: { freyColumnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnSort", required: false }] }], sortStatus: [{ type: i0.Output, args: ["sortStatus"] }] } });

/**
 * Directive to define a header cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Column Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyHeaderCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyHeaderCellDefDirective, isStandalone: true, selector: "[freyHeaderCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyHeaderCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to define a column in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Name</span>
 *   </th>
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyColumnDefDirective {
    columnName = input(undefined, { ...(ngDevMode ? { debugName: "columnName" } : {}), alias: 'freyColumnDef' });
    headerCellDef = contentChild(FreyHeaderCellDefDirective, ...(ngDevMode ? [{ debugName: "headerCellDef" }] : []));
    cellDef = contentChild(FreyCellDefDirective, ...(ngDevMode ? [{ debugName: "cellDef" }] : []));
    sort = contentChild(FreyColumnSortDirective, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.1.2", type: FreyColumnDefDirective, isStandalone: true, selector: "[freyColumnDef]", inputs: { columnName: { classPropertyName: "columnName", publicName: "freyColumnDef", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "headerCellDef", first: true, predicate: FreyHeaderCellDefDirective, descendants: true, isSignal: true }, { propertyName: "cellDef", first: true, predicate: FreyCellDefDirective, descendants: true, isSignal: true }, { propertyName: "sort", first: true, predicate: FreyColumnSortDirective, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnDef]',
                    standalone: true,
                }]
        }], propDecorators: { columnName: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnDef", required: false }] }], headerCellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyHeaderCellDefDirective), { isSignal: true }] }], cellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyCellDefDirective), { isSignal: true }] }], sort: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyColumnSortDirective), { isSignal: true }] }] } });

/**
 * Freya Table Component - A flexible and lightweight data table.
 *
 * Styles are completely optional and must be imported separately.
 * To use the default styles, import:
 * @import 'freya/styles/table/table.scss';
 *
 * @example
 * ```html
 * <!-- Show 10 records per page -->
 * <frey-table [dataSource]="data" [itemsPerPage]="10">
 *   <ng-container freyColumnDef="name">
 *     <th *freyHeaderCellDef>
 *       <span>Name</span>
 *     </th>
 *     <td *freyCellDef="let row">
 *       <div>{{ row.name }}</div>
 *     </td>
 *   </ng-container>
 * </frey-table>
 *
 * <!-- Show all records (no pagination) -->
 * <frey-table [dataSource]="data" [itemsPerPage]="null">
 *   <!-- columns -->
 * </frey-table>
 * ```
 */
class FreyTableComponent {
    // Inputs (using model() for programmatic access)
    columnDefs = contentChildren(FreyColumnDefDirective, ...(ngDevMode ? [{ debugName: "columnDefs" }] : []));
    dataSource = model([], ...(ngDevMode ? [{ debugName: "dataSource" }] : []));
    searchTerm = model('', ...(ngDevMode ? [{ debugName: "searchTerm" }] : []));
    itemsPerPage = model(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    currentPage = model(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    selectable = model(false, ...(ngDevMode ? [{ debugName: "selectable" }] : []));
    // Outputs
    searchResults = output();
    clickRow = output();
    // Computed columns from column definitions
    columns = computed(() => this.columnDefs().map((colDef) => ({
        name: colDef.columnName(),
        headerCellDef: colDef.headerCellDef(),
        cellDef: colDef.cellDef(),
    })), ...(ngDevMode ? [{ debugName: "columns" }] : []));
    // Computed filtered data based on search term
    filteredDataBySearch = computed(() => {
        const data = this.dataSource();
        const search = this.searchTerm().trim().toLowerCase();
        if (!search) {
            return [...data];
        }
        return data.filter((row) => Object.keys(row).some((key) => row[key]?.toString().toLowerCase().includes(search)));
    }, ...(ngDevMode ? [{ debugName: "filteredDataBySearch" }] : []));
    // Computed paginated and sorted data
    paginatedData = computed(() => {
        const filtered = this.filteredDataBySearch();
        const sort = this.sortState();
        const sortedData = [...filtered];
        // Apply sorting if active
        if (sort) {
            sortedData.sort((a, b) => this.compareValues(a, b, sort.column, sort.direction));
        }
        // Apply pagination (if itemsPerPage is null, show all)
        const perPage = this.itemsPerPage();
        if (perPage === null) {
            return sortedData;
        }
        const page = this.currentPage();
        const startIndex = (page - 1) * perPage;
        const endIndex = startIndex + perPage;
        return sortedData.slice(startIndex, endIndex);
    }, ...(ngDevMode ? [{ debugName: "paginatedData" }] : []));
    // Selection state
    selectedRowIndex = signal(null, ...(ngDevMode ? [{ debugName: "selectedRowIndex" }] : []));
    selectedRow = signal(null, ...(ngDevMode ? [{ debugName: "selectedRow" }] : []));
    // Sort state
    sortState = signal(null, ...(ngDevMode ? [{ debugName: "sortState" }] : []));
    constructor() {
        // Effect to emit search results when filtered data changes
        effect(() => {
            const filtered = this.filteredDataBySearch();
            this.searchResults.emit(filtered.length);
        });
        // Effect to set up sort event listeners
        effect((onCleanup) => {
            const cols = this.columnDefs();
            const subscriptions = [];
            cols.forEach((colDef) => {
                const sortDirective = colDef.sort();
                if (sortDirective) {
                    const subscription = sortDirective.sortStatus.subscribe(() => {
                        this.onSort(colDef.columnName() ?? '');
                    });
                    subscriptions.push(subscription);
                }
            });
            onCleanup(() => {
                subscriptions.forEach((sub) => sub.unsubscribe());
            });
        });
    }
    selectRow(columnName, row, index) {
        if (!this.selectable()) {
            return;
        }
        if (this.selectedRow() === row) {
            this.selectedRowIndex.set(null);
            this.selectedRow.set(null);
            this.clickRow.emit(null);
            return;
        }
        this.selectedRowIndex.set(index);
        this.selectedRow.set(row);
        this.clickRow.emit({ name: columnName, data: row, rowIndex: index });
    }
    isRowSelected(row) {
        return this.selectedRow() === row;
    }
    onSort(column) {
        const currentSort = this.sortState();
        if (currentSort?.column === column) {
            this.sortState.set({
                column,
                direction: currentSort.direction === 'asc' ? 'desc' : 'asc',
            });
        }
        else {
            this.sortState.set({ column, direction: 'asc' });
        }
    }
    compareValues(a, b, column, direction) {
        const valueA = a[column];
        const valueB = b[column];
        if (typeof valueA === 'boolean' && typeof valueB === 'boolean') {
            return direction === 'asc'
                ? Number(valueA) - Number(valueB)
                : Number(valueB) - Number(valueA);
        }
        if (this.isNumeric(valueA) && this.isNumeric(valueB)) {
            return this.compareNumeric(valueA, valueB, direction);
        }
        return this.compareString((valueA ?? '').toString(), (valueB ?? '').toString(), direction);
    }
    compareNumeric(a, b, direction) {
        return direction === 'asc' ? a - b : b - a;
    }
    compareString(a, b, direction) {
        return a.localeCompare(b) * (direction === 'asc' ? 1 : -1);
    }
    isNumeric(value) {
        return typeof value === 'number' && !isNaN(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyTableComponent, isStandalone: true, selector: "frey-table", inputs: { dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, searchTerm: { classPropertyName: "searchTerm", publicName: "searchTerm", isSignal: true, isRequired: false, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dataSource: "dataSourceChange", searchTerm: "searchTermChange", itemsPerPage: "itemsPerPageChange", currentPage: "currentPageChange", selectable: "selectableChange", searchResults: "searchResults", clickRow: "clickRow" }, queries: [{ propertyName: "columnDefs", predicate: FreyColumnDefDirective, isSignal: true }], ngImport: i0, template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-table', standalone: true, imports: [NgTemplateOutlet], template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { columnDefs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => FreyColumnDefDirective), { isSignal: true }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }, { type: i0.Output, args: ["dataSourceChange"] }], searchTerm: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchTerm", required: false }] }, { type: i0.Output, args: ["searchTermChange"] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }, { type: i0.Output, args: ["itemsPerPageChange"] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }, { type: i0.Output, args: ["currentPageChange"] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }, { type: i0.Output, args: ["selectableChange"] }], searchResults: [{ type: i0.Output, args: ["searchResults"] }], clickRow: [{ type: i0.Output, args: ["clickRow"] }] } });

/**
 * Public API Surface of Freya Table
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyHeaderCellDefDirective, FreyTableComponent };
//# sourceMappingURL=freya-table.mjs.map
