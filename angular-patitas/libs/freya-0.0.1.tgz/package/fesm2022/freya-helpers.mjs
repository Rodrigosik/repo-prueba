import { firstValueFrom, timer } from 'rxjs';
import { map } from 'rxjs/operators';

const wait = (ms) => firstValueFrom(timer(ms).pipe(map(() => undefined)));
const getRequestAsync = async (request) => {
    try {
        const data = await firstValueFrom(request);
        return { status: true, data };
    }
    catch (error) {
        return { status: false, error };
    }
};

const isNullOrUndefined = (data) => {
    return data === null || data === undefined ? true : false || data === '';
};
const isDefined = (data) => {
    return data !== null && data !== undefined;
};

/**
 * Generated bundle index. Do not edit.
 */

export { getRequestAsync, isDefined, isNullOrUndefined, wait };
//# sourceMappingURL=freya-helpers.mjs.map
