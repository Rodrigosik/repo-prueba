import * as i0 from '@angular/core';
import { signal, computed, Injectable, inject, Component, Renderer2, ElementRef, HostListener, Input, ViewChild, EventEmitter, Output, Directive, NgModule } from '@angular/core';
import { isDefined, wait } from 'freya/helpers';
import { SubjectState, FreyControlValueAccessor } from 'freya/class';
import * as i1 from '@angular/common';
import { NgClass, AsyncPipe } from '@angular/common';
import { NgControl, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';

const getDaysOfTheWeek = (language = 'es-Es') => {
    const days = [];
    for (let i = 0; i < 7; i++) {
        const date = new Date(2023, 0, i + 1);
        const dayName = new Intl.DateTimeFormat(language, { weekday: 'long' }).format(date);
        days.push(dayName);
    }
    return days;
};
const getFirstLetterOfDays = (days) => {
    return days.map((day) => day.charAt(0).toLowerCase());
};
const getDaysInMonth = (date) => {
    const month = date.getMonth() + 1; // Mes (1-12)
    const year = date.getFullYear(); // Año
    return month === 2
        ? year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)
            ? 29
            : 28
        : [1, 3, 5, 7, 8, 10, 12].includes(month)
            ? 31
            : 30;
};
const addOrSubtractMonth = (date, months) => {
    const newDate = new Date(date);
    newDate.setMonth(newDate.getMonth() + months);
    return newDate;
};
const formatDateDDMMYYYY = (date) => {
    return date.toLocaleDateString('es-MX', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    });
};
const isValidDateDDMMYYYY = (dateString) => {
    // Validar formato exacto: dos dígitos / dos dígitos / cuatro dígitos
    const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = dateString.match(dateRegex);
    if (!match) {
        return false;
    }
    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const year = parseInt(match[3], 10);
    // Validación básica de rangos
    if (year < 1000 || year > 9999) {
        return false;
    }
    if (month < 1 || month > 12) {
        return false;
    }
    if (day < 1 || day > 31) {
        return false;
    }
    // Días por mes
    const daysInMonth = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (day > daysInMonth[month - 1]) {
        return false;
    }
    return true;
};
const isLeapYear = (year) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
};
const compareDates = (date1, date2, option) => {
    const formattedDate1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    const formattedDate2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
    if (option === 'lessOrEqual') {
        return formattedDate1 <= formattedDate2;
    }
    else if (option === 'greaterOrEqual') {
        return formattedDate1 >= formattedDate2;
    }
    else {
        throw new Error("Invalid option. Use 'lessOrEqual' or 'greaterOrEqual'.");
    }
};
const parseDateDDMMYYYY = (dateStr) => {
    const [day, month, year] = dateStr.split('/').map(Number);
    if (!day ||
        !month ||
        !year ||
        day < 1 ||
        day > 31 ||
        month < 1 ||
        month > 12 ||
        year < 1000 ||
        year > 9999) {
        return null;
    }
    const date = new Date(year, month - 1, day);
    // Verifica que la fecha generada coincide exactamente
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
        return null;
    }
    return date;
};
const generateDaysArray = (date) => {
    const daysInMonth = getDaysInMonth(date);
    const startDayIndex = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    const totalCells = 42;
    const daysArray = Array(totalCells).fill('');
    for (let day = 1; day <= daysInMonth; day++) {
        daysArray[startDayIndex + day - 1] = day.toString();
    }
    return daysArray;
};
const generateYearArray = (baseYear) => {
    const totalYears = 24;
    const fixedPosition = 9;
    const years = new Array(totalYears);
    for (let i = 0; i < fixedPosition; i++) {
        years[i] = baseYear - (fixedPosition - i);
    }
    years[fixedPosition] = baseYear;
    for (let i = fixedPosition + 1; i < totalYears; i++) {
        years[i] = baseYear + (i - fixedPosition);
    }
    return years;
};
const getMonthsArray = (locale, date) => {
    const monthsArray = [];
    for (let i = 0; i < 12; i++) {
        const monthName = new Intl.DateTimeFormat(locale, { month: 'long' }).format(new Date(date.getFullYear(), i, 1));
        monthsArray.push({ name: monthName.slice(0, 3), id: i });
    }
    return monthsArray;
};
const getShortMonthName = (locale, monthIndex) => {
    const date = new Date();
    date.setMonth(monthIndex);
    return new Intl.DateTimeFormat(locale, { month: 'long' }).format(date).slice(0, 3);
};
const formatRawDateInput = (value) => {
    const day = value.substring(0, 2);
    const month = value.substring(2, 4);
    const year = value.substring(4, 8);
    let formatted = '';
    if (day) {
        formatted += day;
    }
    if (month) {
        formatted += `/${month}`;
    }
    if (year) {
        formatted += `/${year}`;
    }
    return formatted;
};
const isValidDateInstance = (input) => {
    const date = new Date(input);
    return date instanceof Date && !isNaN(date.getTime());
};
const getSizeElementDisplayNone = (element) => {
    const clone = element.cloneNode(true);
    Object.assign(clone.style, {
        display: 'block',
        visibility: 'hidden',
        position: 'absolute',
        top: '-9999px',
    });
    document.body.appendChild(clone);
    const size = {
        width: clone.offsetWidth,
        height: clone.offsetHeight,
    };
    document.body.removeChild(clone);
    return size;
};

class MonthList {
    id = null;
    name = null;
}

class FreyDatePickerService {
    calendarChange$$ = new SubjectState();
    inputElement;
    inputElementControl;
    startView$$ = signal('multi-year', ...(ngDevMode ? [{ debugName: "startView$$" }] : []));
    statusCalendar$$ = signal('days', ...(ngDevMode ? [{ debugName: "statusCalendar$$" }] : []));
    calendarfilter;
    isOpen$$ = signal(false, ...(ngDevMode ? [{ debugName: "isOpen$$" }] : []));
    locale$$ = signal('es-ES', ...(ngDevMode ? [{ debugName: "locale$$" }] : []));
    minDate = null;
    maxDate = null;
    isDateValid = false;
    selectedDate$$ = signal(new Date(), ...(ngDevMode ? [{ debugName: "selectedDate$$" }] : []));
    selectedDay$$ = computed(() => {
        return this.selectedDate$$().getDate().toString();
    }, ...(ngDevMode ? [{ debugName: "selectedDay$$" }] : []));
    selectedMonth$$ = signal(new Date().getMonth(), ...(ngDevMode ? [{ debugName: "selectedMonth$$" }] : []));
    selectedYear$$ = computed(() => {
        return this.selectedDate$$().getFullYear();
    }, ...(ngDevMode ? [{ debugName: "selectedYear$$" }] : []));
    cacheSelectedDate = null;
    renderedDays$$ = signal([], ...(ngDevMode ? [{ debugName: "renderedDays$$" }] : []));
    renderedYears$$ = signal([], ...(ngDevMode ? [{ debugName: "renderedYears$$" }] : []));
    prevSelectedYear$$ = signal(null, ...(ngDevMode ? [{ debugName: "prevSelectedYear$$" }] : []));
    prevSelectedMonth$$ = signal(null, ...(ngDevMode ? [{ debugName: "prevSelectedMonth$$" }] : []));
    prevRenderedDays$$ = signal([], ...(ngDevMode ? [{ debugName: "prevRenderedDays$$" }] : []));
    prevRenderedYears$$ = signal([], ...(ngDevMode ? [{ debugName: "prevRenderedYears$$" }] : []));
    yearsToRender$$ = computed(() => {
        return this.prevRenderedYears$$()?.length ? this.prevRenderedYears$$() : this.renderedYears$$();
    }, ...(ngDevMode ? [{ debugName: "yearsToRender$$" }] : []));
    currentYear = new Date().getFullYear();
    currentMonth = new Date().getMonth();
    currentDay = new Date().getDate().toString();
    validSelectedDate() {
        if (this.selectedDate$$() === null || this.cacheSelectedDate === null) {
            return false;
        }
        if (formatDateDDMMYYYY(this.selectedDate$$()) !== formatDateDDMMYYYY(this.cacheSelectedDate)) {
            return false;
        }
        return true;
    }
    isInvalidMinMaxDate(date) {
        const adjustedMinDate = this.minDate ? new Date(this.minDate) : null;
        const adjustedMaxDate = this.maxDate ? new Date(this.maxDate) : null;
        return ((adjustedMinDate && date < adjustedMinDate) || (adjustedMaxDate && date > adjustedMaxDate));
    }
    initDate(startDate = new Date()) {
        this.renderedDays$$.set(generateDaysArray(startDate));
        this.renderedYears$$.set(generateYearArray(startDate.getFullYear()));
    }
    clearAuxData() {
        this.prevSelectedYear$$.set(null);
        this.prevSelectedMonth$$.set(null);
        this.prevRenderedDays$$.set([]);
        this.prevRenderedYears$$.set([]);
    }
    isValidDate(inputValue) {
        const formatDate = inputValue ? inputValue : formatDateDDMMYYYY(this.selectedDate$$());
        const dateAux = parseDateDDMMYYYY(formatDate);
        const isValidFormatDate = isValidDateDDMMYYYY(formatDate);
        const isValidFilter = this.calendarfilter ? !this.calendarfilter(dateAux) : true;
        const minDate = this.minDate ? compareDates(this.minDate, dateAux, 'lessOrEqual') : true;
        const maxDate = this.maxDate ? compareDates(this.maxDate, dateAux, 'greaterOrEqual') : true;
        this.isDateValid = isValidFormatDate && isValidFilter && minDate && maxDate;
    }
    generateDaysArray(date) {
        const daysInMonth = getDaysInMonth(date);
        const startDayIndex = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
        const totalCells = 42;
        const daysArray = Array(totalCells).fill('');
        for (let day = 1; day <= daysInMonth; day++) {
            daysArray[startDayIndex + day - 1] = day.toString();
        }
        return daysArray;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService, decorators: [{
            type: Injectable
        }] });

class DatepickerControlsComponent {
    prevSelectedMonthText$$ = computed(() => {
        const prevMonth = this.dateService.prevSelectedMonth$$();
        const locale = this.dateService.locale$$();
        return isDefined(prevMonth) ? getShortMonthName(locale, prevMonth) : null;
    }, ...(ngDevMode ? [{ debugName: "prevSelectedMonthText$$" }] : []));
    selectedMonthText$$ = computed(() => {
        const selectedMonth = this.dateService.selectedMonth$$();
        const locale = this.dateService.locale$$();
        return isDefined(selectedMonth) ? getShortMonthName(locale, selectedMonth) : null;
    }, ...(ngDevMode ? [{ debugName: "selectedMonthText$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    async configNavigate() {
        await wait(1);
        switch (this.dateService.statusCalendar$$()) {
            case 'days':
                this.dateService.statusCalendar$$.set('years');
                break;
            case 'months':
                this.dateService.statusCalendar$$.set('years');
                break;
            case 'years':
                this.dateService.statusCalendar$$.set('days');
                this.dateService.clearAuxData();
                this.dateService.initDate(this.dateService.selectedDate$$());
                break;
        }
    }
    previousOrNext(navigate) {
        if (this.dateService.statusCalendar$$() === 'days') {
            this.navigateForDays(navigate);
            return;
        }
        if (!this.dateService.prevSelectedYear$$()) {
            this.dateService.prevSelectedYear$$.set(this.dateService.selectedYear$$());
        }
        const nextOrPrev = navigate === 'next'
            ? this.dateService.prevSelectedYear$$() + 24
            : this.dateService.prevSelectedYear$$() - 24;
        this.dateService.prevRenderedYears$$.set(generateYearArray(nextOrPrev));
        this.dateService.prevSelectedYear$$.set(nextOrPrev);
    }
    navigateForDays(navigate) {
        if (!this.dateService.prevSelectedYear$$()) {
            this.dateService.prevSelectedYear$$.set(this.dateService.selectedYear$$());
            this.dateService.prevSelectedMonth$$.set(this.dateService.selectedDate$$().getMonth());
        }
        const monthId = this.dateService.prevSelectedMonth$$();
        let newMonth = navigate === 'next' ? monthId + 1 : monthId - 1;
        if (newMonth === -1 || newMonth === 12) {
            newMonth = newMonth === 12 ? 0 : 11;
            this.dateService.prevSelectedYear$$.update((year) => (year = navigate === 'next' ? year + 1 : year - 1));
        }
        const year = this.dateService.prevSelectedYear$$();
        const auxDate = new Date(year, newMonth, 1);
        this.dateService.prevRenderedDays$$.set(this.dateService.generateDaysArray(auxDate));
        this.dateService.prevSelectedMonth$$.set(newMonth);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerControlsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerControlsComponent, isStandalone: false, selector: "datepicker-controls", ngImport: i0, template: "<div class=\"calendar__controls\">\n  <button\n    [disabled]=\"dateService.startView$$() === 'multi-year'\"\n    class=\"calendar__years-button\"\n    (click)=\"configNavigate()\"\n  >\n    @switch (dateService.statusCalendar$$()) {\n      @case ('days') {\n        <span>\n          {{ prevSelectedMonthText$$() || selectedMonthText$$() }}\n          {{ dateService.prevSelectedYear$$() || dateService.selectedYear$$() }}\n        </span>\n      }\n      @case ('years') {\n        <span>\n          {{ dateService.yearsToRender$$()[0] }} - {{ dateService.yearsToRender$$()[23] }}\n        </span>\n      }\n      @default {\n        <span>{{ dateService.prevSelectedYear$$() }}</span>\n      }\n    }\n\n    <svg\n      class=\"calendar__arrow\"\n      [ngClass]=\"{ 'calendar__arrow--rotated': dateService.statusCalendar$$() !== 'days' }\"\n      viewBox=\"0 0 10 5\"\n      focusable=\"false\"\n      aria-hidden=\"true\"\n    >\n      <polygon points=\"0,0 5,5 10,0\"></polygon>\n    </svg>\n  </button>\n\n  @if (dateService.statusCalendar$$() !== 'months') {\n    <div class=\"calendar__control-body\">\n      <button class=\"calendar__control\" (click)=\"previousOrNext('prev')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z\" />\n        </svg>\n      </button>\n      <button class=\"calendar__control\" (click)=\"previousOrNext('next')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z\" />\n        </svg>\n      </button>\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerControlsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-controls', template: "<div class=\"calendar__controls\">\n  <button\n    [disabled]=\"dateService.startView$$() === 'multi-year'\"\n    class=\"calendar__years-button\"\n    (click)=\"configNavigate()\"\n  >\n    @switch (dateService.statusCalendar$$()) {\n      @case ('days') {\n        <span>\n          {{ prevSelectedMonthText$$() || selectedMonthText$$() }}\n          {{ dateService.prevSelectedYear$$() || dateService.selectedYear$$() }}\n        </span>\n      }\n      @case ('years') {\n        <span>\n          {{ dateService.yearsToRender$$()[0] }} - {{ dateService.yearsToRender$$()[23] }}\n        </span>\n      }\n      @default {\n        <span>{{ dateService.prevSelectedYear$$() }}</span>\n      }\n    }\n\n    <svg\n      class=\"calendar__arrow\"\n      [ngClass]=\"{ 'calendar__arrow--rotated': dateService.statusCalendar$$() !== 'days' }\"\n      viewBox=\"0 0 10 5\"\n      focusable=\"false\"\n      aria-hidden=\"true\"\n    >\n      <polygon points=\"0,0 5,5 10,0\"></polygon>\n    </svg>\n  </button>\n\n  @if (dateService.statusCalendar$$() !== 'months') {\n    <div class=\"calendar__control-body\">\n      <button class=\"calendar__control\" (click)=\"previousOrNext('prev')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z\" />\n        </svg>\n      </button>\n      <button class=\"calendar__control\" (click)=\"previousOrNext('next')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z\" />\n        </svg>\n      </button>\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderDaysComponent {
    weekDayLetters$$ = computed(() => getFirstLetterOfDays(getDaysOfTheWeek(this.dateService.locale$$())), ...(ngDevMode ? [{ debugName: "weekDayLetters$$" }] : []));
    daysToRendered$$ = computed(() => this.dateService.prevRenderedDays$$()?.length
        ? this.dateService.prevRenderedDays$$()
        : this.dateService.renderedDays$$(), ...(ngDevMode ? [{ debugName: "daysToRendered$$" }] : []));
    isSelectedDay$$ = computed(() => (day) => {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.selectedYear$$() === this.dateService.prevSelectedYear$$() &&
                this.dateService.prevSelectedMonth$$() === this.dateService.selectedMonth$$() &&
                day === this.dateService.selectedDay$$());
        }
        return day === this.dateService.selectedDay$$();
    }, ...(ngDevMode ? [{ debugName: "isSelectedDay$$" }] : []));
    isCurrentDay$$ = computed(() => (day) => {
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.prevSelectedYear$$() === this.dateService.currentYear &&
                this.dateService.prevSelectedMonth$$() === this.dateService.currentMonth &&
                day === this.dateService.currentDay);
        }
        return (this.dateService.currentDay == day &&
            this.dateService.currentMonth === this.dateService.selectedMonth$$() &&
            this.dateService.currentYear === this.dateService.selectedYear$$());
    }, ...(ngDevMode ? [{ debugName: "isCurrentDay$$" }] : []));
    isDisabledDay$$ = computed(() => (day) => {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        if (!day) {
            return false;
        }
        const year = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const month = this.dateService.prevSelectedMonth$$() ?? this.dateService.selectedDate$$().getMonth();
        const date = new Date(year, month, parseInt(String(day), 10));
        let isInvalidMinMax = false;
        let isInvalidFilter = false;
        if (this.dateService.minDate || this.dateService.maxDate) {
            isInvalidMinMax = this.dateService.isInvalidMinMaxDate(date);
        }
        if (this.dateService.calendarfilter) {
            isInvalidFilter = this.dateService.calendarfilter(date);
        }
        return isInvalidMinMax || isInvalidFilter;
    }, ...(ngDevMode ? [{ debugName: "isDisabledDay$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    onSelectedDay(day) {
        if (!day || this.isDisabledDay$$()(String(day))) {
            return;
        }
        const year = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const month = this.dateService.prevSelectedMonth$$() ?? this.dateService.selectedDate$$().getMonth();
        this.dateService.clearAuxData();
        this.dateService.selectedDate$$.set(new Date(year, month, parseInt(String(day), 10)));
        this.dateService.isValidDate();
        if (this.dateService.isDateValid) {
            this.dateService.inputElement.value = formatDateDDMMYYYY(this.dateService.selectedDate$$());
            this.dateService.cacheSelectedDate = new Date(year, month, parseInt(String(day), 10));
            this.dateService.calendarChange$$.update(this.dateService.cacheSelectedDate);
            this.dateService.initDate(this.dateService.cacheSelectedDate);
            this.dateService.isOpen$$.set(false);
            if (this.dateService.inputElementControl) {
                this.dateService.inputElementControl.setValue(this.dateService.selectedDate$$(), {
                    emitEvent: false,
                    emitModelToViewChange: false,
                });
            }
        }
        if (this.dateService.startView$$() === 'multi-year') {
            this.dateService.statusCalendar$$.set('years');
            return;
        }
        this.dateService.statusCalendar$$.set('days');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderDaysComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderDaysComponent, isStandalone: false, selector: "datepicker-render-days", ngImport: i0, template: "<div class=\"calendar__header\">\n  @for (dayWeek of weekDayLetters$$(); track $index) {\n    <div class=\"calendar__day-week\">{{ dayWeek }}</div>\n  }\n</div>\n<div class=\"calendar__days\">\n  @for (day of daysToRendered$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__day\"\n      [ngClass]=\"{\n        'calendar__day--isday': day !== '',\n        'calendar__day--selected': isSelectedDay$$()(day),\n        'calendar__day--current': isCurrentDay$$()(day),\n        'calendar__day--disabled': isDisabledDay$$()(day),\n      }\"\n      (click)=\"onSelectedDay(day)\"\n    >\n      {{ day }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderDaysComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-days', template: "<div class=\"calendar__header\">\n  @for (dayWeek of weekDayLetters$$(); track $index) {\n    <div class=\"calendar__day-week\">{{ dayWeek }}</div>\n  }\n</div>\n<div class=\"calendar__days\">\n  @for (day of daysToRendered$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__day\"\n      [ngClass]=\"{\n        'calendar__day--isday': day !== '',\n        'calendar__day--selected': isSelectedDay$$()(day),\n        'calendar__day--current': isCurrentDay$$()(day),\n        'calendar__day--disabled': isDisabledDay$$()(day),\n      }\"\n      (click)=\"onSelectedDay(day)\"\n    >\n      {{ day }}\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderMonthsComponent {
    renderedMonths$$ = computed(() => getMonthsArray(this.dateService.locale$$(), new Date()), ...(ngDevMode ? [{ debugName: "renderedMonths$$" }] : []));
    isSelectedMonth$$ = computed(() => (monthId) => {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.selectedYear$$() === this.dateService.prevSelectedYear$$() &&
                monthId === this.dateService.selectedMonth$$());
        }
        return monthId === this.dateService.selectedMonth$$();
    }, ...(ngDevMode ? [{ debugName: "isSelectedMonth$$" }] : []));
    isCurrentMonth$$ = computed(() => (monthId) => {
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.currentYear === this.dateService.prevSelectedYear$$() &&
                monthId === this.dateService.currentMonth);
        }
        return monthId === this.dateService.currentMonth;
    }, ...(ngDevMode ? [{ debugName: "isCurrentMonth$$" }] : []));
    isDisabledMonth$$ = computed(() => (month) => {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        return this.isValidMinMaxMonth(month);
    }, ...(ngDevMode ? [{ debugName: "isDisabledMonth$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    async onSelectedMonth(month) {
        if (this.isDisabledMonth$$()(month)) {
            return;
        }
        await wait(1);
        this.dateService.prevSelectedMonth$$.set(month.id);
        const auxDate = new Date(this.dateService.prevSelectedYear$$(), month.id, 1);
        this.dateService.prevRenderedDays$$.set(this.dateService.generateDaysArray(auxDate));
        this.dateService.statusCalendar$$.set('days');
    }
    isValidMinMaxMonth(month) {
        const minYear = this.dateService.minDate
            ? new Date(this.dateService.minDate).getFullYear()
            : null;
        const minMonth = this.dateService.minDate
            ? new Date(this.dateService.minDate).getMonth()
            : null;
        const maxYear = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getFullYear()
            : null;
        const maxMonth = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getMonth()
            : null;
        const selectedYear = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const selectedMonth = month.id;
        // Ambos definidos
        if (minYear !== null && minMonth !== null && maxYear !== null && maxMonth !== null) {
            if (selectedYear < minYear ||
                (selectedYear === minYear && selectedMonth < minMonth) ||
                selectedYear > maxYear ||
                (selectedYear === maxYear && selectedMonth > maxMonth)) {
                return true;
            }
            return false;
        }
        // Solo máximo definido
        if (maxYear !== null && maxMonth !== null) {
            if (selectedYear > maxYear || (selectedYear === maxYear && selectedMonth > maxMonth)) {
                return true;
            }
        }
        // Solo mínimo definido
        if (minYear !== null && minMonth !== null) {
            if (selectedYear < minYear || (selectedYear === minYear && selectedMonth < minMonth)) {
                return true;
            }
        }
        return false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderMonthsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderMonthsComponent, isStandalone: false, selector: "datepicker-render-months", ngImport: i0, template: "<div class=\"calendar__months\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  @for (month of renderedMonths$$(); track month.id; let index = $index) {\n    <div\n      class=\"calendar__month\"\n      [ngClass]=\"{\n        'calendar__month--selected': isSelectedMonth$$()(month.id),\n        'calendar__month--current': isCurrentMonth$$()(month.id),\n        'calendar__month--disabled': isDisabledMonth$$()(month),\n      }\"\n      (click)=\"onSelectedMonth(month)\"\n    >\n      {{ month.name }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderMonthsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-months', template: "<div class=\"calendar__months\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  @for (month of renderedMonths$$(); track month.id; let index = $index) {\n    <div\n      class=\"calendar__month\"\n      [ngClass]=\"{\n        'calendar__month--selected': isSelectedMonth$$()(month.id),\n        'calendar__month--current': isCurrentMonth$$()(month.id),\n        'calendar__month--disabled': isDisabledMonth$$()(month),\n      }\"\n      (click)=\"onSelectedMonth(month)\"\n    >\n      {{ month.name }}\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderYearsComponent {
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    isSelectedYear(year) {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        return this.dateService.selectedYear$$() === year;
    }
    isCurrentYear(year) {
        return this.dateService.currentYear === year;
    }
    isDisabledYear(year) {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        return this.isValidMinMaxYear(year);
    }
    async onSelectedYear(year) {
        if (this.isDisabledYear(year)) {
            return;
        }
        await wait(1);
        this.dateService.prevSelectedYear$$.set(year);
        this.dateService.statusCalendar$$.set('months');
    }
    isValidMinMaxYear(year) {
        const minDate = this.dateService.minDate
            ? new Date(this.dateService.minDate).getFullYear()
            : null;
        const maxDate = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getFullYear()
            : null;
        return (minDate && year < minDate) || (maxDate && year > maxDate);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderYearsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderYearsComponent, isStandalone: false, selector: "datepicker-render-years", ngImport: i0, template: "<div class=\"calendar__years\">\n  @for (year of dateService.yearsToRender$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__year\"\n      [ngClass]=\"{\n        'calendar__year--selected': isSelectedYear(year),\n        'calendar__year--current': isCurrentYear(year),\n        'calendar__year--disabled': isDisabledYear(year),\n      }\"\n      (click)=\"onSelectedYear(year)\"\n    >\n      {{ year }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderYearsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-years', template: "<div class=\"calendar__years\">\n  @for (year of dateService.yearsToRender$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__year\"\n      [ngClass]=\"{\n        'calendar__year--selected': isSelectedYear(year),\n        'calendar__year--current': isCurrentYear(year),\n        'calendar__year--disabled': isDisabledYear(year),\n      }\"\n      (click)=\"onSelectedYear(year)\"\n    >\n      {{ year }}\n    </div>\n  }\n</div>\n" }]
        }] });

class FreyDatepickerComponent {
    calendar;
    startView = 'multi-year';
    calendarfilter;
    positionY$$ = signal(0, ...(ngDevMode ? [{ debugName: "positionY$$" }] : []));
    positionX$$ = signal(0, ...(ngDevMode ? [{ debugName: "positionX$$" }] : []));
    positionCalendar$$ = computed(() => {
        return `top: ${this.positionY$$()}px; left: ${this.positionX$$()}px`;
    }, ...(ngDevMode ? [{ debugName: "positionCalendar$$" }] : []));
    isReadonly$$ = signal(false, ...(ngDevMode ? [{ debugName: "isReadonly$$" }] : []));
    dateService = inject(FreyDatePickerService);
    observer;
    removeClickListener;
    inputListener;
    keydownListener;
    renderer = inject(Renderer2);
    elementRef = inject(ElementRef);
    constructor() {
        this.dateService.startView$$.set(this.startView);
        this.dateService.initDate();
        this.removeClickListener = this.renderer.listen('document', 'click', (event) => this.onClick(event));
    }
    ngOnChanges(changes) {
        if (changes['startView']) {
            this.dateService.startView$$.set(this.startView);
        }
    }
    ngAfterViewInit() {
        this.dateService.calendarfilter = this.calendarfilter;
        this.inputListener = this.renderer.listen(this.dateService.inputElement, 'input', (event) => this.onInput(event));
        this.keydownListener = this.renderer.listen(this.dateService.inputElement, 'keydown', (event) => this.onKeyDown(event));
    }
    ngOnDestroy() {
        this.removeClickListener();
        if (this.observer) {
            this.observer.disconnect();
        }
        if (this.inputListener) {
            this.inputListener();
        }
        if (this.keydownListener) {
            this.keydownListener();
        }
    }
    async open() {
        if (this.isReadonly$$()) {
            return;
        }
        if (this.dateService.isOpen$$()) {
            return;
        }
        await wait(1);
        this.dateService.isOpen$$.update((counter) => (counter = !counter));
        this.setPositionCalendar();
    }
    async onWindowScroll() {
        if (!this.dateService.isOpen$$()) {
            return;
        }
        this.setPositionCalendar();
    }
    setTargetElement(input) {
        this.dateService.inputElement = input;
        this.dateService.minDate = isValidDateInstance(input.min) ? new Date(input.min) : null;
        this.dateService.maxDate = isValidDateInstance(input.max) ? new Date(input.max) : null;
        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes') {
                    if (mutation.attributeName === 'min') {
                        const min = this.dateService.inputElement.getAttribute('min');
                        if (isValidDateInstance(min)) {
                            this.dateService.minDate = new Date(min);
                        }
                        else {
                            this.dateService.minDate = null;
                        }
                    }
                    else if (mutation.attributeName === 'max') {
                        const max = this.dateService.inputElement.getAttribute('max');
                        if (isValidDateInstance(max)) {
                            this.dateService.maxDate = new Date(max);
                        }
                        else {
                            this.dateService.maxDate = null;
                        }
                    }
                }
            });
        });
        this.observer.observe(this.dateService.inputElement, {
            attributes: true,
        });
    }
    onClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.dateService.isOpen$$.set(false);
            this.dateService.clearAuxData();
            if (this.dateService.cacheSelectedDate) {
                this.dateService.initDate(this.dateService.cacheSelectedDate);
            }
            else {
                this.dateService.initDate();
            }
            if (this.dateService.startView$$() === 'multi-year') {
                this.dateService.statusCalendar$$.set('years');
                return;
            }
            this.dateService.statusCalendar$$.set('days');
            return;
        }
    }
    onInput(event) {
        const input = event.target;
        const originalPosition = input.selectionStart || 0;
        const rawValue = input.value.replace(/[^\d]/g, '');
        const formattedValue = formatRawDateInput(rawValue);
        const previousValue = input.value;
        const diff = formattedValue.length - previousValue.length;
        input.value = formattedValue;
        let newCursorPosition = originalPosition;
        if (diff > 0 && formattedValue[newCursorPosition - 1] === '/') {
            newCursorPosition += 1;
        }
        else if (diff < 0) {
            newCursorPosition -= 1;
        }
        newCursorPosition = Math.max(0, Math.min(newCursorPosition, formattedValue.length));
        input.setSelectionRange(newCursorPosition, newCursorPosition);
        if (input.value.length === 0) {
            this.resetControlValue();
            this.dateService.clearAuxData();
            this.dateService.cacheSelectedDate = null;
            this.dateService.calendarChange$$.update(null);
        }
        if (input.value.length === 10) {
            this.dateService.isValidDate(input.value);
            if (this.dateService.isDateValid) {
                this.dateService.calendarChange$$.update(parseDateDDMMYYYY(input.value));
                if (this.dateService.inputElementControl) {
                    this.dateService.inputElementControl.setValue(parseDateDDMMYYYY(input.value), {
                        emitEvent: false,
                        emitModelToViewChange: false,
                    });
                }
                this.dateService.selectedDate$$.set(parseDateDDMMYYYY(input.value));
                this.dateService.cacheSelectedDate = parseDateDDMMYYYY(input.value);
                this.dateService.initDate(this.dateService.selectedDate$$());
            }
            else {
                this.resetControlValue();
            }
        }
        else {
            this.resetControlValue();
        }
    }
    onKeyDown(event) {
        const allowedKeys = ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'];
        if (!/\d/.test(event.key) && !allowedKeys.includes(event.key)) {
            event.preventDefault();
        }
    }
    resetControlValue() {
        if (this.dateService.inputElementControl) {
            this.dateService.inputElementControl.setValue(null, {
                emitEvent: false,
                emitModelToViewChange: false,
            });
            this.dateService.inputElementControl.setErrors({
                error: 'La fecha es inválida',
            });
            this.dateService.inputElementControl.markAsTouched();
        }
    }
    async setPositionCalendar() {
        const elementInputHost = this.dateService.inputElement;
        const inputElement = elementInputHost.getBoundingClientRect();
        const { height } = getSizeElementDisplayNone(this.calendar.nativeElement);
        this.positionY$$.set(inputElement.top + inputElement.height + 5);
        this.positionX$$.set(inputElement.left);
        await wait(1);
        const calendarRect = this.calendar.nativeElement.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const isFullyVisible = calendarRect.top >= 0 && calendarRect.bottom <= viewportHeight;
        if (!isFullyVisible) {
            const inputHeight = this.dateService.inputElement.getBoundingClientRect().height;
            this.positionY$$.set(inputElement.top - height - inputHeight);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyDatepickerComponent, isStandalone: false, selector: "frey-datepicker", inputs: { startView: "startView", calendarfilter: "calendarfilter" }, host: { listeners: { "window:scroll": "onWindowScroll()" } }, providers: [FreyDatePickerService], viewQueries: [{ propertyName: "calendar", first: true, predicate: ["calendar"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  #calendar\n  class=\"calendar\"\n  [style]=\"positionCalendar$$()\"\n  [ngClass]=\"{ 'calendar--active': dateService.isOpen$$() }\"\n>\n  <datepicker-controls></datepicker-controls>\n\n  @switch (dateService.statusCalendar$$()) {\n    @case ('days') {\n      <datepicker-render-days></datepicker-render-days>\n    }\n\n    @case ('years') {\n      <datepicker-render-years></datepicker-render-years>\n    }\n    @default {\n      <datepicker-render-months></datepicker-render-months>\n    }\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: DatepickerRenderDaysComponent, selector: "datepicker-render-days" }, { kind: "component", type: DatepickerRenderMonthsComponent, selector: "datepicker-render-months" }, { kind: "component", type: DatepickerRenderYearsComponent, selector: "datepicker-render-years" }, { kind: "component", type: DatepickerControlsComponent, selector: "datepicker-controls" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-datepicker', providers: [FreyDatePickerService], template: "<div\n  #calendar\n  class=\"calendar\"\n  [style]=\"positionCalendar$$()\"\n  [ngClass]=\"{ 'calendar--active': dateService.isOpen$$() }\"\n>\n  <datepicker-controls></datepicker-controls>\n\n  @switch (dateService.statusCalendar$$()) {\n    @case ('days') {\n      <datepicker-render-days></datepicker-render-days>\n    }\n\n    @case ('years') {\n      <datepicker-render-years></datepicker-render-years>\n    }\n    @default {\n      <datepicker-render-months></datepicker-render-months>\n    }\n  }\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { calendar: [{
                type: ViewChild,
                args: ['calendar']
            }], startView: [{
                type: Input
            }], calendarfilter: [{
                type: Input
            }], onWindowScroll: [{
                type: HostListener,
                args: ['window:scroll', []]
            }] } });

class FreyDatepickerInputDirective extends FreyControlValueAccessor {
    locale = 'es-ES';
    picker;
    calendarChange = new EventEmitter();
    ngControl = inject(NgControl, { self: true, optional: true });
    elementRef = inject(ElementRef);
    calendarControlAux = new FormControl(null);
    subscription = new Subscription();
    get calendarControl() {
        return this.ngControl?.control || this.calendarControlAux;
    }
    get isReadonly() {
        return (this.elementRef.nativeElement.hasAttribute('readonly') ||
            this.elementRef.nativeElement.readOnly === true);
    }
    constructor() {
        super();
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(changes) {
        if (changes['locale'] && this.picker) {
            this.picker.dateService.locale$$.set(this.locale);
        }
    }
    ngAfterViewInit() {
        if (this.picker) {
            this.picker['setTargetElement'](this.elementRef.nativeElement);
            this.subscription.add(this.picker.dateService.calendarChange$$.$observable.subscribe((response) => {
                this.calendarChange.emit(response);
            }));
            if (this.isReadonly) {
                this.picker.isReadonly$$.set(true);
            }
        }
        else {
            console.error('El componente datepicker no se encuentra.');
        }
        if (this.calendarControl) {
            this.picker.dateService.inputElementControl = this.calendarControl;
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    writeValue(value) {
        if (!value) {
            this.elementRef.nativeElement.value = '';
            return;
        }
        if (value instanceof Date && !isNaN(value.getTime())) {
            this.elementRef.nativeElement.value = formatDateDDMMYYYY(value);
            const dateService = this.picker.dateService;
            if (this.picker) {
                dateService.selectedDate$$.set(new Date(value));
                dateService.cacheSelectedDate = new Date(value);
                dateService.initDate(dateService.selectedDate$$());
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    onBlur(event) {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerInputDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyDatepickerInputDirective, isStandalone: false, selector: "[freyDatepicker]", inputs: { locale: "locale", picker: ["freyDatepicker", "picker"] }, outputs: { calendarChange: "calendarChange" }, host: { listeners: { "blur": "onBlur($event)" } }, usesInheritance: true, usesOnChanges: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerInputDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyDatepicker]',
                }]
        }], ctorParameters: () => [], propDecorators: { locale: [{
                type: Input
            }], picker: [{
                type: Input,
                args: ['freyDatepicker']
            }], calendarChange: [{
                type: Output
            }], onBlur: [{
                type: HostListener,
                args: ['blur', ['$event']]
            }] } });

const COMPONENTS = [
    FreyDatepickerComponent,
    DatepickerRenderDaysComponent,
    DatepickerRenderMonthsComponent,
    DatepickerRenderYearsComponent,
    DatepickerControlsComponent,
];
const DIRECTIVES = [FreyDatepickerInputDirective];
class FreyDatepickerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, declarations: [FreyDatepickerComponent,
            DatepickerRenderDaysComponent,
            DatepickerRenderMonthsComponent,
            DatepickerRenderYearsComponent,
            DatepickerControlsComponent, FreyDatepickerInputDirective], imports: [NgClass, AsyncPipe], exports: [FreyDatepickerComponent, FreyDatepickerInputDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NgClass, AsyncPipe],
                    declarations: [COMPONENTS, DIRECTIVES],
                    exports: [FreyDatepickerComponent, DIRECTIVES],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyDatepickerComponent, FreyDatepickerInputDirective, FreyDatepickerModule };
//# sourceMappingURL=freya-datepicker.mjs.map
