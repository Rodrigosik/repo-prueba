import * as i1 from '@angular/common';
import { NgStyle, NgTemplateOutlet } from '@angular/common';
import * as i0 from '@angular/core';
import { EventEmitter, inject, Renderer2, ElementRef, Output, ViewChild, Component, ApplicationRef, RendererFactory2, createComponent, Injectable, NgModule } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscription, Subject, delay, take } from 'rxjs';

class FreyAlertModel {
    showConfirmButton = true;
    textConfirmButton = 'Aceptar';
    showCancelButton = true;
    textCancelButton = 'Cancelar';
    title = null;
    description = null;
    template = null;
    innerHTML = null;
    zIndex = 99999;
    typeHeader = 'success';
    colorButtonConfirm = null;
}

class AlertComponent {
    confirmButton;
    cancelButton;
    closeMeEvent = new EventEmitter();
    confirmEvent = new EventEmitter();
    data = new FreyAlertModel();
    renderer2 = inject(Renderer2);
    elementRef = inject(ElementRef);
    sanitizer = inject(DomSanitizer);
    ngAfterViewInit() {
        this.renderer2.setStyle(this.elementRef.nativeElement, 'z-index', this.data.zIndex);
    }
    closeMe() {
        this.closeMeEvent.emit();
    }
    confirm() {
        this.confirmEvent.emit();
    }
    innerHtmlSanitized() {
        return this.sanitizer.bypassSecurityTrustHtml(this.data.innerHTML);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: AlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: AlertComponent, isStandalone: false, selector: "frey-alert", outputs: { closeMeEvent: "closeMeEvent", confirmEvent: "confirmEvent" }, viewQueries: [{ propertyName: "confirmButton", first: true, predicate: ["confirmButton"], descendants: true }, { propertyName: "cancelButton", first: true, predicate: ["cancelButton"], descendants: true }], ngImport: i0, template: "<div\n  class=\"alert\"\n  [class.alert--success]=\"data.typeHeader === 'success'\"\n  [class.alert--error]=\"data.typeHeader === 'error'\"\n  [class.alert--warning]=\"data.typeHeader === 'warning'\"\n  [class.alert--info]=\"data.typeHeader === 'info'\"\n  [class.alert--question]=\"data.typeHeader === 'question'\"\n>\n  @if (data.typeHeader !== 'none') {\n    <div class=\"alert__header\">\n      <div class=\"alert__icon-container\">\n        <i class=\"ms-filled alert__icon\">\n          @switch (data.typeHeader) {\n            @case ('success') {\n              check_small\n            }\n            @case ('error') {\n              close_small\n            }\n            @case ('warning') {\n              exclamation\n            }\n            @case ('info') {\n              info\n            }\n            @case ('question') {\n              help\n            }\n          }\n        </i>\n      </div>\n    </div>\n  }\n\n  @if (data?.title || data?.description) {\n    <div class=\"alert__body\">\n      @if (data?.title) {\n        <h1 class=\"frey-alert__title\">{{ data.title }}</h1>\n      }\n\n      @if (data?.description) {\n        <p class=\"frey-alert__description\">\n          {{ data.description }}\n        </p>\n      }\n    </div>\n  }\n\n  @if (data?.template) {\n    <div class=\"alert__template\">\n      <ng-container [ngTemplateOutlet]=\"data?.template\"></ng-container>\n    </div>\n  }\n\n  @if (data?.innerHTML) {\n    <div class=\"alert__bodyInnerHTML\">\n      <div class=\"alert__innerHTML\" [innerHTML]=\"innerHtmlSanitized()\"></div>\n    </div>\n  }\n\n  <div class=\"alert__bottom\">\n    <!-- //TODO -->\n    @if (data?.showCancelButton) {\n      <button class=\"alert__button\" (click)=\"closeMe()\" #cancelButton>\n        {{ data?.textCancelButton }}\n      </button>\n    }\n    <!-- TODO -->\n    @if (data?.showConfirmButton) {\n      <button class=\"alert__button alert__button--confirm\" (click)=\"confirm()\" #confirmButton>\n        {{ data?.textConfirmButton }}\n      </button>\n    }\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: AlertComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-alert', template: "<div\n  class=\"alert\"\n  [class.alert--success]=\"data.typeHeader === 'success'\"\n  [class.alert--error]=\"data.typeHeader === 'error'\"\n  [class.alert--warning]=\"data.typeHeader === 'warning'\"\n  [class.alert--info]=\"data.typeHeader === 'info'\"\n  [class.alert--question]=\"data.typeHeader === 'question'\"\n>\n  @if (data.typeHeader !== 'none') {\n    <div class=\"alert__header\">\n      <div class=\"alert__icon-container\">\n        <i class=\"ms-filled alert__icon\">\n          @switch (data.typeHeader) {\n            @case ('success') {\n              check_small\n            }\n            @case ('error') {\n              close_small\n            }\n            @case ('warning') {\n              exclamation\n            }\n            @case ('info') {\n              info\n            }\n            @case ('question') {\n              help\n            }\n          }\n        </i>\n      </div>\n    </div>\n  }\n\n  @if (data?.title || data?.description) {\n    <div class=\"alert__body\">\n      @if (data?.title) {\n        <h1 class=\"frey-alert__title\">{{ data.title }}</h1>\n      }\n\n      @if (data?.description) {\n        <p class=\"frey-alert__description\">\n          {{ data.description }}\n        </p>\n      }\n    </div>\n  }\n\n  @if (data?.template) {\n    <div class=\"alert__template\">\n      <ng-container [ngTemplateOutlet]=\"data?.template\"></ng-container>\n    </div>\n  }\n\n  @if (data?.innerHTML) {\n    <div class=\"alert__bodyInnerHTML\">\n      <div class=\"alert__innerHTML\" [innerHTML]=\"innerHtmlSanitized()\"></div>\n    </div>\n  }\n\n  <div class=\"alert__bottom\">\n    <!-- //TODO -->\n    @if (data?.showCancelButton) {\n      <button class=\"alert__button\" (click)=\"closeMe()\" #cancelButton>\n        {{ data?.textCancelButton }}\n      </button>\n    }\n    <!-- TODO -->\n    @if (data?.showConfirmButton) {\n      <button class=\"alert__button alert__button--confirm\" (click)=\"confirm()\" #confirmButton>\n        {{ data?.textConfirmButton }}\n      </button>\n    }\n  </div>\n</div>\n" }]
        }], propDecorators: { confirmButton: [{
                type: ViewChild,
                args: ['confirmButton', { static: false }]
            }], cancelButton: [{
                type: ViewChild,
                args: ['cancelButton', { static: false }]
            }], closeMeEvent: [{
                type: Output
            }], confirmEvent: [{
                type: Output
            }] } });

class ModalProps {
    modalComponent = null;
    eventsSubscription = new Subscription();
    eventList = ['closeEvent', 'confirmEvent'];
    alertSubscription = new Subject();
}
class FreyAlertService {
    totalModals = 0;
    currentAlert = null;
    renderer2;
    applicationRef = inject(ApplicationRef);
    rendererFactory = inject(RendererFactory2);
    constructor() {
        this.renderer2 = this.rendererFactory.createRenderer(null, null);
    }
    openAlert(config) {
        if (this.totalModals === 0) {
            this.renderer2.setStyle(document.body, 'overflow', 'hidden');
        }
        this.totalModals++;
        const modalProps = this.buildModal();
        this.currentAlert = modalProps;
        this.buildEventsToModal(config, modalProps);
        return modalProps.alertSubscription.asObservable().pipe(delay(1), take(1));
    }
    closeCurrentAlert() {
        this.closeModal(false, this.currentAlert);
    }
    buildModal() {
        const modalProps = new ModalProps();
        modalProps.modalComponent = createComponent(AlertComponent, {
            environmentInjector: this.applicationRef.injector,
        });
        this.applicationRef.attachView(modalProps.modalComponent.hostView);
        const componentDom = modalProps.modalComponent.hostView.rootNodes[0];
        this.renderer2.appendChild(document.body, componentDom);
        return modalProps;
    }
    buildEventsToModal(config, modalProps) {
        modalProps.modalComponent.instance.data = config;
        modalProps.eventsSubscription.add(modalProps.modalComponent.instance.closeMeEvent.subscribe(() => this.closeModal(false, modalProps)));
        modalProps.eventsSubscription.add(modalProps.modalComponent.instance.confirmEvent.subscribe(() => this.closeModal(true, modalProps)));
    }
    closeModal(value, modalProps) {
        modalProps.alertSubscription.next(value);
        modalProps.alertSubscription.complete();
        modalProps.eventsSubscription.unsubscribe();
        modalProps.modalComponent.destroy();
        this.totalModals--;
        if (this.totalModals === 0) {
            this.renderer2.removeStyle(document.body, 'overflow');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

const COMPONENTS = [AlertComponent];
const SERVICES = [FreyAlertService];
class FreyAlertModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertModule, declarations: [AlertComponent], imports: [NgStyle, NgTemplateOutlet] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertModule, providers: [SERVICES] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyAlertModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [COMPONENTS],
                    providers: [SERVICES],
                    imports: [NgStyle, NgTemplateOutlet],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyAlertModel, FreyAlertModule, FreyAlertService };
//# sourceMappingURL=freya-alert.mjs.map
