import * as i0 from '@angular/core';
import { input, inject, ElementRef, Renderer2, HostListener, Directive } from '@angular/core';

class FreyTooltipDirective {
    freyTooltip = input('', ...(ngDevMode ? [{ debugName: "freyTooltip" }] : []));
    tooltipPosition = input('top', ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : []));
    tooltipElement = null;
    elementRef = inject(ElementRef);
    renderer = inject(Renderer2);
    ngOnDestroy() {
        this.hideTooltip();
    }
    onMouseEnter() {
        this.showTooltip();
    }
    onMouseLeave() {
        this.hideTooltip();
    }
    showTooltip() {
        if (!this.freyTooltip() || this.tooltipElement) {
            return;
        }
        this.createTooltipElement();
        this.positionTooltip();
        this.renderer.addClass(this.tooltipElement, 'frey-tooltip-show');
    }
    hideTooltip() {
        if (this.tooltipElement) {
            this.renderer.removeClass(this.tooltipElement, 'frey-tooltip-show');
            if (this.tooltipElement) {
                this.renderer.removeChild(document.body, this.tooltipElement);
                this.tooltipElement = null;
            }
        }
    }
    createTooltipElement() {
        this.tooltipElement = this.renderer.createElement('div');
        this.renderer.addClass(this.tooltipElement, 'frey-tooltip');
        const textNode = this.renderer.createText(this.freyTooltip());
        this.renderer.appendChild(this.tooltipElement, textNode);
        this.renderer.setStyle(this.tooltipElement, 'position', 'absolute');
        this.renderer.setStyle(this.tooltipElement, 'z-index', '100000');
        this.renderer.setStyle(this.tooltipElement, 'opacity', '0');
        this.renderer.setStyle(this.tooltipElement, 'pointer-events', 'none');
        this.renderer.appendChild(document.body, this.tooltipElement);
    }
    positionTooltip() {
        if (!this.tooltipElement) {
            return;
        }
        const hostRect = this.elementRef.nativeElement.getBoundingClientRect();
        const tooltipRect = this.tooltipElement.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        // Obtener el scroll actual de la página
        const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
        const scrollY = window.pageYOffset || document.documentElement.scrollTop;
        let position = this.tooltipPosition();
        // Si es auto, calcular la mejor posición
        if (position === 'auto') {
            position = this.calculateBestPosition(hostRect, tooltipRect, viewportWidth, viewportHeight);
        }
        const coords = this.calculatePosition(position, hostRect, tooltipRect);
        // Ajustar las coordenadas con el scroll de la página
        const adjustedCoords = {
            x: coords.x + scrollX,
            y: coords.y + scrollY,
        };
        // Verificar si la posición calculada se sale de la pantalla y ajustar si es necesario
        if (this.tooltipPosition() === 'auto') {
            const finalCoords = this.adjustPositionIfNeeded(adjustedCoords, tooltipRect);
            this.renderer.setStyle(this.tooltipElement, 'left', `${finalCoords.x}px`);
            this.renderer.setStyle(this.tooltipElement, 'top', `${finalCoords.y}px`);
        }
        else {
            this.renderer.setStyle(this.tooltipElement, 'left', `${adjustedCoords.x}px`);
            this.renderer.setStyle(this.tooltipElement, 'top', `${adjustedCoords.y}px`);
        }
        this.renderer.addClass(this.tooltipElement, `frey-tooltip-${position}`);
    }
    calculateBestPosition(hostRect, tooltipRect, viewportWidth, viewportHeight) {
        const spaceTop = hostRect.top;
        const spaceBottom = viewportHeight - hostRect.bottom;
        const spaceLeft = hostRect.left;
        const spaceRight = viewportWidth - hostRect.right;
        const tooltipWidth = tooltipRect.width;
        const tooltipHeight = tooltipRect.height;
        // Prioridad: bottom > top > right > left
        if (spaceBottom >= tooltipHeight + 10) {
            return 'bottom';
        }
        else if (spaceTop >= tooltipHeight + 10) {
            return 'top';
        }
        else if (spaceRight >= tooltipWidth + 10) {
            return 'right';
        }
        else if (spaceLeft >= tooltipWidth + 10) {
            return 'left';
        }
        // Si no cabe en ningún lado, usar la posición con más espacio
        const maxSpace = Math.max(spaceTop, spaceBottom, spaceLeft, spaceRight);
        if (maxSpace === spaceBottom) {
            return 'bottom';
        }
        if (maxSpace === spaceTop) {
            return 'top';
        }
        if (maxSpace === spaceRight) {
            return 'right';
        }
        return 'left';
    }
    calculatePosition(position, hostRect, tooltipRect) {
        const offset = 8;
        let x, y;
        switch (position) {
            case 'top':
                x = hostRect.left + hostRect.width / 2 - tooltipRect.width / 2;
                y = hostRect.top - tooltipRect.height - offset;
                break;
            case 'bottom':
                x = hostRect.left + hostRect.width / 2 - tooltipRect.width / 2;
                y = hostRect.bottom + offset;
                break;
            case 'left':
                x = hostRect.left - tooltipRect.width - offset;
                y = hostRect.top + hostRect.height / 2 - tooltipRect.height / 2;
                break;
            case 'right':
                x = hostRect.right + offset;
                y = hostRect.top + hostRect.height / 2 - tooltipRect.height / 2;
                break;
            default:
                x = hostRect.left + hostRect.width / 2 - tooltipRect.width / 2;
                y = hostRect.bottom + offset;
        }
        return { x, y };
    }
    adjustPositionIfNeeded(coords, tooltipRect) {
        let { x, y } = coords;
        const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
        const scrollY = window.pageYOffset || document.documentElement.scrollTop;
        // Ajustar horizontalmente considerando el scroll
        const minX = scrollX + 10;
        const maxX = scrollX + window.innerWidth - tooltipRect.width - 10;
        if (x < minX) {
            x = minX;
        }
        else if (x > maxX) {
            x = maxX;
        }
        // Ajustar verticalmente considerando el scroll
        const minY = scrollY + 10;
        const maxY = scrollY + window.innerHeight - tooltipRect.height - 10;
        if (y < minY) {
            y = minY;
        }
        else if (y > maxY) {
            y = maxY;
        }
        return { x, y };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.1.2", type: FreyTooltipDirective, isStandalone: true, selector: "[freyTooltip]", inputs: { freyTooltip: { classPropertyName: "freyTooltip", publicName: "freyTooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "mouseenter": "onMouseEnter()", "mouseleave": "onMouseLeave()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyTooltip]',
                }]
        }], propDecorators: { freyTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyTooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyTooltipDirective };
//# sourceMappingURL=freya-tooltip.mjs.map
