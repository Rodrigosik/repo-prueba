import * as i0 from '@angular/core';
import { Component, Directive, input, contentChild, signal, computed, viewChild, output, inject, ElementRef, contentChildren, Injector, effect, forwardRef, HostListener, NgModule } from '@angular/core';
import { Validators, NgControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { FreyControlForm, FreyControlValueAccessor } from 'freya/class';
import * as i1 from '@angular/common';
import { NgClass } from '@angular/common';

class FreyErrorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyErrorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyErrorComponent, isStandalone: false, selector: "frey-error", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyErrorComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-error',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreyInputDirective extends FreyControlForm {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyInputDirective, isStandalone: false, selector: "[freyInput]", usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyInput]',
                }]
        }] });

class FreyTextareaDirective extends FreyControlForm {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTextareaDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyTextareaDirective, isStandalone: false, selector: "[freyTextarea]", usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTextareaDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyTextarea]',
                }]
        }] });

class FreyFieldComponent {
    requiredText = input('Campo requerido', ...(ngDevMode ? [{ debugName: "requiredText" }] : []));
    freyInput = contentChild(FreyInputDirective, ...(ngDevMode ? [{ debugName: "freyInput" }] : []));
    freyTextarea = contentChild(FreyTextareaDirective, ...(ngDevMode ? [{ debugName: "freyTextarea" }] : []));
    freySelect = contentChild(FreyFieldComponent, ...(ngDevMode ? [{ debugName: "freySelect" }] : []));
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isDisabled = computed(() => {
        return this.formControl()?.disabled;
    }, ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    ngAfterContentInit() {
        if (this.freyInput()) {
            this.formControl.set(this.freyInput()?.formControl());
            return;
        }
        if (this.freyTextarea()) {
            this.formControl.set(this.freyTextarea()?.formControl());
            return;
        }
        // if (this.jumSelect) {
        //   this.formControl$$ = signal(this.jumSelect.formControl);
        //   this.disableFromHTML$$ = this.jumSelect.disabled;
        // }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyFieldComponent, isStandalone: false, selector: "frey-field", inputs: { requiredText: { classPropertyName: "requiredText", publicName: "requiredText", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "freyInput", first: true, predicate: FreyInputDirective, descendants: true, isSignal: true }, { propertyName: "freyTextarea", first: true, predicate: FreyTextareaDirective, descendants: true, isSignal: true }, { propertyName: "freySelect", first: true, predicate: FreyFieldComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<section class=\"frey-field\">\n  <div class=\"frey-field__header\">\n    <ng-content select=\"frey-label\"></ng-content>\n    @if (isRequired()) {\n      <span class=\"frey-field__required\"> *</span>\n    }\n  </div>\n\n  <div class=\"frey-field__body\">\n    <div class=\"frey-field__control\">\n      <ng-content select=\"frey-prefix\"></ng-content>\n      <ng-content select=\"[freyInput], [freyTextarea], frey-select\"></ng-content>\n      <ng-content select=\"frey-suffix\"></ng-content>\n    </div>\n    <div class=\"frey-field__footer\">\n      <ng-content select=\"frey-hint\"></ng-content>\n\n      @if (\n        formControl() && formControl().invalid && (formControl().dirty || formControl().touched)\n      ) {\n        @if (formControl().errors?.required) {\n          <frey-error>{{ requiredText() }}</frey-error>\n        } @else {\n          <ng-content select=\"frey-error\"></ng-content>\n        }\n      }\n\n      @if (formControl() && formControl().valid) {\n        <ng-content select=\"frey-success\"></ng-content>\n      }\n    </div>\n  </div>\n</section>\n", dependencies: [{ kind: "component", type: FreyErrorComponent, selector: "frey-error" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-field', template: "<section class=\"frey-field\">\n  <div class=\"frey-field__header\">\n    <ng-content select=\"frey-label\"></ng-content>\n    @if (isRequired()) {\n      <span class=\"frey-field__required\"> *</span>\n    }\n  </div>\n\n  <div class=\"frey-field__body\">\n    <div class=\"frey-field__control\">\n      <ng-content select=\"frey-prefix\"></ng-content>\n      <ng-content select=\"[freyInput], [freyTextarea], frey-select\"></ng-content>\n      <ng-content select=\"frey-suffix\"></ng-content>\n    </div>\n    <div class=\"frey-field__footer\">\n      <ng-content select=\"frey-hint\"></ng-content>\n\n      @if (\n        formControl() && formControl().invalid && (formControl().dirty || formControl().touched)\n      ) {\n        @if (formControl().errors?.required) {\n          <frey-error>{{ requiredText() }}</frey-error>\n        } @else {\n          <ng-content select=\"frey-error\"></ng-content>\n        }\n      }\n\n      @if (formControl() && formControl().valid) {\n        <ng-content select=\"frey-success\"></ng-content>\n      }\n    </div>\n  </div>\n</section>\n" }]
        }], propDecorators: { requiredText: [{ type: i0.Input, args: [{ isSignal: true, alias: "requiredText", required: false }] }], freyInput: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyInputDirective), { isSignal: true }] }], freyTextarea: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyTextareaDirective), { isSignal: true }] }], freySelect: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyFieldComponent), { isSignal: true }] }] } });

class FreyHintComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHintComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyHintComponent, isStandalone: false, selector: "frey-hint", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHintComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-hint',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreyLabelComponent {
    labelText = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyLabelComponent, isStandalone: false, selector: "frey-label", host: { attributes: { "title": "labelText" } }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLabelComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-label',
                    template: `<ng-content></ng-content>`,
                    host: {
                        title: 'labelText',
                    },
                }]
        }] });

class FreyOptionComponent {
    description = viewChild('description', ...(ngDevMode ? [{ debugName: "description" }] : []));
    clickOption = output();
    value = input(...(ngDevMode ? [undefined, { debugName: "value" }] : []));
    isDisabled = input(false, ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    isSelected = signal(false, ...(ngDevMode ? [{ debugName: "isSelected" }] : []));
    isVisible = signal(true, ...(ngDevMode ? [{ debugName: "isVisible" }] : []));
    elementRef = inject(ElementRef);
    onClickOption() {
        if (this.isDisabled()) {
            return;
        }
        this.clickOption.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyOptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyOptionComponent, isStandalone: false, selector: "frey-option", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, isDisabled: { classPropertyName: "isDisabled", publicName: "isDisabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clickOption: "clickOption" }, viewQueries: [{ propertyName: "description", first: true, predicate: ["description"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"option\"\n  [ngClass]=\"{ 'option--hidden': !isVisible(), 'option--disabled': isDisabled() }\"\n  (click)=\"onClickOption()\"\n>\n  <div class=\"option__description\">\n    <span class=\"option__text\" #description><ng-content></ng-content></span>\n  </div>\n  @if (isSelected()) {\n    <svg\n      class=\"option__selected\"\n      aria-label=\"Seleccionado\"\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      focusable=\"false\"\n    >\n      <polyline\n        points=\"6.5,11 9,13.5 14,8.5\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyOptionComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-option', template: "<div\n  class=\"option\"\n  [ngClass]=\"{ 'option--hidden': !isVisible(), 'option--disabled': isDisabled() }\"\n  (click)=\"onClickOption()\"\n>\n  <div class=\"option__description\">\n    <span class=\"option__text\" #description><ng-content></ng-content></span>\n  </div>\n  @if (isSelected()) {\n    <svg\n      class=\"option__selected\"\n      aria-label=\"Seleccionado\"\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      focusable=\"false\"\n    >\n      <polyline\n        points=\"6.5,11 9,13.5 14,8.5\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  }\n</div>\n" }]
        }], propDecorators: { description: [{ type: i0.ViewChild, args: ['description', { isSignal: true }] }], clickOption: [{ type: i0.Output, args: ["clickOption"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], isDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isDisabled", required: false }] }] } });

class FreyPrefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPrefix, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyPrefix, isStandalone: false, selector: "frey-prefix", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPrefix, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-prefix',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreySelectComponent extends FreyControlValueAccessor {
    freyOptions = contentChildren(FreyOptionComponent, ...(ngDevMode ? [{ debugName: "freyOptions" }] : []));
    searchInput = viewChild('searchInput', ...(ngDevMode ? [{ debugName: "searchInput" }] : []));
    searchInputBackend = viewChild('searchInputBackend', ...(ngDevMode ? [{ debugName: "searchInputBackend" }] : []));
    typeSearch = input('none', ...(ngDevMode ? [{ debugName: "typeSearch" }] : []));
    backendSearchDebounceMs = input(1000, ...(ngDevMode ? [{ debugName: "backendSearchDebounceMs" }] : []));
    readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    placeholder = input('Seleccione una opción', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    selectionChange = output();
    backendSearchQuery = output();
    currentText = signal(null, ...(ngDevMode ? [{ debugName: "currentText" }] : []));
    currentValue = signal(null, ...(ngDevMode ? [{ debugName: "currentValue" }] : []));
    isSelectOpen = signal(false, ...(ngDevMode ? [{ debugName: "isSelectOpen" }] : []));
    searchBackendValue = signal('', ...(ngDevMode ? [{ debugName: "searchBackendValue" }] : []));
    formControl;
    debouncedBackendSearchQuery = signal('', ...(ngDevMode ? [{ debugName: "debouncedBackendSearchQuery" }] : []));
    lastEmittedBackendSearchQuery = '';
    injector = inject(Injector);
    elementRef = inject(ElementRef);
    constructor() {
        super();
        this.subscribeToOptionClicks();
        this.setupBackendSearch();
    }
    ngAfterContentInit() {
        const ngControl = this.injector.get(NgControl, null);
        if (ngControl?.control) {
            this.formControl = ngControl.control;
        }
    }
    selected() {
        if (this.disabled() || this.readonly()) {
            return;
        }
        this.isSelectOpen.set(!this.isSelectOpen());
        if (this.isSelectOpen()) {
            this.setPositionScroll();
        }
        if (this.isSelectOpen() && this.typeSearch() === 'frontend') {
            setTimeout(() => {
                this.searchInput().nativeElement.focus();
            }, 0);
        }
        else if (this.isSelectOpen() && this.typeSearch() === 'backend') {
            setTimeout(() => {
                this.searchInputBackend().nativeElement.focus();
            }, 0);
        }
    }
    onTouchedFn() {
        if (this.readonly()) {
            return;
        }
        this.onTouched();
    }
    writeValue(value) {
        this.currentValue.set(value);
        if (this.isNullOrUndefined(value)) {
            this.currentText.set(null);
            return;
        }
        if (this.freyOptions?.length) {
            this.setSelectedOption();
        }
    }
    onSearch() {
        const cleanedSearchTerm = this.normalizeText(this.searchInput().nativeElement.value.trim());
        this.freyOptions().forEach((option) => {
            const optionText = this.normalizeText(option?.description()?.nativeElement?.textContent || '');
            if (!optionText.includes(cleanedSearchTerm)) {
                option.isVisible.set(false);
            }
            else {
                option.isVisible.set(true);
            }
        });
        if (!cleanedSearchTerm) {
            this.setPositionScroll();
        }
    }
    onClearValues() {
        if (this.readonly()) {
            return;
        }
        this.resetOptions();
        this.isSelectOpen.set(false);
        this.currentText.set(null);
        this.currentValue.set(null);
        this.onChange(null);
        this.selectionChange.emit(null);
    }
    isNullOrUndefined(data) {
        return data === null || data === undefined ? true : false || data === '';
    }
    onClick(targetElement) {
        const clickedInside = this.elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.isSelectOpen.set(false);
        }
    }
    setPositionScroll() {
        const value = this.freyOptions().find((option) => this.currentValue() === option.value());
        if (value) {
            setTimeout(() => {
                value['elementRef'].nativeElement.scrollIntoView({
                    behavior: 'instant',
                    block: 'nearest',
                });
            }, 0);
        }
    }
    setupBackendSearch() {
        effect((onCleanup) => {
            const value = this.searchBackendValue();
            const timeout = setTimeout(() => {
                if (value !== this.lastEmittedBackendSearchQuery) {
                    this.lastEmittedBackendSearchQuery = value;
                    this.debouncedBackendSearchQuery.set(value);
                }
            }, this.backendSearchDebounceMs());
            onCleanup(() => clearTimeout(timeout));
        });
        effect(() => {
            if (this.typeSearch() === 'none') {
                return;
            }
            const value = this.debouncedBackendSearchQuery();
            this.backendSearchQuery.emit(value);
        });
    }
    subscribeToOptionClicks() {
        effect((onCleanup) => {
            const subs = this.freyOptions().map((option) => option.clickOption.subscribe(() => {
                this.optionClicked(option);
            }));
            if (this.currentValue() !== null) {
                this.setSelectedOption();
            }
            onCleanup(() => {
                subs.forEach((sub) => sub.unsubscribe());
            });
        });
    }
    optionClicked(option) {
        if (this.disabled()) {
            return;
        }
        this.resetOptions();
        this.isSelectOpen.set(false);
        this.currentText.set(option.description()?.nativeElement.innerText);
        this.currentValue.set(option.value());
        option.isSelected.set(true);
        this.onChange(option.value());
        this.selectionChange.emit(option.value());
        if (this.typeSearch() === 'frontend' && this.searchInput) {
            this.searchInput().nativeElement.value = null;
        }
    }
    setSelectedOption() {
        const selectedOption = this.freyOptions().find((option) => option.value() === this.currentValue());
        if (selectedOption) {
            this.optionClicked(selectedOption);
        }
    }
    resetOptions() {
        if (this.freyOptions()) {
            this.freyOptions().forEach((option) => {
                option.isSelected.set(false);
                option.isVisible.set(true);
            });
        }
    }
    normalizeText(text) {
        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreySelectComponent, isStandalone: false, selector: "frey-select", inputs: { typeSearch: { classPropertyName: "typeSearch", publicName: "typeSearch", isSignal: true, isRequired: false, transformFunction: null }, backendSearchDebounceMs: { classPropertyName: "backendSearchDebounceMs", publicName: "backendSearchDebounceMs", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", backendSearchQuery: "backendSearchQuery" }, host: { listeners: { "document:click": "onClick($event.target)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreySelectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "freyOptions", predicate: FreyOptionComponent, isSignal: true }], viewQueries: [{ propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }, { propertyName: "searchInputBackend", first: true, predicate: ["searchInputBackend"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"select\"\n  [ngClass]=\"{\n    'select--active': isSelectOpen(),\n    'select--readonly': readonly(),\n  }\"\n  (click)=\"onTouchedFn()\"\n  (keydown)=\"onTouchedFn()\"\n  [title]=\"currentText() || ''\"\n>\n  <div class=\"select__header\" (click)=\"selected()\" (keydown)=\"selected()\">\n    @if (isNullOrUndefined(currentValue())) {\n      <span class=\"select__placeholder\">{{ placeholder() }}</span>\n      <svg\n        class=\"select__arrow\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        focusable=\"false\"\n        (click)=\"onClearValues()\"\n      >\n        <polyline\n          points=\"6 8 10 12 14 8\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          fill=\"none\"\n        />\n      </svg>\n    } @else {\n      <span class=\"select__value\">{{ currentText() }}</span>\n      @if (!readonly()) {\n        <svg\n          (click)=\"onClearValues()\"\n          class=\"select__clear\"\n          aria-label=\"Limpiar selecci\u00F3n\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <line\n            x1=\"6\"\n            y1=\"6\"\n            x2=\"14\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n          <line\n            x1=\"14\"\n            y1=\"6\"\n            x2=\"6\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n    }\n  </div>\n\n  <div class=\"select__options\">\n    @if (typeSearch() === 'frontend') {\n      <input type=\"text\" class=\"select__search\" (input)=\"onSearch()\" #searchInput />\n    }\n    @if (typeSearch() === 'backend') {\n      <div class=\"select__search-container\">\n        <svg\n          class=\"select__search-icon\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <!-- Database shape -->\n          <ellipse\n            cx=\"10\"\n            cy=\"6\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <path\n            d=\"M4 6v6c0 1.66 2.69 3 6 3s6-1.34 6-3V6\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <ellipse\n            cx=\"10\"\n            cy=\"12\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <!-- Magnifier glass -->\n          <circle cx=\"15.5\" cy=\"15.5\" r=\"2\" stroke=\"currentColor\" stroke-width=\"1.5\" fill=\"none\" />\n          <line\n            x1=\"17\"\n            y1=\"17\"\n            x2=\"18.5\"\n            y2=\"18.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n        <input\n          type=\"text\"\n          class=\"select__search--backend\"\n          #searchInputBackend\n          placeholder=\"Escriba un t\u00E9rmino para consultar.\"\n          (input)=\"searchBackendValue.set($any($event.target).value)\"\n        />\n      </div>\n    }\n    <ng-content select=\"frey-option\"></ng-content>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-select', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreySelectComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"select\"\n  [ngClass]=\"{\n    'select--active': isSelectOpen(),\n    'select--readonly': readonly(),\n  }\"\n  (click)=\"onTouchedFn()\"\n  (keydown)=\"onTouchedFn()\"\n  [title]=\"currentText() || ''\"\n>\n  <div class=\"select__header\" (click)=\"selected()\" (keydown)=\"selected()\">\n    @if (isNullOrUndefined(currentValue())) {\n      <span class=\"select__placeholder\">{{ placeholder() }}</span>\n      <svg\n        class=\"select__arrow\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        focusable=\"false\"\n        (click)=\"onClearValues()\"\n      >\n        <polyline\n          points=\"6 8 10 12 14 8\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          fill=\"none\"\n        />\n      </svg>\n    } @else {\n      <span class=\"select__value\">{{ currentText() }}</span>\n      @if (!readonly()) {\n        <svg\n          (click)=\"onClearValues()\"\n          class=\"select__clear\"\n          aria-label=\"Limpiar selecci\u00F3n\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <line\n            x1=\"6\"\n            y1=\"6\"\n            x2=\"14\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n          <line\n            x1=\"14\"\n            y1=\"6\"\n            x2=\"6\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n    }\n  </div>\n\n  <div class=\"select__options\">\n    @if (typeSearch() === 'frontend') {\n      <input type=\"text\" class=\"select__search\" (input)=\"onSearch()\" #searchInput />\n    }\n    @if (typeSearch() === 'backend') {\n      <div class=\"select__search-container\">\n        <svg\n          class=\"select__search-icon\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <!-- Database shape -->\n          <ellipse\n            cx=\"10\"\n            cy=\"6\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <path\n            d=\"M4 6v6c0 1.66 2.69 3 6 3s6-1.34 6-3V6\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <ellipse\n            cx=\"10\"\n            cy=\"12\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <!-- Magnifier glass -->\n          <circle cx=\"15.5\" cy=\"15.5\" r=\"2\" stroke=\"currentColor\" stroke-width=\"1.5\" fill=\"none\" />\n          <line\n            x1=\"17\"\n            y1=\"17\"\n            x2=\"18.5\"\n            y2=\"18.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n        <input\n          type=\"text\"\n          class=\"select__search--backend\"\n          #searchInputBackend\n          placeholder=\"Escriba un t\u00E9rmino para consultar.\"\n          (input)=\"searchBackendValue.set($any($event.target).value)\"\n        />\n      </div>\n    }\n    <ng-content select=\"frey-option\"></ng-content>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { freyOptions: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => FreyOptionComponent), { isSignal: true }] }], searchInput: [{ type: i0.ViewChild, args: ['searchInput', { isSignal: true }] }], searchInputBackend: [{ type: i0.ViewChild, args: ['searchInputBackend', { isSignal: true }] }], typeSearch: [{ type: i0.Input, args: [{ isSignal: true, alias: "typeSearch", required: false }] }], backendSearchDebounceMs: [{ type: i0.Input, args: [{ isSignal: true, alias: "backendSearchDebounceMs", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], backendSearchQuery: [{ type: i0.Output, args: ["backendSearchQuery"] }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event.target']]
            }] } });

class FreySuccessComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuccessComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreySuccessComponent, isStandalone: false, selector: "frey-success", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuccessComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-success',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreySuffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuffix, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreySuffix, isStandalone: false, selector: "frey-suffix", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuffix, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-suffix',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

const COMPONENTS = [
    FreyErrorComponent,
    FreyFieldComponent,
    FreyHintComponent,
    FreyLabelComponent,
    FreyPrefix,
    FreySuccessComponent,
    FreySuffix,
    FreyOptionComponent,
    FreySelectComponent,
];
const DIRECTIVES = [FreyInputDirective, FreyTextareaDirective];
class FreyFormModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, declarations: [FreyErrorComponent,
            FreyFieldComponent,
            FreyHintComponent,
            FreyLabelComponent,
            FreyPrefix,
            FreySuccessComponent,
            FreySuffix,
            FreyOptionComponent,
            FreySelectComponent, FreyInputDirective, FreyTextareaDirective], imports: [NgClass], exports: [FreyErrorComponent,
            FreyFieldComponent,
            FreyHintComponent,
            FreyLabelComponent,
            FreyPrefix,
            FreySuccessComponent,
            FreySuffix,
            FreyOptionComponent,
            FreySelectComponent, FreyInputDirective, FreyTextareaDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NgClass],
                    declarations: [COMPONENTS, DIRECTIVES],
                    exports: [COMPONENTS, DIRECTIVES],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyErrorComponent, FreyFieldComponent, FreyFormModule, FreyHintComponent, FreyInputDirective, FreyLabelComponent, FreyOptionComponent, FreyPrefix, FreySelectComponent, FreySuccessComponent, FreySuffix, FreyTextareaDirective };
//# sourceMappingURL=freya-form.mjs.map
