import * as i0 from '@angular/core';
import { signal, computed, inject, effect, Directive, HostBinding, Input } from '@angular/core';
import { Validators, NgControl } from '@angular/forms';
import { Subscription, Subject, firstValueFrom, timer } from 'rxjs';
import { map } from 'rxjs/operators';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
class FreyControlForm {
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) ?? false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isValid = computed(() => this.formControl()?.valid ?? true, ...(ngDevMode ? [{ debugName: "isValid" }] : []));
    isInvalid = computed(() => this.formControl()?.invalid ?? false, ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    isTouched = computed(() => this.formControl()?.touched ?? false, ...(ngDevMode ? [{ debugName: "isTouched" }] : []));
    errors = computed(() => this.formControl()?.errors ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : []));
    ngControl = inject(NgControl, { optional: true });
    subscription = new Subscription();
    constructor() {
        // Sincronizar el estado de disabled cuando cambie el control
        effect(() => {
            const ctrl = this.formControl();
            if (ctrl) {
                this.disabled.set(ctrl.disabled);
            }
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    ngAfterContentInit() {
        if (this.ngControl?.control) {
            const ctrl = this.ngControl.control;
            this.formControl.set(ctrl);
            this.subscription.add(
            // Suscribirse a cambios de estado del control
            ctrl.statusChanges?.subscribe(() => {
                // Forzar re-evaluación de computeds
                this.formControl.set(ctrl);
            }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyControlForm, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, decorators: [{
            type: Directive,
            args: [{}]
        }], ctorParameters: () => [] });

class FreyControlValueAccessor {
    writeValue(value) { }
    onChange = () => { };
    registerOnChange(fn) {
        this.onChange = fn;
    }
    onTouched = () => { };
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) { }
}

class SubjectState {
    $observable;
    _subject;
    constructor() {
        this._subject = new Subject();
        this.$observable = this._subject.asObservable();
    }
    update(value) {
        this._subject.next(value);
    }
    complete() {
        this._subject.complete();
    }
    error(error) {
        this._subject.error(error);
    }
}

const wait = (ms) => firstValueFrom(timer(ms).pipe(map(() => undefined)));
const getRequestAsync = async (request) => {
    try {
        const data = await firstValueFrom(request);
        return { status: true, data };
    }
    catch (error) {
        return { status: false, error };
    }
};

const isNullOrUndefined = (data) => {
    return data === null || data === undefined ? true : false || data === '';
};
const isDefined = (data) => {
    return data !== null && data !== undefined;
};

const isObjectEmpty = (obj) => {
    if (obj === null || obj === undefined) {
        return true;
    }
    return Object.values(obj).every((value) => {
        if (typeof value === 'object') {
            return isObjectEmpty(value);
        }
        return value === null;
    });
};
const getObjectNestedProperty = (obj, path) => path.split('.').reduce((acc, key) => acc && acc[key], obj);

/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant = 'solid';
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color = 'primary';
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size = 'medium';
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading = false;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled = false;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular = false;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly = false;
    /**
     * Clases computadas para el host
     */
    get hostClasses() {
        const classes = ['frey-button'];
        // Variante
        if (this.variant !== 'solid') {
            classes.push(`frey-button--${this.variant}`);
        }
        // Color
        classes.push(`frey-button--${this.color}`);
        // Tamaño
        if (this.size !== 'medium') {
            classes.push(`frey-button--${this.size}`);
        }
        // Estados
        if (this.loading) {
            classes.push('frey-button--loading');
        }
        if (this.disabled) {
            classes.push('frey-button--disabled');
        }
        // Modificadores
        if (this.circular) {
            classes.push('frey-button--circular');
        }
        if (this.iconOnly) {
            classes.push('frey-button--icon-only');
        }
        return classes.join(' ');
    }
    /**
     * Atributo disabled del botón
     */
    get isDisabled() {
        return this.disabled || this.loading ? true : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyButtonDirective, isStandalone: true, selector: "[freyButton]", inputs: { variant: "variant", color: "color", size: "size", loading: "loading", disabled: "disabled", circular: "circular", iconOnly: "iconOnly" }, host: { attributes: { "type": "button" }, properties: { "class": "this.hostClasses", "attr.disabled": "this.isDisabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyButton]',
                    standalone: true,
                    host: {
                        type: 'button',
                    },
                }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], loading: [{
                type: Input
            }], disabled: [{
                type: Input
            }], circular: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], isDisabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

/**
 * Public API Surface of Freya UI Library
 * Primero deben ir las clases globales o compartidas
 */
// Clases

/**
 * Generated bundle index. Do not edit.
 */

export { FreyButtonDirective, FreyControlForm, FreyControlValueAccessor, SubjectState, getObjectNestedProperty, getRequestAsync, isDefined, isNullOrUndefined, isObjectEmpty, wait };
//# sourceMappingURL=freya.mjs.map
