import * as i0 from '@angular/core';
import { signal, computed, inject, effect, Directive, HostBinding, Input, input, output, Component, TemplateRef, ElementRef, Renderer2, contentChild, contentChildren, model, forwardRef, Injectable, HostListener, ViewChild, EventEmitter, Output, NgModule, viewChild, Injector } from '@angular/core';
import { Validators, NgControl, NG_VALUE_ACCESSOR, FormControl } from '@angular/forms';
import { Subscription, Subject, firstValueFrom, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import * as i1 from '@angular/common';
import { NgTemplateOutlet, NgClass, AsyncPipe } from '@angular/common';
import { FreyControlValueAccessor as FreyControlValueAccessor$1, SubjectState as SubjectState$1, FreyControlForm as FreyControlForm$1 } from 'freya/class';
import { isDefined as isDefined$1, wait as wait$1 } from 'freya/helpers';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
class FreyControlForm {
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) ?? false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isValid = computed(() => this.formControl()?.valid ?? true, ...(ngDevMode ? [{ debugName: "isValid" }] : []));
    isInvalid = computed(() => this.formControl()?.invalid ?? false, ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    isTouched = computed(() => this.formControl()?.touched ?? false, ...(ngDevMode ? [{ debugName: "isTouched" }] : []));
    errors = computed(() => this.formControl()?.errors ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : []));
    ngControl = inject(NgControl, { optional: true });
    subscription = new Subscription();
    constructor() {
        // Sincronizar el estado de disabled cuando cambie el control
        effect(() => {
            const ctrl = this.formControl();
            if (ctrl) {
                this.disabled.set(ctrl.disabled);
            }
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    ngAfterContentInit() {
        if (this.ngControl?.control) {
            const ctrl = this.ngControl.control;
            this.formControl.set(ctrl);
            this.subscription.add(
            // Suscribirse a cambios de estado del control
            ctrl.statusChanges?.subscribe(() => {
                // Forzar re-evaluación de computeds
                this.formControl.set(ctrl);
            }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyControlForm, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, decorators: [{
            type: Directive,
            args: [{}]
        }], ctorParameters: () => [] });

class FreyControlValueAccessor {
    writeValue(value) { }
    onChange = () => { };
    registerOnChange(fn) {
        this.onChange = fn;
    }
    onTouched = () => { };
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) { }
}

class SubjectState {
    $observable;
    _subject;
    constructor() {
        this._subject = new Subject();
        this.$observable = this._subject.asObservable();
    }
    update(value) {
        this._subject.next(value);
    }
    complete() {
        this._subject.complete();
    }
    error(error) {
        this._subject.error(error);
    }
}

const wait = (ms) => firstValueFrom(timer(ms).pipe(map(() => undefined)));
const getRequestAsync = async (request) => {
    try {
        const data = await firstValueFrom(request);
        return { status: true, data };
    }
    catch (error) {
        return { status: false, error };
    }
};

const isNullOrUndefined = (data) => {
    return data === null || data === undefined ? true : false || data === '';
};
const isDefined = (data) => {
    return data !== null && data !== undefined;
};

/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant = 'solid';
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color = 'primary';
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size = 'medium';
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading = false;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled = false;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular = false;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly = false;
    /**
     * Clases computadas para el host
     */
    get hostClasses() {
        const classes = ['frey-button'];
        // Variante
        if (this.variant !== 'solid') {
            classes.push(`frey-button--${this.variant}`);
        }
        // Color
        classes.push(`frey-button--${this.color}`);
        // Tamaño
        if (this.size !== 'medium') {
            classes.push(`frey-button--${this.size}`);
        }
        // Estados
        if (this.loading) {
            classes.push('frey-button--loading');
        }
        if (this.disabled) {
            classes.push('frey-button--disabled');
        }
        // Modificadores
        if (this.circular) {
            classes.push('frey-button--circular');
        }
        if (this.iconOnly) {
            classes.push('frey-button--icon-only');
        }
        return classes.join(' ');
    }
    /**
     * Atributo disabled del botón
     */
    get isDisabled() {
        return this.disabled || this.loading ? true : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyButtonDirective, isStandalone: true, selector: "[freyButton]", inputs: { variant: "variant", color: "color", size: "size", loading: "loading", disabled: "disabled", circular: "circular", iconOnly: "iconOnly" }, host: { attributes: { "type": "button" }, properties: { "class": "this.hostClasses", "attr.disabled": "this.isDisabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyButton]',
                    standalone: true,
                    host: {
                        type: 'button',
                    },
                }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], loading: [{
                type: Input
            }], disabled: [{
                type: Input
            }], circular: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], isDisabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

/**
 * Componente Paginador para Freya UI.
 *
 * Este componente proporciona controles de paginación para navegar a través de una colección de elementos.
 * Permite al usuario ver el número total de elementos, el número de elementos por página,
 * y navegar entre páginas utilizando botones de "anterior", "siguiente" y números de página.
 *
 * Los estilos son completamente opcionales.
 * Para usar los estilos por defecto:
 * @import 'freya/styles/paginator/paginator.scss';
 *
 * @example
 * ```html
 * <frey-paginator
 *   [totalItems]="100"
 *   [itemsPerPage]="10"
 *   [currentPage]="1"
 *   (pageChange)="onPageChange($event)"
 *   (itemsPerPageChange)="onItemsPerPageChange($event)"
 * ></frey-paginator>
 * ```
 */
class FreyPaginatorComponent {
    /**
     * El número total de elementos en la colección.
     */
    totalItems = input.required(...(ngDevMode ? [{ debugName: "totalItems" }] : []));
    /**
     * El número de elementos a mostrar por página.
     * Por defecto es 10.
     */
    itemsPerPage = input(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    /**
     * La página actual seleccionada.
     * Por defecto es 1.
     */
    currentPage = input(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    /**
     * Evento emitido cuando la página cambia.
     * Emite el nuevo número de página.
     */
    pageChange = output();
    /**
     * Evento emitido cuando cambia el número de elementos por página.
     * Emite el nuevo valor de elementos por página.
     */
    itemsPerPageChange = output();
    /** Señal interna para el estado mutable de currentPage */
    _currentPage = signal(1, ...(ngDevMode ? [{ debugName: "_currentPage" }] : []));
    /** Señal interna para el estado mutable de itemsPerPage */
    _itemsPerPage = signal(this.itemsPerPage(), ...(ngDevMode ? [{ debugName: "_itemsPerPage" }] : []));
    /** El número total de páginas calculadas. */
    totalPages = computed(() => Math.ceil(this.totalItems() / this._itemsPerPage()), ...(ngDevMode ? [{ debugName: "totalPages" }] : []));
    /** Array de números de página visibles en los controles. */
    visiblePages = computed(() => this.generateVisiblePages(this._currentPage(), this.totalPages()), ...(ngDevMode ? [{ debugName: "visiblePages" }] : []));
    constructor() {
        // Sincronizar la señal interna con el input
        effect(() => this._currentPage.set(this.currentPage()));
        effect(() => this._itemsPerPage.set(this.itemsPerPage()));
        // Validar y ajustar currentPage si es necesario
        effect(() => {
            if (this._currentPage() > this.totalPages() && this.totalPages() > 0) {
                this._currentPage.set(this.totalPages());
                this.pageChange.emit(this.totalPages());
            }
            else if (this._currentPage() < 1 && this.totalPages() > 0) {
                this._currentPage.set(1);
                this.pageChange.emit(1);
            }
        });
    }
    /**
     * Navega a la página especificada.
     * @param page El número de página al que navegar.
     */
    goToPage(page) {
        if (page >= 1 && page <= this.totalPages() && page !== this._currentPage()) {
            this._currentPage.set(page);
            this.pageChange.emit(page);
        }
    }
    /**
     * Navega a la página anterior.
     */
    prevPage() {
        if (this._currentPage() > 1) {
            this.goToPage(this._currentPage() - 1);
        }
    }
    /**
     * Navega a la página siguiente.
     */
    nextPage() {
        if (this._currentPage() < this.totalPages()) {
            this.goToPage(this._currentPage() + 1);
        }
    }
    /**
     * Actualiza el número de elementos por página basado en la entrada del usuario.
     * @param value El nuevo valor de elementos por página.
     */
    updateItemsPerPage(value) {
        const parsedValue = parseInt(value, 10);
        if (!isNaN(parsedValue) && parsedValue > 0) {
            this._itemsPerPage.set(parsedValue); // Actualizar la señal interna
            this.itemsPerPageChange.emit(parsedValue);
            this.pageChange.emit(this._currentPage());
        }
    }
    /**
     * Genera un array de números de página para mostrar en los controles.
     * @param currentPage La página actual.
     * @param totalPages El número total de páginas.
     * @returns Un array de números de página visibles.
     */
    generateVisiblePages(currentPage, totalPages) {
        const pages = [];
        const maxPagesToShow = 5; // Número máximo de páginas a mostrar directamente
        if (totalPages <= maxPagesToShow) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        }
        else {
            let startPage;
            let endPage;
            if (currentPage <= Math.floor(maxPagesToShow / 2) + 1) {
                startPage = 1;
                endPage = maxPagesToShow - 1;
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
            else if (currentPage >= totalPages - Math.floor(maxPagesToShow / 2)) {
                startPage = totalPages - maxPagesToShow + 2;
                endPage = totalPages;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
            }
            else {
                startPage = currentPage - Math.floor(maxPagesToShow / 2) + 1;
                endPage = currentPage + Math.floor(maxPagesToShow / 2) - 1;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
        }
        return pages.filter((value, index, self) => self.indexOf(value) === index); // Eliminar duplicados si los hubiera
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyPaginatorComponent, isStandalone: true, selector: "frey-paginator", inputs: { totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: true, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", itemsPerPageChange: "itemsPerPageChange" }, host: { classAttribute: "frey-paginator" }, ngImport: i0, template: "<div class=\"frey-paginator__summary\">\n  <span>Total: {{ totalItems() }} elementos</span>\n  <div>\n    <span>Elementos por p\u00E1gina: </span>\n\n    <input\n      type=\"number\"\n      [value]=\"itemsPerPage()\"\n      (input)=\"updateItemsPerPage($event.target.value)\"\n      class=\"frey-paginator__input\"\n      min=\"1\"\n    />\n  </div>\n</div>\n\n<div class=\"frey-paginator__controls\">\n  <button\n    class=\"frey-paginator__button frey-paginator__button--prev\"\n    (click)=\"prevPage()\"\n    [disabled]=\"_currentPage() === 1\"\n  >\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M26 16 L18 24 L26 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span>Anterior</span>\n  </button>\n\n  @for (page of visiblePages(); track $index) {\n    @if (page === '...') {\n      <span class=\"frey-paginator__ellipsis\">...</span>\n    } @else {\n      <button\n        class=\"frey-paginator__button\"\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\n        (click)=\"goToPage(page)\"\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\n      >\n        {{ page }}\n      </button>\n    }\n  }\n\n  <button\n    class=\"frey-paginator__button frey-paginator__button--next\"\n    (click)=\"nextPage()\"\n    [disabled]=\"_currentPage() === totalPages()\"\n  >\n    <span>Siguiente</span>\n\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M22 16 L30 24 L22 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-paginator', standalone: true, imports: [], host: {
                        class: 'frey-paginator',
                    }, template: "<div class=\"frey-paginator__summary\">\n  <span>Total: {{ totalItems() }} elementos</span>\n  <div>\n    <span>Elementos por p\u00E1gina: </span>\n\n    <input\n      type=\"number\"\n      [value]=\"itemsPerPage()\"\n      (input)=\"updateItemsPerPage($event.target.value)\"\n      class=\"frey-paginator__input\"\n      min=\"1\"\n    />\n  </div>\n</div>\n\n<div class=\"frey-paginator__controls\">\n  <button\n    class=\"frey-paginator__button frey-paginator__button--prev\"\n    (click)=\"prevPage()\"\n    [disabled]=\"_currentPage() === 1\"\n  >\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M26 16 L18 24 L26 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span>Anterior</span>\n  </button>\n\n  @for (page of visiblePages(); track $index) {\n    @if (page === '...') {\n      <span class=\"frey-paginator__ellipsis\">...</span>\n    } @else {\n      <button\n        class=\"frey-paginator__button\"\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\n        (click)=\"goToPage(page)\"\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\n      >\n        {{ page }}\n      </button>\n    }\n  }\n\n  <button\n    class=\"frey-paginator__button frey-paginator__button--next\"\n    (click)=\"nextPage()\"\n    [disabled]=\"_currentPage() === totalPages()\"\n  >\n    <span>Siguiente</span>\n\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M22 16 L30 24 L22 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: true }] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], itemsPerPageChange: [{ type: i0.Output, args: ["itemsPerPageChange"] }] } });

/**
 * Directive to define a cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyCellDefDirective, isStandalone: true, selector: "[freyCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to add sorting functionality to table columns.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef freyColumnSort>
 *     <span>Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyColumnSortDirective {
    freyColumnSort = input(...(ngDevMode ? [undefined, { debugName: "freyColumnSort" }] : []));
    sortStatus = output();
    isArrowUp = false;
    elementRef = inject(ElementRef);
    renderer2 = inject(Renderer2);
    // private readonly cdr = inject(ChangeDetectorRef);
    ngAfterContentInit() {
        const iconSort = this.renderer2.createElement('span');
        const icon = this.renderer2.createText('▼');
        this.renderer2.setStyle(iconSort, 'font-size', '10px');
        this.renderer2.setStyle(iconSort, 'padding-left', ' 10px');
        this.renderer2.appendChild(iconSort, icon);
        this.renderer2.listen(this.elementRef.nativeElement, 'click', () => {
            this.isArrowUp = !this.isArrowUp;
            this.renderer2.setProperty(iconSort, 'textContent', this.getArrowText());
            // this.cdr.markForCheck();
        });
        this.renderer2.appendChild(this.elementRef.nativeElement, iconSort);
    }
    getArrowText() {
        this.sortStatus.emit(this.isArrowUp);
        return this.isArrowUp ? '▲' : '▼';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.1.2", type: FreyColumnSortDirective, isStandalone: true, selector: "[freyColumnSort]", inputs: { freyColumnSort: { classPropertyName: "freyColumnSort", publicName: "freyColumnSort", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sortStatus: "sortStatus" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnSort]',
                    standalone: true,
                }]
        }], propDecorators: { freyColumnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnSort", required: false }] }], sortStatus: [{ type: i0.Output, args: ["sortStatus"] }] } });

/**
 * Directive to define a header cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Column Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyHeaderCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyHeaderCellDefDirective, isStandalone: true, selector: "[freyHeaderCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyHeaderCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to define a column in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Name</span>
 *   </th>
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyColumnDefDirective {
    columnName = input(undefined, { ...(ngDevMode ? { debugName: "columnName" } : {}), alias: 'freyColumnDef' });
    headerCellDef = contentChild(FreyHeaderCellDefDirective, ...(ngDevMode ? [{ debugName: "headerCellDef" }] : []));
    cellDef = contentChild(FreyCellDefDirective, ...(ngDevMode ? [{ debugName: "cellDef" }] : []));
    sort = contentChild(FreyColumnSortDirective, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.1.2", type: FreyColumnDefDirective, isStandalone: true, selector: "[freyColumnDef]", inputs: { columnName: { classPropertyName: "columnName", publicName: "freyColumnDef", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "headerCellDef", first: true, predicate: FreyHeaderCellDefDirective, descendants: true, isSignal: true }, { propertyName: "cellDef", first: true, predicate: FreyCellDefDirective, descendants: true, isSignal: true }, { propertyName: "sort", first: true, predicate: FreyColumnSortDirective, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnDef]',
                    standalone: true,
                }]
        }], propDecorators: { columnName: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnDef", required: false }] }], headerCellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyHeaderCellDefDirective), { isSignal: true }] }], cellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyCellDefDirective), { isSignal: true }] }], sort: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyColumnSortDirective), { isSignal: true }] }] } });

/**
 * Freya Table Component - A flexible and lightweight data table.
 *
 * Styles are completely optional and must be imported separately.
 * To use the default styles, import:
 * @import 'freya/styles/table/table.scss';
 *
 * @example
 * ```html
 * <!-- Show 10 records per page -->
 * <frey-table [dataSource]="data" [itemsPerPage]="10">
 *   <ng-container freyColumnDef="name">
 *     <th *freyHeaderCellDef>
 *       <span>Name</span>
 *     </th>
 *     <td *freyCellDef="let row">
 *       <div>{{ row.name }}</div>
 *     </td>
 *   </ng-container>
 * </frey-table>
 *
 * <!-- Show all records (no pagination) -->
 * <frey-table [dataSource]="data" [itemsPerPage]="null">
 *   <!-- columns -->
 * </frey-table>
 * ```
 */
class FreyTableComponent {
    // Inputs (using model() for programmatic access)
    columnDefs = contentChildren(FreyColumnDefDirective, ...(ngDevMode ? [{ debugName: "columnDefs" }] : []));
    dataSource = model([], ...(ngDevMode ? [{ debugName: "dataSource" }] : []));
    searchTerm = model('', ...(ngDevMode ? [{ debugName: "searchTerm" }] : []));
    itemsPerPage = model(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    currentPage = model(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    selectable = model(false, ...(ngDevMode ? [{ debugName: "selectable" }] : []));
    // Outputs
    searchResults = output();
    clickRow = output();
    // Computed columns from column definitions
    columns = computed(() => this.columnDefs().map((colDef) => ({
        name: colDef.columnName(),
        headerCellDef: colDef.headerCellDef(),
        cellDef: colDef.cellDef(),
    })), ...(ngDevMode ? [{ debugName: "columns" }] : []));
    // Computed filtered data based on search term
    filteredDataBySearch = computed(() => {
        const data = this.dataSource();
        const search = this.searchTerm().trim().toLowerCase();
        if (!search) {
            return [...data];
        }
        return data.filter((row) => Object.keys(row).some((key) => row[key]?.toString().toLowerCase().includes(search)));
    }, ...(ngDevMode ? [{ debugName: "filteredDataBySearch" }] : []));
    // Computed paginated and sorted data
    paginatedData = computed(() => {
        const filtered = this.filteredDataBySearch();
        const sort = this.sortState();
        const sortedData = [...filtered];
        // Apply sorting if active
        if (sort) {
            sortedData.sort((a, b) => this.compareValues(a, b, sort.column, sort.direction));
        }
        // Apply pagination (if itemsPerPage is null, show all)
        const perPage = this.itemsPerPage();
        if (perPage === null) {
            return sortedData;
        }
        const page = this.currentPage();
        const startIndex = (page - 1) * perPage;
        const endIndex = startIndex + perPage;
        return sortedData.slice(startIndex, endIndex);
    }, ...(ngDevMode ? [{ debugName: "paginatedData" }] : []));
    // Selection state
    selectedRowIndex = signal(null, ...(ngDevMode ? [{ debugName: "selectedRowIndex" }] : []));
    selectedRow = signal(null, ...(ngDevMode ? [{ debugName: "selectedRow" }] : []));
    // Sort state
    sortState = signal(null, ...(ngDevMode ? [{ debugName: "sortState" }] : []));
    constructor() {
        // Effect to emit search results when filtered data changes
        effect(() => {
            const filtered = this.filteredDataBySearch();
            this.searchResults.emit(filtered.length);
        });
        // Effect to set up sort event listeners
        effect((onCleanup) => {
            const cols = this.columnDefs();
            const subscriptions = [];
            cols.forEach((colDef) => {
                const sortDirective = colDef.sort();
                if (sortDirective) {
                    const subscription = sortDirective.sortStatus.subscribe(() => {
                        this.onSort(colDef.columnName() ?? '');
                    });
                    subscriptions.push(subscription);
                }
            });
            onCleanup(() => {
                subscriptions.forEach((sub) => sub.unsubscribe());
            });
        });
    }
    selectRow(columnName, row, index) {
        if (!this.selectable()) {
            return;
        }
        if (this.selectedRow() === row) {
            this.selectedRowIndex.set(null);
            this.selectedRow.set(null);
            this.clickRow.emit(null);
            return;
        }
        this.selectedRowIndex.set(index);
        this.selectedRow.set(row);
        this.clickRow.emit({ name: columnName, data: row, rowIndex: index });
    }
    isRowSelected(row) {
        return this.selectedRow() === row;
    }
    onSort(column) {
        const currentSort = this.sortState();
        if (currentSort?.column === column) {
            this.sortState.set({
                column,
                direction: currentSort.direction === 'asc' ? 'desc' : 'asc',
            });
        }
        else {
            this.sortState.set({ column, direction: 'asc' });
        }
    }
    compareValues(a, b, column, direction) {
        const valueA = a[column];
        const valueB = b[column];
        if (typeof valueA === 'boolean' && typeof valueB === 'boolean') {
            return direction === 'asc'
                ? Number(valueA) - Number(valueB)
                : Number(valueB) - Number(valueA);
        }
        if (this.isNumeric(valueA) && this.isNumeric(valueB)) {
            return this.compareNumeric(valueA, valueB, direction);
        }
        return this.compareString((valueA ?? '').toString(), (valueB ?? '').toString(), direction);
    }
    compareNumeric(a, b, direction) {
        return direction === 'asc' ? a - b : b - a;
    }
    compareString(a, b, direction) {
        return a.localeCompare(b) * (direction === 'asc' ? 1 : -1);
    }
    isNumeric(value) {
        return typeof value === 'number' && !isNaN(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyTableComponent, isStandalone: true, selector: "frey-table", inputs: { dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, searchTerm: { classPropertyName: "searchTerm", publicName: "searchTerm", isSignal: true, isRequired: false, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dataSource: "dataSourceChange", searchTerm: "searchTermChange", itemsPerPage: "itemsPerPageChange", currentPage: "currentPageChange", selectable: "selectableChange", searchResults: "searchResults", clickRow: "clickRow" }, queries: [{ propertyName: "columnDefs", predicate: FreyColumnDefDirective, isSignal: true }], ngImport: i0, template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-table', standalone: true, imports: [NgTemplateOutlet], template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { columnDefs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => FreyColumnDefDirective), { isSignal: true }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }, { type: i0.Output, args: ["dataSourceChange"] }], searchTerm: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchTerm", required: false }] }, { type: i0.Output, args: ["searchTermChange"] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }, { type: i0.Output, args: ["itemsPerPageChange"] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }, { type: i0.Output, args: ["currentPageChange"] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }, { type: i0.Output, args: ["selectableChange"] }], searchResults: [{ type: i0.Output, args: ["searchResults"] }], clickRow: [{ type: i0.Output, args: ["clickRow"] }] } });

/**
 * Public API Surface of Freya Table
 */

class FreyTimepickerComponent extends FreyControlValueAccessor$1 {
    initialTime = input(null, ...(ngDevMode ? [{ debugName: "initialTime" }] : []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : []));
    minTime = input(null, ...(ngDevMode ? [{ debugName: "minTime" }] : []));
    maxTime = input(null, ...(ngDevMode ? [{ debugName: "maxTime" }] : []));
    timeChange = output();
    hour = signal('12', ...(ngDevMode ? [{ debugName: "hour" }] : []));
    minute = signal('00', ...(ngDevMode ? [{ debugName: "minute" }] : []));
    period = signal('AM', ...(ngDevMode ? [{ debugName: "period" }] : []));
    formControlDisabled = signal(false, ...(ngDevMode ? [{ debugName: "formControlDisabled" }] : []));
    isInteractionDisabled = computed(() => this.disabled() || this.readonly() || this.formControlDisabled(), ...(ngDevMode ? [{ debugName: "isInteractionDisabled" }] : []));
    isInputDisabled = computed(() => this.disabled() || this.formControlDisabled(), ...(ngDevMode ? [{ debugName: "isInputDisabled" }] : []));
    currentTime = computed(() => {
        const hourNum = parseInt(this.hour()) || 12;
        const minuteNum = parseInt(this.minute()) || 0;
        const hour24 = this.convertTo24Hour(hourNum, this.period());
        return `${hour24.toString().padStart(2, '0')}:${minuteNum.toString().padStart(2, '0')}:00`;
    }, ...(ngDevMode ? [{ debugName: "currentTime" }] : []));
    constructor() {
        super();
        effect(() => {
            const min = this.minTime();
            if (min && this.hour() === '12' && this.minute() === '00' && this.period() === 'AM') {
                this.setTimeFromString(min);
            }
        });
        effect(() => {
            const currentTime = this.currentTime();
            this.timeChange.emit(currentTime);
            this.onChange(currentTime);
        });
    }
    writeValue(value) {
        if (value) {
            this.setTimeFromString(value);
        }
        else {
            this.resetToDefault();
        }
    }
    setDisabledState(isDisabled) {
        this.formControlDisabled.set(isDisabled);
    }
    onHourInput(event) {
        if (this.isInteractionDisabled()) {
            return;
        }
        const inputElement = event.target;
        const inputValue = inputElement.value;
        if (inputValue === '00') {
            inputElement.value = this.hour();
            return;
        }
        const value = this.sanitizeAndValidateHour(inputValue);
        this.hour.set(value);
        this.onTouched();
    }
    onMinuteInput(event) {
        if (this.isInteractionDisabled()) {
            return;
        }
        const value = this.sanitizeAndValidateMinute(event.target.value);
        this.minute.set(value);
        this.onTouched();
    }
    onHourBlur() {
        if (this.isInteractionDisabled()) {
            return;
        }
        const formattedHour = this.formatHour(this.hour());
        this.hour.set(formattedHour);
        this.validateTimeRange();
    }
    onMinuteBlur() {
        if (this.isInteractionDisabled()) {
            return;
        }
        const formattedMinute = this.formatMinute(this.minute());
        this.minute.set(formattedMinute);
        this.validateTimeRange();
    }
    togglePeriod() {
        if (this.isInteractionDisabled()) {
            return;
        }
        this.period.set(this.period() === 'AM' ? 'PM' : 'AM');
        this.onTouched();
        this.validateTimeRange();
    }
    validateTimeRange() {
        const currentTimeMinutes = this.getTimeInMinutes();
        if (this.minTime()) {
            const minMinutes = this.getTimeInMinutesFromString(this.minTime());
            if (currentTimeMinutes < minMinutes) {
                this.setTimeFromString(this.minTime());
                return;
            }
        }
        if (this.maxTime()) {
            const maxMinutes = this.getTimeInMinutesFromString(this.maxTime());
            if (currentTimeMinutes > maxMinutes) {
                this.setTimeFromString(this.maxTime());
                return;
            }
        }
    }
    getTimeInMinutes(date) {
        if (date) {
            return date.getHours() * 60 + date.getMinutes();
        }
        const currentHour = parseInt(this.hour()) || 12;
        const currentMinute = parseInt(this.minute()) || 0;
        const hour24 = this.convertTo24Hour(currentHour, this.period());
        return hour24 * 60 + currentMinute;
    }
    getTimeInMinutesFromString(timeString) {
        const timeParts = timeString.split(':');
        const hour = parseInt(timeParts[0]) || 0;
        const minute = parseInt(timeParts[1]) || 0;
        return hour * 60 + minute;
    }
    sanitizeAndValidateHour(input) {
        const cleaned = input.replace(/\D/g, '').substring(0, 2);
        if (!cleaned) {
            return this.hour();
        }
        const num = parseInt(cleaned);
        if (num === 0) {
            return this.hour();
        }
        if (cleaned.length === 1 && num > 1) {
            return num.toString().padStart(2, '0');
        }
        if (num > 12) {
            return cleaned.charAt(0);
        }
        return cleaned;
    }
    sanitizeAndValidateMinute(input) {
        const cleaned = input.replace(/\D/g, '').substring(0, 2);
        if (!cleaned) {
            return this.minute();
        }
        const num = parseInt(cleaned);
        if (cleaned.length === 1 && num > 5) {
            return num.toString().padStart(2, '0');
        }
        // Durante la entrada, permitir valores hasta 99 y que la validación real se haga en blur
        return cleaned;
    }
    formatHour(value) {
        const cleaned = value.replace(/\D/g, '');
        if (!cleaned) {
            return '12';
        }
        const num = parseInt(cleaned);
        if (num === 0 || num > 12) {
            return '12';
        }
        if (num < 1) {
            return '01';
        }
        return num.toString().padStart(2, '0');
    }
    formatMinute(value) {
        const cleaned = value.replace(/\D/g, '');
        if (!cleaned) {
            return '00';
        }
        const num = parseInt(cleaned);
        if (num > 59) {
            const firstDigit = parseInt(cleaned.charAt(0));
            if (firstDigit > 5) {
                return '00';
            }
            return firstDigit.toString().padStart(2, '0');
        }
        return num.toString().padStart(2, '0');
    }
    convertTo24Hour(hour12, period) {
        if (period === 'PM' && hour12 !== 12) {
            return hour12 + 12;
        }
        if (period === 'AM' && hour12 === 12) {
            return 0;
        }
        return hour12;
    }
    setTimeFromString(timeString) {
        const timeParts = timeString.split(':');
        const hour24 = parseInt(timeParts[0]) || 0;
        const minutes = parseInt(timeParts[1]) || 0;
        const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
        const period = hour24 >= 12 ? 'PM' : 'AM';
        this.hour.set(hour12.toString().padStart(2, '0'));
        this.minute.set(minutes.toString().padStart(2, '0'));
        this.period.set(period);
    }
    resetToDefault() {
        this.hour.set('12');
        this.minute.set('00');
        this.period.set('AM');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTimepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.2", type: FreyTimepickerComponent, isStandalone: true, selector: "frey-timepicker", inputs: { initialTime: { classPropertyName: "initialTime", publicName: "initialTime", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, minTime: { classPropertyName: "minTime", publicName: "minTime", isSignal: true, isRequired: false, transformFunction: null }, maxTime: { classPropertyName: "maxTime", publicName: "maxTime", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { timeChange: "timeChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreyTimepickerComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<ng-content select=\"frey-label\"></ng-content>\n<div\n  class=\"time-picker\"\n  [class.time-picker--disabled]=\"isInputDisabled()\"\n  [class.time-picker--readonly]=\"readonly()\"\n>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"hour()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onHourInput($event)\"\n      (blur)=\"onHourBlur()\"\n      maxlength=\"2\"\n      placeholder=\"12\"\n      id=\"frey-timepicker-hour\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-hour\">Hora</label>\n  </div>\n  <div class=\"time-picker__separator\">:</div>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"minute()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onMinuteInput($event)\"\n      (blur)=\"onMinuteBlur()\"\n      maxlength=\"2\"\n      placeholder=\"00\"\n      id=\"frey-timepicker-minute\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-minute\">Minutos</label>\n  </div>\n\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'AM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    AM\n  </button>\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'PM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    PM\n  </button>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTimepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-timepicker', imports: [], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreyTimepickerComponent),
                            multi: true,
                        },
                    ], template: "<ng-content select=\"frey-label\"></ng-content>\n<div\n  class=\"time-picker\"\n  [class.time-picker--disabled]=\"isInputDisabled()\"\n  [class.time-picker--readonly]=\"readonly()\"\n>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"hour()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onHourInput($event)\"\n      (blur)=\"onHourBlur()\"\n      maxlength=\"2\"\n      placeholder=\"12\"\n      id=\"frey-timepicker-hour\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-hour\">Hora</label>\n  </div>\n  <div class=\"time-picker__separator\">:</div>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"minute()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onMinuteInput($event)\"\n      (blur)=\"onMinuteBlur()\"\n      maxlength=\"2\"\n      placeholder=\"00\"\n      id=\"frey-timepicker-minute\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-minute\">Minutos</label>\n  </div>\n\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'AM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    AM\n  </button>\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'PM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    PM\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { initialTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialTime", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], minTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "minTime", required: false }] }], maxTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxTime", required: false }] }], timeChange: [{ type: i0.Output, args: ["timeChange"] }] } });

/**
 * Public API Surface of Freya Table
 */

const getDaysOfTheWeek = (language = 'es-Es') => {
    const days = [];
    for (let i = 0; i < 7; i++) {
        const date = new Date(2023, 0, i + 1);
        const dayName = new Intl.DateTimeFormat(language, { weekday: 'long' }).format(date);
        days.push(dayName);
    }
    return days;
};
const getFirstLetterOfDays = (days) => {
    return days.map((day) => day.charAt(0).toLowerCase());
};
const getDaysInMonth = (date) => {
    const month = date.getMonth() + 1; // Mes (1-12)
    const year = date.getFullYear(); // Año
    return month === 2
        ? year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)
            ? 29
            : 28
        : [1, 3, 5, 7, 8, 10, 12].includes(month)
            ? 31
            : 30;
};
const addOrSubtractMonth = (date, months) => {
    const newDate = new Date(date);
    newDate.setMonth(newDate.getMonth() + months);
    return newDate;
};
const formatDateDDMMYYYY = (date) => {
    return date.toLocaleDateString('es-MX', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    });
};
const isValidDateDDMMYYYY = (dateString) => {
    // Validar formato exacto: dos dígitos / dos dígitos / cuatro dígitos
    const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = dateString.match(dateRegex);
    if (!match) {
        return false;
    }
    const day = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const year = parseInt(match[3], 10);
    // Validación básica de rangos
    if (year < 1000 || year > 9999) {
        return false;
    }
    if (month < 1 || month > 12) {
        return false;
    }
    if (day < 1 || day > 31) {
        return false;
    }
    // Días por mes
    const daysInMonth = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (day > daysInMonth[month - 1]) {
        return false;
    }
    return true;
};
const isLeapYear = (year) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
};
const compareDates = (date1, date2, option) => {
    const formattedDate1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    const formattedDate2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
    if (option === 'lessOrEqual') {
        return formattedDate1 <= formattedDate2;
    }
    else if (option === 'greaterOrEqual') {
        return formattedDate1 >= formattedDate2;
    }
    else {
        throw new Error("Invalid option. Use 'lessOrEqual' or 'greaterOrEqual'.");
    }
};
const parseDateDDMMYYYY = (dateStr) => {
    const [day, month, year] = dateStr.split('/').map(Number);
    if (!day ||
        !month ||
        !year ||
        day < 1 ||
        day > 31 ||
        month < 1 ||
        month > 12 ||
        year < 1000 ||
        year > 9999) {
        return null;
    }
    const date = new Date(year, month - 1, day);
    // Verifica que la fecha generada coincide exactamente
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
        return null;
    }
    return date;
};
const generateDaysArray = (date) => {
    const daysInMonth = getDaysInMonth(date);
    const startDayIndex = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    const totalCells = 42;
    const daysArray = Array(totalCells).fill('');
    for (let day = 1; day <= daysInMonth; day++) {
        daysArray[startDayIndex + day - 1] = day.toString();
    }
    return daysArray;
};
const generateYearArray = (baseYear) => {
    const totalYears = 24;
    const fixedPosition = 9;
    const years = new Array(totalYears);
    for (let i = 0; i < fixedPosition; i++) {
        years[i] = baseYear - (fixedPosition - i);
    }
    years[fixedPosition] = baseYear;
    for (let i = fixedPosition + 1; i < totalYears; i++) {
        years[i] = baseYear + (i - fixedPosition);
    }
    return years;
};
const getMonthsArray = (locale, date) => {
    const monthsArray = [];
    for (let i = 0; i < 12; i++) {
        const monthName = new Intl.DateTimeFormat(locale, { month: 'long' }).format(new Date(date.getFullYear(), i, 1));
        monthsArray.push({ name: monthName.slice(0, 3), id: i });
    }
    return monthsArray;
};
const getShortMonthName = (locale, monthIndex) => {
    const date = new Date();
    date.setMonth(monthIndex);
    return new Intl.DateTimeFormat(locale, { month: 'long' }).format(date).slice(0, 3);
};
const formatRawDateInput = (value) => {
    const day = value.substring(0, 2);
    const month = value.substring(2, 4);
    const year = value.substring(4, 8);
    let formatted = '';
    if (day) {
        formatted += day;
    }
    if (month) {
        formatted += `/${month}`;
    }
    if (year) {
        formatted += `/${year}`;
    }
    return formatted;
};
const isValidDateInstance = (input) => {
    const date = new Date(input);
    return date instanceof Date && !isNaN(date.getTime());
};
const getSizeElementDisplayNone = (element) => {
    const clone = element.cloneNode(true);
    Object.assign(clone.style, {
        display: 'block',
        visibility: 'hidden',
        position: 'absolute',
        top: '-9999px',
    });
    document.body.appendChild(clone);
    const size = {
        width: clone.offsetWidth,
        height: clone.offsetHeight,
    };
    document.body.removeChild(clone);
    return size;
};

class MonthList {
    id = null;
    name = null;
}

class FreyDatePickerService {
    calendarChange$$ = new SubjectState$1();
    inputElement;
    inputElementControl;
    startView$$ = signal('multi-year', ...(ngDevMode ? [{ debugName: "startView$$" }] : []));
    statusCalendar$$ = signal('days', ...(ngDevMode ? [{ debugName: "statusCalendar$$" }] : []));
    calendarfilter;
    isOpen$$ = signal(false, ...(ngDevMode ? [{ debugName: "isOpen$$" }] : []));
    locale$$ = signal('es-ES', ...(ngDevMode ? [{ debugName: "locale$$" }] : []));
    minDate = null;
    maxDate = null;
    isDateValid = false;
    selectedDate$$ = signal(new Date(), ...(ngDevMode ? [{ debugName: "selectedDate$$" }] : []));
    selectedDay$$ = computed(() => {
        return this.selectedDate$$().getDate().toString();
    }, ...(ngDevMode ? [{ debugName: "selectedDay$$" }] : []));
    selectedMonth$$ = signal(new Date().getMonth(), ...(ngDevMode ? [{ debugName: "selectedMonth$$" }] : []));
    selectedYear$$ = computed(() => {
        return this.selectedDate$$().getFullYear();
    }, ...(ngDevMode ? [{ debugName: "selectedYear$$" }] : []));
    cacheSelectedDate = null;
    renderedDays$$ = signal([], ...(ngDevMode ? [{ debugName: "renderedDays$$" }] : []));
    renderedYears$$ = signal([], ...(ngDevMode ? [{ debugName: "renderedYears$$" }] : []));
    prevSelectedYear$$ = signal(null, ...(ngDevMode ? [{ debugName: "prevSelectedYear$$" }] : []));
    prevSelectedMonth$$ = signal(null, ...(ngDevMode ? [{ debugName: "prevSelectedMonth$$" }] : []));
    prevRenderedDays$$ = signal([], ...(ngDevMode ? [{ debugName: "prevRenderedDays$$" }] : []));
    prevRenderedYears$$ = signal([], ...(ngDevMode ? [{ debugName: "prevRenderedYears$$" }] : []));
    yearsToRender$$ = computed(() => {
        return this.prevRenderedYears$$()?.length ? this.prevRenderedYears$$() : this.renderedYears$$();
    }, ...(ngDevMode ? [{ debugName: "yearsToRender$$" }] : []));
    currentYear = new Date().getFullYear();
    currentMonth = new Date().getMonth();
    currentDay = new Date().getDate().toString();
    validSelectedDate() {
        if (this.selectedDate$$() === null || this.cacheSelectedDate === null) {
            return false;
        }
        if (formatDateDDMMYYYY(this.selectedDate$$()) !== formatDateDDMMYYYY(this.cacheSelectedDate)) {
            return false;
        }
        return true;
    }
    isInvalidMinMaxDate(date) {
        const adjustedMinDate = this.minDate ? new Date(this.minDate) : null;
        const adjustedMaxDate = this.maxDate ? new Date(this.maxDate) : null;
        return ((adjustedMinDate && date < adjustedMinDate) || (adjustedMaxDate && date > adjustedMaxDate));
    }
    initDate(startDate = new Date()) {
        this.renderedDays$$.set(generateDaysArray(startDate));
        this.renderedYears$$.set(generateYearArray(startDate.getFullYear()));
    }
    clearAuxData() {
        this.prevSelectedYear$$.set(null);
        this.prevSelectedMonth$$.set(null);
        this.prevRenderedDays$$.set([]);
        this.prevRenderedYears$$.set([]);
    }
    isValidDate(inputValue) {
        const formatDate = inputValue ? inputValue : formatDateDDMMYYYY(this.selectedDate$$());
        const dateAux = parseDateDDMMYYYY(formatDate);
        const isValidFormatDate = isValidDateDDMMYYYY(formatDate);
        const isValidFilter = this.calendarfilter ? !this.calendarfilter(dateAux) : true;
        const minDate = this.minDate ? compareDates(this.minDate, dateAux, 'lessOrEqual') : true;
        const maxDate = this.maxDate ? compareDates(this.maxDate, dateAux, 'greaterOrEqual') : true;
        this.isDateValid = isValidFormatDate && isValidFilter && minDate && maxDate;
    }
    generateDaysArray(date) {
        const daysInMonth = getDaysInMonth(date);
        const startDayIndex = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
        const totalCells = 42;
        const daysArray = Array(totalCells).fill('');
        for (let day = 1; day <= daysInMonth; day++) {
            daysArray[startDayIndex + day - 1] = day.toString();
        }
        return daysArray;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatePickerService, decorators: [{
            type: Injectable
        }] });

class DatepickerControlsComponent {
    prevSelectedMonthText$$ = computed(() => {
        const prevMonth = this.dateService.prevSelectedMonth$$();
        const locale = this.dateService.locale$$();
        return isDefined$1(prevMonth) ? getShortMonthName(locale, prevMonth) : null;
    }, ...(ngDevMode ? [{ debugName: "prevSelectedMonthText$$" }] : []));
    selectedMonthText$$ = computed(() => {
        const selectedMonth = this.dateService.selectedMonth$$();
        const locale = this.dateService.locale$$();
        return isDefined$1(selectedMonth) ? getShortMonthName(locale, selectedMonth) : null;
    }, ...(ngDevMode ? [{ debugName: "selectedMonthText$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    async configNavigate() {
        await wait$1(1);
        switch (this.dateService.statusCalendar$$()) {
            case 'days':
                this.dateService.statusCalendar$$.set('years');
                break;
            case 'months':
                this.dateService.statusCalendar$$.set('years');
                break;
            case 'years':
                this.dateService.statusCalendar$$.set('days');
                this.dateService.clearAuxData();
                this.dateService.initDate(this.dateService.selectedDate$$());
                break;
        }
    }
    previousOrNext(navigate) {
        if (this.dateService.statusCalendar$$() === 'days') {
            this.navigateForDays(navigate);
            return;
        }
        if (!this.dateService.prevSelectedYear$$()) {
            this.dateService.prevSelectedYear$$.set(this.dateService.selectedYear$$());
        }
        const nextOrPrev = navigate === 'next'
            ? this.dateService.prevSelectedYear$$() + 24
            : this.dateService.prevSelectedYear$$() - 24;
        this.dateService.prevRenderedYears$$.set(generateYearArray(nextOrPrev));
        this.dateService.prevSelectedYear$$.set(nextOrPrev);
    }
    navigateForDays(navigate) {
        if (!this.dateService.prevSelectedYear$$()) {
            this.dateService.prevSelectedYear$$.set(this.dateService.selectedYear$$());
            this.dateService.prevSelectedMonth$$.set(this.dateService.selectedDate$$().getMonth());
        }
        const monthId = this.dateService.prevSelectedMonth$$();
        let newMonth = navigate === 'next' ? monthId + 1 : monthId - 1;
        if (newMonth === -1 || newMonth === 12) {
            newMonth = newMonth === 12 ? 0 : 11;
            this.dateService.prevSelectedYear$$.update((year) => (year = navigate === 'next' ? year + 1 : year - 1));
        }
        const year = this.dateService.prevSelectedYear$$();
        const auxDate = new Date(year, newMonth, 1);
        this.dateService.prevRenderedDays$$.set(this.dateService.generateDaysArray(auxDate));
        this.dateService.prevSelectedMonth$$.set(newMonth);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerControlsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerControlsComponent, isStandalone: false, selector: "datepicker-controls", ngImport: i0, template: "<div class=\"calendar__controls\">\n  <button\n    [disabled]=\"dateService.startView$$() === 'multi-year'\"\n    class=\"calendar__years-button\"\n    (click)=\"configNavigate()\"\n  >\n    @switch (dateService.statusCalendar$$()) {\n      @case ('days') {\n        <span>\n          {{ prevSelectedMonthText$$() || selectedMonthText$$() }}\n          {{ dateService.prevSelectedYear$$() || dateService.selectedYear$$() }}\n        </span>\n      }\n      @case ('years') {\n        <span>\n          {{ dateService.yearsToRender$$()[0] }} - {{ dateService.yearsToRender$$()[23] }}\n        </span>\n      }\n      @default {\n        <span>{{ dateService.prevSelectedYear$$() }}</span>\n      }\n    }\n\n    <svg\n      class=\"calendar__arrow\"\n      [ngClass]=\"{ 'calendar__arrow--rotated': dateService.statusCalendar$$() !== 'days' }\"\n      viewBox=\"0 0 10 5\"\n      focusable=\"false\"\n      aria-hidden=\"true\"\n    >\n      <polygon points=\"0,0 5,5 10,0\"></polygon>\n    </svg>\n  </button>\n\n  @if (dateService.statusCalendar$$() !== 'months') {\n    <div class=\"calendar__control-body\">\n      <button class=\"calendar__control\" (click)=\"previousOrNext('prev')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z\" />\n        </svg>\n      </button>\n      <button class=\"calendar__control\" (click)=\"previousOrNext('next')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z\" />\n        </svg>\n      </button>\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerControlsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-controls', template: "<div class=\"calendar__controls\">\n  <button\n    [disabled]=\"dateService.startView$$() === 'multi-year'\"\n    class=\"calendar__years-button\"\n    (click)=\"configNavigate()\"\n  >\n    @switch (dateService.statusCalendar$$()) {\n      @case ('days') {\n        <span>\n          {{ prevSelectedMonthText$$() || selectedMonthText$$() }}\n          {{ dateService.prevSelectedYear$$() || dateService.selectedYear$$() }}\n        </span>\n      }\n      @case ('years') {\n        <span>\n          {{ dateService.yearsToRender$$()[0] }} - {{ dateService.yearsToRender$$()[23] }}\n        </span>\n      }\n      @default {\n        <span>{{ dateService.prevSelectedYear$$() }}</span>\n      }\n    }\n\n    <svg\n      class=\"calendar__arrow\"\n      [ngClass]=\"{ 'calendar__arrow--rotated': dateService.statusCalendar$$() !== 'days' }\"\n      viewBox=\"0 0 10 5\"\n      focusable=\"false\"\n      aria-hidden=\"true\"\n    >\n      <polygon points=\"0,0 5,5 10,0\"></polygon>\n    </svg>\n  </button>\n\n  @if (dateService.statusCalendar$$() !== 'months') {\n    <div class=\"calendar__control-body\">\n      <button class=\"calendar__control\" (click)=\"previousOrNext('prev')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z\" />\n        </svg>\n      </button>\n      <button class=\"calendar__control\" (click)=\"previousOrNext('next')\">\n        <svg viewBox=\"0 0 24 24\" focusable=\"false\" aria-hidden=\"true\" width=\"24\" height=\"24\">\n          <path d=\"M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z\" />\n        </svg>\n      </button>\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderDaysComponent {
    weekDayLetters$$ = computed(() => getFirstLetterOfDays(getDaysOfTheWeek(this.dateService.locale$$())), ...(ngDevMode ? [{ debugName: "weekDayLetters$$" }] : []));
    daysToRendered$$ = computed(() => this.dateService.prevRenderedDays$$()?.length
        ? this.dateService.prevRenderedDays$$()
        : this.dateService.renderedDays$$(), ...(ngDevMode ? [{ debugName: "daysToRendered$$" }] : []));
    isSelectedDay$$ = computed(() => (day) => {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.selectedYear$$() === this.dateService.prevSelectedYear$$() &&
                this.dateService.prevSelectedMonth$$() === this.dateService.selectedMonth$$() &&
                day === this.dateService.selectedDay$$());
        }
        return day === this.dateService.selectedDay$$();
    }, ...(ngDevMode ? [{ debugName: "isSelectedDay$$" }] : []));
    isCurrentDay$$ = computed(() => (day) => {
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.prevSelectedYear$$() === this.dateService.currentYear &&
                this.dateService.prevSelectedMonth$$() === this.dateService.currentMonth &&
                day === this.dateService.currentDay);
        }
        return (this.dateService.currentDay == day &&
            this.dateService.currentMonth === this.dateService.selectedMonth$$() &&
            this.dateService.currentYear === this.dateService.selectedYear$$());
    }, ...(ngDevMode ? [{ debugName: "isCurrentDay$$" }] : []));
    isDisabledDay$$ = computed(() => (day) => {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        if (!day) {
            return false;
        }
        const year = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const month = this.dateService.prevSelectedMonth$$() ?? this.dateService.selectedDate$$().getMonth();
        const date = new Date(year, month, parseInt(String(day), 10));
        let isInvalidMinMax = false;
        let isInvalidFilter = false;
        if (this.dateService.minDate || this.dateService.maxDate) {
            isInvalidMinMax = this.dateService.isInvalidMinMaxDate(date);
        }
        if (this.dateService.calendarfilter) {
            isInvalidFilter = this.dateService.calendarfilter(date);
        }
        return isInvalidMinMax || isInvalidFilter;
    }, ...(ngDevMode ? [{ debugName: "isDisabledDay$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    onSelectedDay(day) {
        if (!day || this.isDisabledDay$$()(String(day))) {
            return;
        }
        const year = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const month = this.dateService.prevSelectedMonth$$() ?? this.dateService.selectedDate$$().getMonth();
        this.dateService.clearAuxData();
        this.dateService.selectedDate$$.set(new Date(year, month, parseInt(String(day), 10)));
        this.dateService.isValidDate();
        if (this.dateService.isDateValid) {
            this.dateService.inputElement.value = formatDateDDMMYYYY(this.dateService.selectedDate$$());
            this.dateService.cacheSelectedDate = new Date(year, month, parseInt(String(day), 10));
            this.dateService.calendarChange$$.update(this.dateService.cacheSelectedDate);
            this.dateService.initDate(this.dateService.cacheSelectedDate);
            this.dateService.isOpen$$.set(false);
            if (this.dateService.inputElementControl) {
                this.dateService.inputElementControl.setValue(this.dateService.selectedDate$$(), {
                    emitEvent: false,
                    emitModelToViewChange: false,
                });
            }
        }
        if (this.dateService.startView$$() === 'multi-year') {
            this.dateService.statusCalendar$$.set('years');
            return;
        }
        this.dateService.statusCalendar$$.set('days');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderDaysComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderDaysComponent, isStandalone: false, selector: "datepicker-render-days", ngImport: i0, template: "<div class=\"calendar__header\">\n  @for (dayWeek of weekDayLetters$$(); track $index) {\n    <div class=\"calendar__day-week\">{{ dayWeek }}</div>\n  }\n</div>\n<div class=\"calendar__days\">\n  @for (day of daysToRendered$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__day\"\n      [ngClass]=\"{\n        'calendar__day--isday': day !== '',\n        'calendar__day--selected': isSelectedDay$$()(day),\n        'calendar__day--current': isCurrentDay$$()(day),\n        'calendar__day--disabled': isDisabledDay$$()(day),\n      }\"\n      (click)=\"onSelectedDay(day)\"\n    >\n      {{ day }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderDaysComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-days', template: "<div class=\"calendar__header\">\n  @for (dayWeek of weekDayLetters$$(); track $index) {\n    <div class=\"calendar__day-week\">{{ dayWeek }}</div>\n  }\n</div>\n<div class=\"calendar__days\">\n  @for (day of daysToRendered$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__day\"\n      [ngClass]=\"{\n        'calendar__day--isday': day !== '',\n        'calendar__day--selected': isSelectedDay$$()(day),\n        'calendar__day--current': isCurrentDay$$()(day),\n        'calendar__day--disabled': isDisabledDay$$()(day),\n      }\"\n      (click)=\"onSelectedDay(day)\"\n    >\n      {{ day }}\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderMonthsComponent {
    renderedMonths$$ = computed(() => getMonthsArray(this.dateService.locale$$(), new Date()), ...(ngDevMode ? [{ debugName: "renderedMonths$$" }] : []));
    isSelectedMonth$$ = computed(() => (monthId) => {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.selectedYear$$() === this.dateService.prevSelectedYear$$() &&
                monthId === this.dateService.selectedMonth$$());
        }
        return monthId === this.dateService.selectedMonth$$();
    }, ...(ngDevMode ? [{ debugName: "isSelectedMonth$$" }] : []));
    isCurrentMonth$$ = computed(() => (monthId) => {
        if (this.dateService?.prevSelectedYear$$()) {
            return (this.dateService.currentYear === this.dateService.prevSelectedYear$$() &&
                monthId === this.dateService.currentMonth);
        }
        return monthId === this.dateService.currentMonth;
    }, ...(ngDevMode ? [{ debugName: "isCurrentMonth$$" }] : []));
    isDisabledMonth$$ = computed(() => (month) => {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        return this.isValidMinMaxMonth(month);
    }, ...(ngDevMode ? [{ debugName: "isDisabledMonth$$" }] : []));
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    async onSelectedMonth(month) {
        if (this.isDisabledMonth$$()(month)) {
            return;
        }
        await wait$1(1);
        this.dateService.prevSelectedMonth$$.set(month.id);
        const auxDate = new Date(this.dateService.prevSelectedYear$$(), month.id, 1);
        this.dateService.prevRenderedDays$$.set(this.dateService.generateDaysArray(auxDate));
        this.dateService.statusCalendar$$.set('days');
    }
    isValidMinMaxMonth(month) {
        const minYear = this.dateService.minDate
            ? new Date(this.dateService.minDate).getFullYear()
            : null;
        const minMonth = this.dateService.minDate
            ? new Date(this.dateService.minDate).getMonth()
            : null;
        const maxYear = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getFullYear()
            : null;
        const maxMonth = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getMonth()
            : null;
        const selectedYear = this.dateService.prevSelectedYear$$() ?? this.dateService.selectedDate$$().getFullYear();
        const selectedMonth = month.id;
        // Ambos definidos
        if (minYear !== null && minMonth !== null && maxYear !== null && maxMonth !== null) {
            if (selectedYear < minYear ||
                (selectedYear === minYear && selectedMonth < minMonth) ||
                selectedYear > maxYear ||
                (selectedYear === maxYear && selectedMonth > maxMonth)) {
                return true;
            }
            return false;
        }
        // Solo máximo definido
        if (maxYear !== null && maxMonth !== null) {
            if (selectedYear > maxYear || (selectedYear === maxYear && selectedMonth > maxMonth)) {
                return true;
            }
        }
        // Solo mínimo definido
        if (minYear !== null && minMonth !== null) {
            if (selectedYear < minYear || (selectedYear === minYear && selectedMonth < minMonth)) {
                return true;
            }
        }
        return false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderMonthsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderMonthsComponent, isStandalone: false, selector: "datepicker-render-months", ngImport: i0, template: "<div class=\"calendar__months\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  @for (month of renderedMonths$$(); track month.id; let index = $index) {\n    <div\n      class=\"calendar__month\"\n      [ngClass]=\"{\n        'calendar__month--selected': isSelectedMonth$$()(month.id),\n        'calendar__month--current': isCurrentMonth$$()(month.id),\n        'calendar__month--disabled': isDisabledMonth$$()(month),\n      }\"\n      (click)=\"onSelectedMonth(month)\"\n    >\n      {{ month.name }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderMonthsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-months', template: "<div class=\"calendar__months\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  @for (month of renderedMonths$$(); track month.id; let index = $index) {\n    <div\n      class=\"calendar__month\"\n      [ngClass]=\"{\n        'calendar__month--selected': isSelectedMonth$$()(month.id),\n        'calendar__month--current': isCurrentMonth$$()(month.id),\n        'calendar__month--disabled': isDisabledMonth$$()(month),\n      }\"\n      (click)=\"onSelectedMonth(month)\"\n    >\n      {{ month.name }}\n    </div>\n  }\n</div>\n" }]
        }] });

class DatepickerRenderYearsComponent {
    dateService = inject(FreyDatePickerService, { skipSelf: true });
    isSelectedYear(year) {
        if (!this.dateService.validSelectedDate()) {
            return false;
        }
        return this.dateService.selectedYear$$() === year;
    }
    isCurrentYear(year) {
        return this.dateService.currentYear === year;
    }
    isDisabledYear(year) {
        if (!this.dateService.isOpen$$()) {
            return false;
        }
        return this.isValidMinMaxYear(year);
    }
    async onSelectedYear(year) {
        if (this.isDisabledYear(year)) {
            return;
        }
        await wait$1(1);
        this.dateService.prevSelectedYear$$.set(year);
        this.dateService.statusCalendar$$.set('months');
    }
    isValidMinMaxYear(year) {
        const minDate = this.dateService.minDate
            ? new Date(this.dateService.minDate).getFullYear()
            : null;
        const maxDate = this.dateService.maxDate
            ? new Date(this.dateService.maxDate).getFullYear()
            : null;
        return (minDate && year < minDate) || (maxDate && year > maxDate);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderYearsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: DatepickerRenderYearsComponent, isStandalone: false, selector: "datepicker-render-years", ngImport: i0, template: "<div class=\"calendar__years\">\n  @for (year of dateService.yearsToRender$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__year\"\n      [ngClass]=\"{\n        'calendar__year--selected': isSelectedYear(year),\n        'calendar__year--current': isCurrentYear(year),\n        'calendar__year--disabled': isDisabledYear(year),\n      }\"\n      (click)=\"onSelectedYear(year)\"\n    >\n      {{ year }}\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: DatepickerRenderYearsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'datepicker-render-years', template: "<div class=\"calendar__years\">\n  @for (year of dateService.yearsToRender$$(); track $index; let index = $index) {\n    <div\n      class=\"calendar__year\"\n      [ngClass]=\"{\n        'calendar__year--selected': isSelectedYear(year),\n        'calendar__year--current': isCurrentYear(year),\n        'calendar__year--disabled': isDisabledYear(year),\n      }\"\n      (click)=\"onSelectedYear(year)\"\n    >\n      {{ year }}\n    </div>\n  }\n</div>\n" }]
        }] });

class FreyDatepickerComponent {
    calendar;
    startView = 'multi-year';
    calendarfilter;
    positionY$$ = signal(0, ...(ngDevMode ? [{ debugName: "positionY$$" }] : []));
    positionX$$ = signal(0, ...(ngDevMode ? [{ debugName: "positionX$$" }] : []));
    positionCalendar$$ = computed(() => {
        return `top: ${this.positionY$$()}px; left: ${this.positionX$$()}px`;
    }, ...(ngDevMode ? [{ debugName: "positionCalendar$$" }] : []));
    isReadonly$$ = signal(false, ...(ngDevMode ? [{ debugName: "isReadonly$$" }] : []));
    dateService = inject(FreyDatePickerService);
    observer;
    removeClickListener;
    inputListener;
    keydownListener;
    renderer = inject(Renderer2);
    elementRef = inject(ElementRef);
    constructor() {
        this.dateService.startView$$.set(this.startView);
        this.dateService.initDate();
        this.removeClickListener = this.renderer.listen('document', 'click', (event) => this.onClick(event));
    }
    ngOnChanges(changes) {
        if (changes['startView']) {
            this.dateService.startView$$.set(this.startView);
        }
    }
    ngAfterViewInit() {
        this.dateService.calendarfilter = this.calendarfilter;
        this.inputListener = this.renderer.listen(this.dateService.inputElement, 'input', (event) => this.onInput(event));
        this.keydownListener = this.renderer.listen(this.dateService.inputElement, 'keydown', (event) => this.onKeyDown(event));
    }
    ngOnDestroy() {
        this.removeClickListener();
        if (this.observer) {
            this.observer.disconnect();
        }
        if (this.inputListener) {
            this.inputListener();
        }
        if (this.keydownListener) {
            this.keydownListener();
        }
    }
    async open() {
        if (this.isReadonly$$()) {
            return;
        }
        if (this.dateService.isOpen$$()) {
            return;
        }
        await wait$1(1);
        this.dateService.isOpen$$.update((counter) => (counter = !counter));
        this.setPositionCalendar();
    }
    async onWindowScroll() {
        if (!this.dateService.isOpen$$()) {
            return;
        }
        this.setPositionCalendar();
    }
    setTargetElement(input) {
        this.dateService.inputElement = input;
        this.dateService.minDate = isValidDateInstance(input.min) ? new Date(input.min) : null;
        this.dateService.maxDate = isValidDateInstance(input.max) ? new Date(input.max) : null;
        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes') {
                    if (mutation.attributeName === 'min') {
                        const min = this.dateService.inputElement.getAttribute('min');
                        if (isValidDateInstance(min)) {
                            this.dateService.minDate = new Date(min);
                        }
                        else {
                            this.dateService.minDate = null;
                        }
                    }
                    else if (mutation.attributeName === 'max') {
                        const max = this.dateService.inputElement.getAttribute('max');
                        if (isValidDateInstance(max)) {
                            this.dateService.maxDate = new Date(max);
                        }
                        else {
                            this.dateService.maxDate = null;
                        }
                    }
                }
            });
        });
        this.observer.observe(this.dateService.inputElement, {
            attributes: true,
        });
    }
    onClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.dateService.isOpen$$.set(false);
            this.dateService.clearAuxData();
            if (this.dateService.cacheSelectedDate) {
                this.dateService.initDate(this.dateService.cacheSelectedDate);
            }
            else {
                this.dateService.initDate();
            }
            if (this.dateService.startView$$() === 'multi-year') {
                this.dateService.statusCalendar$$.set('years');
                return;
            }
            this.dateService.statusCalendar$$.set('days');
            return;
        }
    }
    onInput(event) {
        const input = event.target;
        const originalPosition = input.selectionStart || 0;
        const rawValue = input.value.replace(/[^\d]/g, '');
        const formattedValue = formatRawDateInput(rawValue);
        const previousValue = input.value;
        const diff = formattedValue.length - previousValue.length;
        input.value = formattedValue;
        let newCursorPosition = originalPosition;
        if (diff > 0 && formattedValue[newCursorPosition - 1] === '/') {
            newCursorPosition += 1;
        }
        else if (diff < 0) {
            newCursorPosition -= 1;
        }
        newCursorPosition = Math.max(0, Math.min(newCursorPosition, formattedValue.length));
        input.setSelectionRange(newCursorPosition, newCursorPosition);
        if (input.value.length === 0) {
            this.resetControlValue();
            this.dateService.clearAuxData();
            this.dateService.cacheSelectedDate = null;
            this.dateService.calendarChange$$.update(null);
        }
        if (input.value.length === 10) {
            this.dateService.isValidDate(input.value);
            if (this.dateService.isDateValid) {
                this.dateService.calendarChange$$.update(parseDateDDMMYYYY(input.value));
                if (this.dateService.inputElementControl) {
                    this.dateService.inputElementControl.setValue(parseDateDDMMYYYY(input.value), {
                        emitEvent: false,
                        emitModelToViewChange: false,
                    });
                }
                this.dateService.selectedDate$$.set(parseDateDDMMYYYY(input.value));
                this.dateService.cacheSelectedDate = parseDateDDMMYYYY(input.value);
                this.dateService.initDate(this.dateService.selectedDate$$());
            }
            else {
                this.resetControlValue();
            }
        }
        else {
            this.resetControlValue();
        }
    }
    onKeyDown(event) {
        const allowedKeys = ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'];
        if (!/\d/.test(event.key) && !allowedKeys.includes(event.key)) {
            event.preventDefault();
        }
    }
    resetControlValue() {
        if (this.dateService.inputElementControl) {
            this.dateService.inputElementControl.setValue(null, {
                emitEvent: false,
                emitModelToViewChange: false,
            });
            this.dateService.inputElementControl.setErrors({
                error: 'La fecha es inválida',
            });
            this.dateService.inputElementControl.markAsTouched();
        }
    }
    async setPositionCalendar() {
        const elementInputHost = this.dateService.inputElement;
        const inputElement = elementInputHost.getBoundingClientRect();
        const { height } = getSizeElementDisplayNone(this.calendar.nativeElement);
        this.positionY$$.set(inputElement.top + inputElement.height + 5);
        this.positionX$$.set(inputElement.left);
        await wait$1(1);
        const calendarRect = this.calendar.nativeElement.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const isFullyVisible = calendarRect.top >= 0 && calendarRect.bottom <= viewportHeight;
        if (!isFullyVisible) {
            const inputHeight = this.dateService.inputElement.getBoundingClientRect().height;
            this.positionY$$.set(inputElement.top - height - inputHeight);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyDatepickerComponent, isStandalone: false, selector: "frey-datepicker", inputs: { startView: "startView", calendarfilter: "calendarfilter" }, host: { listeners: { "window:scroll": "onWindowScroll()" } }, providers: [FreyDatePickerService], viewQueries: [{ propertyName: "calendar", first: true, predicate: ["calendar"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  #calendar\n  class=\"calendar\"\n  [style]=\"positionCalendar$$()\"\n  [ngClass]=\"{ 'calendar--active': dateService.isOpen$$() }\"\n>\n  <datepicker-controls></datepicker-controls>\n\n  @switch (dateService.statusCalendar$$()) {\n    @case ('days') {\n      <datepicker-render-days></datepicker-render-days>\n    }\n\n    @case ('years') {\n      <datepicker-render-years></datepicker-render-years>\n    }\n    @default {\n      <datepicker-render-months></datepicker-render-months>\n    }\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: DatepickerRenderDaysComponent, selector: "datepicker-render-days" }, { kind: "component", type: DatepickerRenderMonthsComponent, selector: "datepicker-render-months" }, { kind: "component", type: DatepickerRenderYearsComponent, selector: "datepicker-render-years" }, { kind: "component", type: DatepickerControlsComponent, selector: "datepicker-controls" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-datepicker', providers: [FreyDatePickerService], template: "<div\n  #calendar\n  class=\"calendar\"\n  [style]=\"positionCalendar$$()\"\n  [ngClass]=\"{ 'calendar--active': dateService.isOpen$$() }\"\n>\n  <datepicker-controls></datepicker-controls>\n\n  @switch (dateService.statusCalendar$$()) {\n    @case ('days') {\n      <datepicker-render-days></datepicker-render-days>\n    }\n\n    @case ('years') {\n      <datepicker-render-years></datepicker-render-years>\n    }\n    @default {\n      <datepicker-render-months></datepicker-render-months>\n    }\n  }\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { calendar: [{
                type: ViewChild,
                args: ['calendar']
            }], startView: [{
                type: Input
            }], calendarfilter: [{
                type: Input
            }], onWindowScroll: [{
                type: HostListener,
                args: ['window:scroll', []]
            }] } });

class FreyDatepickerInputDirective extends FreyControlValueAccessor$1 {
    locale = 'es-ES';
    picker;
    calendarChange = new EventEmitter();
    ngControl = inject(NgControl, { self: true, optional: true });
    elementRef = inject(ElementRef);
    calendarControlAux = new FormControl(null);
    subscription = new Subscription();
    get calendarControl() {
        return this.ngControl?.control || this.calendarControlAux;
    }
    get isReadonly() {
        return (this.elementRef.nativeElement.hasAttribute('readonly') ||
            this.elementRef.nativeElement.readOnly === true);
    }
    constructor() {
        super();
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(changes) {
        if (changes['locale'] && this.picker) {
            this.picker.dateService.locale$$.set(this.locale);
        }
    }
    ngAfterViewInit() {
        if (this.picker) {
            this.picker['setTargetElement'](this.elementRef.nativeElement);
            this.subscription.add(this.picker.dateService.calendarChange$$.$observable.subscribe((response) => {
                this.calendarChange.emit(response);
            }));
            if (this.isReadonly) {
                this.picker.isReadonly$$.set(true);
            }
        }
        else {
            console.error('El componente datepicker no se encuentra.');
        }
        if (this.calendarControl) {
            this.picker.dateService.inputElementControl = this.calendarControl;
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    writeValue(value) {
        if (!value) {
            this.elementRef.nativeElement.value = '';
            return;
        }
        if (value instanceof Date && !isNaN(value.getTime())) {
            this.elementRef.nativeElement.value = formatDateDDMMYYYY(value);
            const dateService = this.picker.dateService;
            if (this.picker) {
                dateService.selectedDate$$.set(new Date(value));
                dateService.cacheSelectedDate = new Date(value);
                dateService.initDate(dateService.selectedDate$$());
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    onBlur(event) {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerInputDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyDatepickerInputDirective, isStandalone: false, selector: "[freyDatepicker]", inputs: { locale: "locale", picker: ["freyDatepicker", "picker"] }, outputs: { calendarChange: "calendarChange" }, host: { listeners: { "blur": "onBlur($event)" } }, usesInheritance: true, usesOnChanges: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerInputDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyDatepicker]',
                }]
        }], ctorParameters: () => [], propDecorators: { locale: [{
                type: Input
            }], picker: [{
                type: Input,
                args: ['freyDatepicker']
            }], calendarChange: [{
                type: Output
            }], onBlur: [{
                type: HostListener,
                args: ['blur', ['$event']]
            }] } });

const COMPONENTS$1 = [
    FreyDatepickerComponent,
    DatepickerRenderDaysComponent,
    DatepickerRenderMonthsComponent,
    DatepickerRenderYearsComponent,
    DatepickerControlsComponent,
];
const DIRECTIVES$1 = [FreyDatepickerInputDirective];
class FreyDatepickerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, declarations: [FreyDatepickerComponent,
            DatepickerRenderDaysComponent,
            DatepickerRenderMonthsComponent,
            DatepickerRenderYearsComponent,
            DatepickerControlsComponent, FreyDatepickerInputDirective], imports: [NgClass, AsyncPipe], exports: [FreyDatepickerComponent, FreyDatepickerInputDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyDatepickerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NgClass, AsyncPipe],
                    declarations: [COMPONENTS$1, DIRECTIVES$1],
                    exports: [FreyDatepickerComponent, DIRECTIVES$1],
                }]
        }] });

class FreyErrorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyErrorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyErrorComponent, isStandalone: false, selector: "frey-error", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyErrorComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-error',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreyInputDirective extends FreyControlForm$1 {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyInputDirective, isStandalone: false, selector: "[freyInput]", usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyInput]',
                }]
        }] });

class FreyTextareaDirective extends FreyControlForm$1 {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTextareaDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyTextareaDirective, isStandalone: false, selector: "[freyTextarea]", usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTextareaDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: '[freyTextarea]',
                }]
        }] });

class FreyFieldComponent {
    requiredText = input('Campo requerido', ...(ngDevMode ? [{ debugName: "requiredText" }] : []));
    freyInput = contentChild(FreyInputDirective, ...(ngDevMode ? [{ debugName: "freyInput" }] : []));
    freyTextarea = contentChild(FreyTextareaDirective, ...(ngDevMode ? [{ debugName: "freyTextarea" }] : []));
    freySelect = contentChild(FreyFieldComponent, ...(ngDevMode ? [{ debugName: "freySelect" }] : []));
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isDisabled = computed(() => {
        return this.formControl()?.disabled;
    }, ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    ngAfterContentInit() {
        if (this.freyInput()) {
            this.formControl.set(this.freyInput()?.formControl());
            return;
        }
        if (this.freyTextarea()) {
            this.formControl.set(this.freyTextarea()?.formControl());
            return;
        }
        // if (this.jumSelect) {
        //   this.formControl$$ = signal(this.jumSelect.formControl);
        //   this.disableFromHTML$$ = this.jumSelect.disabled;
        // }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyFieldComponent, isStandalone: false, selector: "frey-field", inputs: { requiredText: { classPropertyName: "requiredText", publicName: "requiredText", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "freyInput", first: true, predicate: FreyInputDirective, descendants: true, isSignal: true }, { propertyName: "freyTextarea", first: true, predicate: FreyTextareaDirective, descendants: true, isSignal: true }, { propertyName: "freySelect", first: true, predicate: FreyFieldComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<section class=\"frey-field\">\n  <div class=\"frey-field__header\">\n    <ng-content select=\"frey-label\"></ng-content>\n    @if (isRequired()) {\n      <span class=\"frey-field__required\"> *</span>\n    }\n  </div>\n\n  <div class=\"frey-field__body\">\n    <div class=\"frey-field__control\">\n      <ng-content select=\"frey-prefix\"></ng-content>\n      <ng-content select=\"[freyInput], [freyTextarea], frey-select\"></ng-content>\n      <ng-content select=\"frey-suffix\"></ng-content>\n    </div>\n    <div class=\"frey-field__footer\">\n      <ng-content select=\"frey-hint\"></ng-content>\n\n      @if (\n        formControl() && formControl().invalid && (formControl().dirty || formControl().touched)\n      ) {\n        @if (formControl().errors?.required) {\n          <frey-error>{{ requiredText() }}</frey-error>\n        } @else {\n          <ng-content select=\"frey-error\"></ng-content>\n        }\n      }\n\n      @if (formControl() && formControl().valid) {\n        <ng-content select=\"frey-success\"></ng-content>\n      }\n    </div>\n  </div>\n</section>\n", dependencies: [{ kind: "component", type: FreyErrorComponent, selector: "frey-error" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-field', template: "<section class=\"frey-field\">\n  <div class=\"frey-field__header\">\n    <ng-content select=\"frey-label\"></ng-content>\n    @if (isRequired()) {\n      <span class=\"frey-field__required\"> *</span>\n    }\n  </div>\n\n  <div class=\"frey-field__body\">\n    <div class=\"frey-field__control\">\n      <ng-content select=\"frey-prefix\"></ng-content>\n      <ng-content select=\"[freyInput], [freyTextarea], frey-select\"></ng-content>\n      <ng-content select=\"frey-suffix\"></ng-content>\n    </div>\n    <div class=\"frey-field__footer\">\n      <ng-content select=\"frey-hint\"></ng-content>\n\n      @if (\n        formControl() && formControl().invalid && (formControl().dirty || formControl().touched)\n      ) {\n        @if (formControl().errors?.required) {\n          <frey-error>{{ requiredText() }}</frey-error>\n        } @else {\n          <ng-content select=\"frey-error\"></ng-content>\n        }\n      }\n\n      @if (formControl() && formControl().valid) {\n        <ng-content select=\"frey-success\"></ng-content>\n      }\n    </div>\n  </div>\n</section>\n" }]
        }], propDecorators: { requiredText: [{ type: i0.Input, args: [{ isSignal: true, alias: "requiredText", required: false }] }], freyInput: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyInputDirective), { isSignal: true }] }], freyTextarea: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyTextareaDirective), { isSignal: true }] }], freySelect: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyFieldComponent), { isSignal: true }] }] } });

class FreyHintComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHintComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyHintComponent, isStandalone: false, selector: "frey-hint", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHintComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-hint',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreyLabelComponent {
    labelText = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyLabelComponent, isStandalone: false, selector: "frey-label", host: { attributes: { "title": "labelText" } }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLabelComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-label',
                    template: `<ng-content></ng-content>`,
                    host: {
                        title: 'labelText',
                    },
                }]
        }] });

class FreyOptionComponent {
    description = viewChild('description', ...(ngDevMode ? [{ debugName: "description" }] : []));
    clickOption = output();
    value = input(...(ngDevMode ? [undefined, { debugName: "value" }] : []));
    isDisabled = input(false, ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    isSelected = signal(false, ...(ngDevMode ? [{ debugName: "isSelected" }] : []));
    isVisible = signal(true, ...(ngDevMode ? [{ debugName: "isVisible" }] : []));
    elementRef = inject(ElementRef);
    onClickOption() {
        if (this.isDisabled()) {
            return;
        }
        this.clickOption.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyOptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyOptionComponent, isStandalone: false, selector: "frey-option", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, isDisabled: { classPropertyName: "isDisabled", publicName: "isDisabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clickOption: "clickOption" }, viewQueries: [{ propertyName: "description", first: true, predicate: ["description"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"option\"\n  [ngClass]=\"{ 'option--hidden': !isVisible(), 'option--disabled': isDisabled() }\"\n  (click)=\"onClickOption()\"\n>\n  <div class=\"option__description\">\n    <span class=\"option__text\" #description><ng-content></ng-content></span>\n  </div>\n  @if (isSelected()) {\n    <svg\n      class=\"option__selected\"\n      aria-label=\"Seleccionado\"\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      focusable=\"false\"\n    >\n      <polyline\n        points=\"6.5,11 9,13.5 14,8.5\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyOptionComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-option', template: "<div\n  class=\"option\"\n  [ngClass]=\"{ 'option--hidden': !isVisible(), 'option--disabled': isDisabled() }\"\n  (click)=\"onClickOption()\"\n>\n  <div class=\"option__description\">\n    <span class=\"option__text\" #description><ng-content></ng-content></span>\n  </div>\n  @if (isSelected()) {\n    <svg\n      class=\"option__selected\"\n      aria-label=\"Seleccionado\"\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      focusable=\"false\"\n    >\n      <polyline\n        points=\"6.5,11 9,13.5 14,8.5\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  }\n</div>\n" }]
        }], propDecorators: { description: [{ type: i0.ViewChild, args: ['description', { isSignal: true }] }], clickOption: [{ type: i0.Output, args: ["clickOption"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], isDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isDisabled", required: false }] }] } });

class FreyPrefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPrefix, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreyPrefix, isStandalone: false, selector: "frey-prefix", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPrefix, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-prefix',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreySelectComponent extends FreyControlValueAccessor$1 {
    freyOptions = contentChildren(FreyOptionComponent, ...(ngDevMode ? [{ debugName: "freyOptions" }] : []));
    searchInput = viewChild('searchInput', ...(ngDevMode ? [{ debugName: "searchInput" }] : []));
    searchInputBackend = viewChild('searchInputBackend', ...(ngDevMode ? [{ debugName: "searchInputBackend" }] : []));
    typeSearch = input('none', ...(ngDevMode ? [{ debugName: "typeSearch" }] : []));
    backendSearchDebounceMs = input(1000, ...(ngDevMode ? [{ debugName: "backendSearchDebounceMs" }] : []));
    readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    placeholder = input('Seleccione una opción', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    selectionChange = output();
    backendSearchQuery = output();
    currentText = signal(null, ...(ngDevMode ? [{ debugName: "currentText" }] : []));
    currentValue = signal(null, ...(ngDevMode ? [{ debugName: "currentValue" }] : []));
    isSelectOpen = signal(false, ...(ngDevMode ? [{ debugName: "isSelectOpen" }] : []));
    searchBackendValue = signal('', ...(ngDevMode ? [{ debugName: "searchBackendValue" }] : []));
    formControl;
    debouncedBackendSearchQuery = signal('', ...(ngDevMode ? [{ debugName: "debouncedBackendSearchQuery" }] : []));
    lastEmittedBackendSearchQuery = '';
    injector = inject(Injector);
    elementRef = inject(ElementRef);
    constructor() {
        super();
        this.subscribeToOptionClicks();
        this.setupBackendSearch();
    }
    ngAfterContentInit() {
        const ngControl = this.injector.get(NgControl, null);
        if (ngControl?.control) {
            this.formControl = ngControl.control;
        }
    }
    selected() {
        if (this.disabled() || this.readonly()) {
            return;
        }
        this.isSelectOpen.set(!this.isSelectOpen());
        if (this.isSelectOpen()) {
            this.setPositionScroll();
        }
        if (this.isSelectOpen() && this.typeSearch() === 'frontend') {
            setTimeout(() => {
                this.searchInput().nativeElement.focus();
            }, 0);
        }
        else if (this.isSelectOpen() && this.typeSearch() === 'backend') {
            setTimeout(() => {
                this.searchInputBackend().nativeElement.focus();
            }, 0);
        }
    }
    onTouchedFn() {
        if (this.readonly()) {
            return;
        }
        this.onTouched();
    }
    writeValue(value) {
        this.currentValue.set(value);
        if (this.isNullOrUndefined(value)) {
            this.currentText.set(null);
            return;
        }
        if (this.freyOptions?.length) {
            this.setSelectedOption();
        }
    }
    onSearch() {
        const cleanedSearchTerm = this.normalizeText(this.searchInput().nativeElement.value.trim());
        this.freyOptions().forEach((option) => {
            const optionText = this.normalizeText(option?.description()?.nativeElement?.textContent || '');
            if (!optionText.includes(cleanedSearchTerm)) {
                option.isVisible.set(false);
            }
            else {
                option.isVisible.set(true);
            }
        });
        if (!cleanedSearchTerm) {
            this.setPositionScroll();
        }
    }
    onClearValues() {
        if (this.readonly()) {
            return;
        }
        this.resetOptions();
        this.isSelectOpen.set(false);
        this.currentText.set(null);
        this.currentValue.set(null);
        this.onChange(null);
        this.selectionChange.emit(null);
    }
    isNullOrUndefined(data) {
        return data === null || data === undefined ? true : false || data === '';
    }
    onClick(targetElement) {
        const clickedInside = this.elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.isSelectOpen.set(false);
        }
    }
    setPositionScroll() {
        const value = this.freyOptions().find((option) => this.currentValue() === option.value());
        if (value) {
            setTimeout(() => {
                value['elementRef'].nativeElement.scrollIntoView({
                    behavior: 'instant',
                    block: 'nearest',
                });
            }, 0);
        }
    }
    setupBackendSearch() {
        effect((onCleanup) => {
            const value = this.searchBackendValue();
            const timeout = setTimeout(() => {
                if (value !== this.lastEmittedBackendSearchQuery) {
                    this.lastEmittedBackendSearchQuery = value;
                    this.debouncedBackendSearchQuery.set(value);
                }
            }, this.backendSearchDebounceMs());
            onCleanup(() => clearTimeout(timeout));
        });
        effect(() => {
            if (this.typeSearch() === 'none') {
                return;
            }
            const value = this.debouncedBackendSearchQuery();
            this.backendSearchQuery.emit(value);
        });
    }
    subscribeToOptionClicks() {
        effect((onCleanup) => {
            const subs = this.freyOptions().map((option) => option.clickOption.subscribe(() => {
                this.optionClicked(option);
            }));
            if (this.currentValue() !== null) {
                this.setSelectedOption();
            }
            onCleanup(() => {
                subs.forEach((sub) => sub.unsubscribe());
            });
        });
    }
    optionClicked(option) {
        if (this.disabled()) {
            return;
        }
        this.resetOptions();
        this.isSelectOpen.set(false);
        this.currentText.set(option.description()?.nativeElement.innerText);
        this.currentValue.set(option.value());
        option.isSelected.set(true);
        this.onChange(option.value());
        this.selectionChange.emit(option.value());
        if (this.typeSearch() === 'frontend' && this.searchInput) {
            this.searchInput().nativeElement.value = null;
        }
    }
    setSelectedOption() {
        const selectedOption = this.freyOptions().find((option) => option.value() === this.currentValue());
        if (selectedOption) {
            this.optionClicked(selectedOption);
        }
    }
    resetOptions() {
        if (this.freyOptions()) {
            this.freyOptions().forEach((option) => {
                option.isSelected.set(false);
                option.isVisible.set(true);
            });
        }
    }
    normalizeText(text) {
        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreySelectComponent, isStandalone: false, selector: "frey-select", inputs: { typeSearch: { classPropertyName: "typeSearch", publicName: "typeSearch", isSignal: true, isRequired: false, transformFunction: null }, backendSearchDebounceMs: { classPropertyName: "backendSearchDebounceMs", publicName: "backendSearchDebounceMs", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", backendSearchQuery: "backendSearchQuery" }, host: { listeners: { "document:click": "onClick($event.target)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreySelectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "freyOptions", predicate: FreyOptionComponent, isSignal: true }], viewQueries: [{ propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }, { propertyName: "searchInputBackend", first: true, predicate: ["searchInputBackend"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"select\"\n  [ngClass]=\"{\n    'select--active': isSelectOpen(),\n    'select--readonly': readonly(),\n  }\"\n  (click)=\"onTouchedFn()\"\n  (keydown)=\"onTouchedFn()\"\n  [title]=\"currentText() || ''\"\n>\n  <div class=\"select__header\" (click)=\"selected()\" (keydown)=\"selected()\">\n    @if (isNullOrUndefined(currentValue())) {\n      <span class=\"select__placeholder\">{{ placeholder() }}</span>\n      <svg\n        class=\"select__arrow\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        focusable=\"false\"\n        (click)=\"onClearValues()\"\n      >\n        <polyline\n          points=\"6 8 10 12 14 8\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          fill=\"none\"\n        />\n      </svg>\n    } @else {\n      <span class=\"select__value\">{{ currentText() }}</span>\n      @if (!readonly()) {\n        <svg\n          (click)=\"onClearValues()\"\n          class=\"select__clear\"\n          aria-label=\"Limpiar selecci\u00F3n\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <line\n            x1=\"6\"\n            y1=\"6\"\n            x2=\"14\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n          <line\n            x1=\"14\"\n            y1=\"6\"\n            x2=\"6\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n    }\n  </div>\n\n  <div class=\"select__options\">\n    @if (typeSearch() === 'frontend') {\n      <input type=\"text\" class=\"select__search\" (input)=\"onSearch()\" #searchInput />\n    }\n    @if (typeSearch() === 'backend') {\n      <div class=\"select__search-container\">\n        <svg\n          class=\"select__search-icon\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <!-- Database shape -->\n          <ellipse\n            cx=\"10\"\n            cy=\"6\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <path\n            d=\"M4 6v6c0 1.66 2.69 3 6 3s6-1.34 6-3V6\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <ellipse\n            cx=\"10\"\n            cy=\"12\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <!-- Magnifier glass -->\n          <circle cx=\"15.5\" cy=\"15.5\" r=\"2\" stroke=\"currentColor\" stroke-width=\"1.5\" fill=\"none\" />\n          <line\n            x1=\"17\"\n            y1=\"17\"\n            x2=\"18.5\"\n            y2=\"18.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n        <input\n          type=\"text\"\n          class=\"select__search--backend\"\n          #searchInputBackend\n          placeholder=\"Escriba un t\u00E9rmino para consultar.\"\n          (input)=\"searchBackendValue.set($any($event.target).value)\"\n        />\n      </div>\n    }\n    <ng-content select=\"frey-option\"></ng-content>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-select', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreySelectComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"select\"\n  [ngClass]=\"{\n    'select--active': isSelectOpen(),\n    'select--readonly': readonly(),\n  }\"\n  (click)=\"onTouchedFn()\"\n  (keydown)=\"onTouchedFn()\"\n  [title]=\"currentText() || ''\"\n>\n  <div class=\"select__header\" (click)=\"selected()\" (keydown)=\"selected()\">\n    @if (isNullOrUndefined(currentValue())) {\n      <span class=\"select__placeholder\">{{ placeholder() }}</span>\n      <svg\n        class=\"select__arrow\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        focusable=\"false\"\n        (click)=\"onClearValues()\"\n      >\n        <polyline\n          points=\"6 8 10 12 14 8\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          fill=\"none\"\n        />\n      </svg>\n    } @else {\n      <span class=\"select__value\">{{ currentText() }}</span>\n      @if (!readonly()) {\n        <svg\n          (click)=\"onClearValues()\"\n          class=\"select__clear\"\n          aria-label=\"Limpiar selecci\u00F3n\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <line\n            x1=\"6\"\n            y1=\"6\"\n            x2=\"14\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n          <line\n            x1=\"14\"\n            y1=\"6\"\n            x2=\"6\"\n            y2=\"14\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n    }\n  </div>\n\n  <div class=\"select__options\">\n    @if (typeSearch() === 'frontend') {\n      <input type=\"text\" class=\"select__search\" (input)=\"onSearch()\" #searchInput />\n    }\n    @if (typeSearch() === 'backend') {\n      <div class=\"select__search-container\">\n        <svg\n          class=\"select__search-icon\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          focusable=\"false\"\n        >\n          <!-- Database shape -->\n          <ellipse\n            cx=\"10\"\n            cy=\"6\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <path\n            d=\"M4 6v6c0 1.66 2.69 3 6 3s6-1.34 6-3V6\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <ellipse\n            cx=\"10\"\n            cy=\"12\"\n            rx=\"6\"\n            ry=\"3\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            fill=\"none\"\n          />\n          <!-- Magnifier glass -->\n          <circle cx=\"15.5\" cy=\"15.5\" r=\"2\" stroke=\"currentColor\" stroke-width=\"1.5\" fill=\"none\" />\n          <line\n            x1=\"17\"\n            y1=\"17\"\n            x2=\"18.5\"\n            y2=\"18.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n        <input\n          type=\"text\"\n          class=\"select__search--backend\"\n          #searchInputBackend\n          placeholder=\"Escriba un t\u00E9rmino para consultar.\"\n          (input)=\"searchBackendValue.set($any($event.target).value)\"\n        />\n      </div>\n    }\n    <ng-content select=\"frey-option\"></ng-content>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { freyOptions: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => FreyOptionComponent), { isSignal: true }] }], searchInput: [{ type: i0.ViewChild, args: ['searchInput', { isSignal: true }] }], searchInputBackend: [{ type: i0.ViewChild, args: ['searchInputBackend', { isSignal: true }] }], typeSearch: [{ type: i0.Input, args: [{ isSignal: true, alias: "typeSearch", required: false }] }], backendSearchDebounceMs: [{ type: i0.Input, args: [{ isSignal: true, alias: "backendSearchDebounceMs", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], backendSearchQuery: [{ type: i0.Output, args: ["backendSearchQuery"] }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event.target']]
            }] } });

class FreySuccessComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuccessComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreySuccessComponent, isStandalone: false, selector: "frey-success", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuccessComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-success',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

class FreySuffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuffix, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: FreySuffix, isStandalone: false, selector: "frey-suffix", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreySuffix, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/prefer-standalone
                    standalone: false,
                    selector: 'frey-suffix',
                    template: `<ng-content></ng-content>`,
                }]
        }] });

const COMPONENTS = [
    FreyErrorComponent,
    FreyFieldComponent,
    FreyHintComponent,
    FreyLabelComponent,
    FreyPrefix,
    FreySuccessComponent,
    FreySuffix,
    FreyOptionComponent,
    FreySelectComponent,
];
const DIRECTIVES = [FreyInputDirective, FreyTextareaDirective];
class FreyFormModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, declarations: [FreyErrorComponent,
            FreyFieldComponent,
            FreyHintComponent,
            FreyLabelComponent,
            FreyPrefix,
            FreySuccessComponent,
            FreySuffix,
            FreyOptionComponent,
            FreySelectComponent, FreyInputDirective, FreyTextareaDirective], imports: [NgClass], exports: [FreyErrorComponent,
            FreyFieldComponent,
            FreyHintComponent,
            FreyLabelComponent,
            FreyPrefix,
            FreySuccessComponent,
            FreySuffix,
            FreyOptionComponent,
            FreySelectComponent, FreyInputDirective, FreyTextareaDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [NgClass],
                    declarations: [COMPONENTS, DIRECTIVES],
                    exports: [COMPONENTS, DIRECTIVES],
                }]
        }] });

/**
 * Public API Surface of Freya UI Library
 * Primero deben ir las clases globales o compartidas
 */
// Clases

/**
 * Generated bundle index. Do not edit.
 */

export { FreyButtonDirective, FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyControlForm, FreyControlValueAccessor, FreyDatepickerComponent, FreyDatepickerInputDirective, FreyDatepickerModule, FreyErrorComponent, FreyFieldComponent, FreyFormModule, FreyHeaderCellDefDirective, FreyHintComponent, FreyInputDirective, FreyLabelComponent, FreyOptionComponent, FreyPaginatorComponent, FreyPrefix, FreySelectComponent, FreySuccessComponent, FreySuffix, FreyTableComponent, FreyTextareaDirective, FreyTimepickerComponent, SubjectState, getRequestAsync, isDefined, isNullOrUndefined, wait };
//# sourceMappingURL=freya.mjs.map
