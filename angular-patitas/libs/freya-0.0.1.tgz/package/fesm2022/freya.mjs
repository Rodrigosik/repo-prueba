import * as i0 from '@angular/core';
import { signal, computed, inject, effect, Directive, HostBinding, Input, input, output, Component, TemplateRef, ElementRef, Renderer2, contentChild, contentChildren, model } from '@angular/core';
import { Validators, NgControl } from '@angular/forms';
import { Subscription, Subject, firstValueFrom, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import { NgTemplateOutlet } from '@angular/common';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
class FreyControlForm {
    formControl = signal(null, ...(ngDevMode ? [{ debugName: "formControl" }] : []));
    disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) ?? false, ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    isValid = computed(() => this.formControl()?.valid ?? true, ...(ngDevMode ? [{ debugName: "isValid" }] : []));
    isInvalid = computed(() => this.formControl()?.invalid ?? false, ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    isTouched = computed(() => this.formControl()?.touched ?? false, ...(ngDevMode ? [{ debugName: "isTouched" }] : []));
    errors = computed(() => this.formControl()?.errors ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : []));
    ngControl = inject(NgControl, { optional: true });
    subscription = new Subscription();
    constructor() {
        // Sincronizar el estado de disabled cuando cambie el control
        effect(() => {
            const ctrl = this.formControl();
            if (ctrl) {
                this.disabled.set(ctrl.disabled);
            }
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    ngAfterContentInit() {
        if (this.ngControl?.control) {
            const ctrl = this.ngControl.control;
            this.formControl.set(ctrl);
            this.subscription.add(
            // Suscribirse a cambios de estado del control
            ctrl.statusChanges?.subscribe(() => {
                // Forzar re-evaluación de computeds
                this.formControl.set(ctrl);
            }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyControlForm, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyControlForm, decorators: [{
            type: Directive,
            args: [{}]
        }], ctorParameters: () => [] });

class FreyControlValueAccessor {
    writeValue(value) { }
    onChange = () => { };
    registerOnChange(fn) {
        this.onChange = fn;
    }
    onTouched = () => { };
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) { }
}

class SubjectState {
    $observable;
    _subject;
    constructor() {
        this._subject = new Subject();
        this.$observable = this._subject.asObservable();
    }
    update(value) {
        this._subject.next(value);
    }
    complete() {
        this._subject.complete();
    }
    error(error) {
        this._subject.error(error);
    }
}

const wait = (ms) => firstValueFrom(timer(ms).pipe(map(() => undefined)));
const getRequestAsync = async (request) => {
    try {
        const data = await firstValueFrom(request);
        return { status: true, data };
    }
    catch (error) {
        return { status: false, error };
    }
};

const isNullOrUndefined = (data) => {
    return data === null || data === undefined ? true : false || data === '';
};
const isDefined = (data) => {
    return data !== null && data !== undefined;
};

/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant = 'solid';
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color = 'primary';
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size = 'medium';
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading = false;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled = false;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular = false;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly = false;
    /**
     * Clases computadas para el host
     */
    get hostClasses() {
        const classes = ['frey-button'];
        // Variante
        if (this.variant !== 'solid') {
            classes.push(`frey-button--${this.variant}`);
        }
        // Color
        classes.push(`frey-button--${this.color}`);
        // Tamaño
        if (this.size !== 'medium') {
            classes.push(`frey-button--${this.size}`);
        }
        // Estados
        if (this.loading) {
            classes.push('frey-button--loading');
        }
        if (this.disabled) {
            classes.push('frey-button--disabled');
        }
        // Modificadores
        if (this.circular) {
            classes.push('frey-button--circular');
        }
        if (this.iconOnly) {
            classes.push('frey-button--icon-only');
        }
        return classes.join(' ');
    }
    /**
     * Atributo disabled del botón
     */
    get isDisabled() {
        return this.disabled || this.loading ? true : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyButtonDirective, isStandalone: true, selector: "[freyButton]", inputs: { variant: "variant", color: "color", size: "size", loading: "loading", disabled: "disabled", circular: "circular", iconOnly: "iconOnly" }, host: { attributes: { "type": "button" }, properties: { "class": "this.hostClasses", "attr.disabled": "this.isDisabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyButton]',
                    standalone: true,
                    host: {
                        type: 'button',
                    },
                }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], loading: [{
                type: Input
            }], disabled: [{
                type: Input
            }], circular: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], isDisabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

/**
 * Componente Paginador para Freya UI.
 *
 * Este componente proporciona controles de paginación para navegar a través de una colección de elementos.
 * Permite al usuario ver el número total de elementos, el número de elementos por página,
 * y navegar entre páginas utilizando botones de "anterior", "siguiente" y números de página.
 *
 * Los estilos son completamente opcionales.
 * Para usar los estilos por defecto:
 * @import 'freya/styles/paginator/paginator.scss';
 *
 * @example
 * ```html
 * <frey-paginator
 *   [totalItems]="100"
 *   [itemsPerPage]="10"
 *   [currentPage]="1"
 *   (pageChange)="onPageChange($event)"
 *   (itemsPerPageChange)="onItemsPerPageChange($event)"
 * ></frey-paginator>
 * ```
 */
class FreyPaginatorComponent {
    /**
     * El número total de elementos en la colección.
     */
    totalItems = input.required(...(ngDevMode ? [{ debugName: "totalItems" }] : []));
    /**
     * El número de elementos a mostrar por página.
     * Por defecto es 10.
     */
    itemsPerPage = input(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    /**
     * La página actual seleccionada.
     * Por defecto es 1.
     */
    currentPage = input(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    /**
     * Evento emitido cuando la página cambia.
     * Emite el nuevo número de página.
     */
    pageChange = output();
    /**
     * Evento emitido cuando cambia el número de elementos por página.
     * Emite el nuevo valor de elementos por página.
     */
    itemsPerPageChange = output();
    /** Señal interna para el estado mutable de currentPage */
    _currentPage = signal(1, ...(ngDevMode ? [{ debugName: "_currentPage" }] : []));
    /** Señal interna para el estado mutable de itemsPerPage */
    _itemsPerPage = signal(this.itemsPerPage(), ...(ngDevMode ? [{ debugName: "_itemsPerPage" }] : []));
    /** El número total de páginas calculadas. */
    totalPages = computed(() => Math.ceil(this.totalItems() / this._itemsPerPage()), ...(ngDevMode ? [{ debugName: "totalPages" }] : []));
    /** Array de números de página visibles en los controles. */
    visiblePages = computed(() => this.generateVisiblePages(this._currentPage(), this.totalPages()), ...(ngDevMode ? [{ debugName: "visiblePages" }] : []));
    constructor() {
        // Sincronizar la señal interna con el input
        effect(() => this._currentPage.set(this.currentPage()));
        effect(() => this._itemsPerPage.set(this.itemsPerPage()));
        // Validar y ajustar currentPage si es necesario
        effect(() => {
            if (this._currentPage() > this.totalPages() && this.totalPages() > 0) {
                this._currentPage.set(this.totalPages());
                this.pageChange.emit(this.totalPages());
            }
            else if (this._currentPage() < 1 && this.totalPages() > 0) {
                this._currentPage.set(1);
                this.pageChange.emit(1);
            }
        });
    }
    /**
     * Navega a la página especificada.
     * @param page El número de página al que navegar.
     */
    goToPage(page) {
        if (page >= 1 && page <= this.totalPages() && page !== this._currentPage()) {
            this._currentPage.set(page);
            this.pageChange.emit(page);
        }
    }
    /**
     * Navega a la página anterior.
     */
    prevPage() {
        if (this._currentPage() > 1) {
            this.goToPage(this._currentPage() - 1);
        }
    }
    /**
     * Navega a la página siguiente.
     */
    nextPage() {
        if (this._currentPage() < this.totalPages()) {
            this.goToPage(this._currentPage() + 1);
        }
    }
    /**
     * Actualiza el número de elementos por página basado en la entrada del usuario.
     * @param value El nuevo valor de elementos por página.
     */
    updateItemsPerPage(value) {
        const parsedValue = parseInt(value, 10);
        if (!isNaN(parsedValue) && parsedValue > 0) {
            this._itemsPerPage.set(parsedValue); // Actualizar la señal interna
            this.itemsPerPageChange.emit(parsedValue);
            this.pageChange.emit(this._currentPage());
        }
    }
    /**
     * Genera un array de números de página para mostrar en los controles.
     * @param currentPage La página actual.
     * @param totalPages El número total de páginas.
     * @returns Un array de números de página visibles.
     */
    generateVisiblePages(currentPage, totalPages) {
        const pages = [];
        const maxPagesToShow = 5; // Número máximo de páginas a mostrar directamente
        if (totalPages <= maxPagesToShow) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        }
        else {
            let startPage;
            let endPage;
            if (currentPage <= Math.floor(maxPagesToShow / 2) + 1) {
                startPage = 1;
                endPage = maxPagesToShow - 1;
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
            else if (currentPage >= totalPages - Math.floor(maxPagesToShow / 2)) {
                startPage = totalPages - maxPagesToShow + 2;
                endPage = totalPages;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
            }
            else {
                startPage = currentPage - Math.floor(maxPagesToShow / 2) + 1;
                endPage = currentPage + Math.floor(maxPagesToShow / 2) - 1;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
        }
        return pages.filter((value, index, self) => self.indexOf(value) === index); // Eliminar duplicados si los hubiera
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyPaginatorComponent, isStandalone: true, selector: "frey-paginator", inputs: { totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: true, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", itemsPerPageChange: "itemsPerPageChange" }, host: { classAttribute: "frey-paginator" }, ngImport: i0, template: "<div class=\"frey-paginator__summary\">\n  <span>Total: {{ totalItems() }} elementos</span>\n  <div>\n    <span>Elementos por p\u00E1gina: </span>\n\n    <input\n      type=\"number\"\n      [value]=\"itemsPerPage()\"\n      (input)=\"updateItemsPerPage($event.target.value)\"\n      class=\"frey-paginator__input\"\n      min=\"1\"\n    />\n  </div>\n</div>\n\n<div class=\"frey-paginator__controls\">\n  <button\n    class=\"frey-paginator__button frey-paginator__button--prev\"\n    (click)=\"prevPage()\"\n    [disabled]=\"_currentPage() === 1\"\n  >\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M26 16 L18 24 L26 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span>Anterior</span>\n  </button>\n\n  @for (page of visiblePages(); track $index) {\n    @if (page === '...') {\n      <span class=\"frey-paginator__ellipsis\">...</span>\n    } @else {\n      <button\n        class=\"frey-paginator__button\"\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\n        (click)=\"goToPage(page)\"\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\n      >\n        {{ page }}\n      </button>\n    }\n  }\n\n  <button\n    class=\"frey-paginator__button frey-paginator__button--next\"\n    (click)=\"nextPage()\"\n    [disabled]=\"_currentPage() === totalPages()\"\n  >\n    <span>Siguiente</span>\n\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M22 16 L30 24 L22 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-paginator', standalone: true, imports: [], host: {
                        class: 'frey-paginator',
                    }, template: "<div class=\"frey-paginator__summary\">\n  <span>Total: {{ totalItems() }} elementos</span>\n  <div>\n    <span>Elementos por p\u00E1gina: </span>\n\n    <input\n      type=\"number\"\n      [value]=\"itemsPerPage()\"\n      (input)=\"updateItemsPerPage($event.target.value)\"\n      class=\"frey-paginator__input\"\n      min=\"1\"\n    />\n  </div>\n</div>\n\n<div class=\"frey-paginator__controls\">\n  <button\n    class=\"frey-paginator__button frey-paginator__button--prev\"\n    (click)=\"prevPage()\"\n    [disabled]=\"_currentPage() === 1\"\n  >\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M26 16 L18 24 L26 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span>Anterior</span>\n  </button>\n\n  @for (page of visiblePages(); track $index) {\n    @if (page === '...') {\n      <span class=\"frey-paginator__ellipsis\">...</span>\n    } @else {\n      <button\n        class=\"frey-paginator__button\"\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\n        (click)=\"goToPage(page)\"\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\n      >\n        {{ page }}\n      </button>\n    }\n  }\n\n  <button\n    class=\"frey-paginator__button frey-paginator__button--next\"\n    (click)=\"nextPage()\"\n    [disabled]=\"_currentPage() === totalPages()\"\n  >\n    <span>Siguiente</span>\n\n    <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"48\"\n      height=\"48\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      class=\"frey-paginator__icon\"\n    >\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\n\n      <path\n        d=\"M22 16 L30 24 L22 32\"\n        stroke-width=\"3\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: true }] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], itemsPerPageChange: [{ type: i0.Output, args: ["itemsPerPageChange"] }] } });

/**
 * Directive to define a cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyCellDefDirective, isStandalone: true, selector: "[freyCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to add sorting functionality to table columns.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef freyColumnSort>
 *     <span>Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyColumnSortDirective {
    freyColumnSort = input(...(ngDevMode ? [undefined, { debugName: "freyColumnSort" }] : []));
    sortStatus = output();
    isArrowUp = false;
    elementRef = inject(ElementRef);
    renderer2 = inject(Renderer2);
    // private readonly cdr = inject(ChangeDetectorRef);
    ngAfterContentInit() {
        const iconSort = this.renderer2.createElement('span');
        const icon = this.renderer2.createText('▼');
        this.renderer2.setStyle(iconSort, 'font-size', '10px');
        this.renderer2.setStyle(iconSort, 'padding-left', ' 10px');
        this.renderer2.appendChild(iconSort, icon);
        this.renderer2.listen(this.elementRef.nativeElement, 'click', () => {
            this.isArrowUp = !this.isArrowUp;
            this.renderer2.setProperty(iconSort, 'textContent', this.getArrowText());
            // this.cdr.markForCheck();
        });
        this.renderer2.appendChild(this.elementRef.nativeElement, iconSort);
    }
    getArrowText() {
        this.sortStatus.emit(this.isArrowUp);
        return this.isArrowUp ? '▲' : '▼';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.1.2", type: FreyColumnSortDirective, isStandalone: true, selector: "[freyColumnSort]", inputs: { freyColumnSort: { classPropertyName: "freyColumnSort", publicName: "freyColumnSort", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sortStatus: "sortStatus" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnSortDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnSort]',
                    standalone: true,
                }]
        }], propDecorators: { freyColumnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnSort", required: false }] }], sortStatus: [{ type: i0.Output, args: ["sortStatus"] }] } });

/**
 * Directive to define a header cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Column Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
class FreyHeaderCellDefDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyHeaderCellDefDirective, isStandalone: true, selector: "[freyHeaderCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyHeaderCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyHeaderCellDef]',
                    standalone: true,
                }]
        }] });

/**
 * Directive to define a column in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Name</span>
 *   </th>
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
class FreyColumnDefDirective {
    columnName = input(undefined, { ...(ngDevMode ? { debugName: "columnName" } : {}), alias: 'freyColumnDef' });
    headerCellDef = contentChild(FreyHeaderCellDefDirective, ...(ngDevMode ? [{ debugName: "headerCellDef" }] : []));
    cellDef = contentChild(FreyCellDefDirective, ...(ngDevMode ? [{ debugName: "cellDef" }] : []));
    sort = contentChild(FreyColumnSortDirective, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.1.2", type: FreyColumnDefDirective, isStandalone: true, selector: "[freyColumnDef]", inputs: { columnName: { classPropertyName: "columnName", publicName: "freyColumnDef", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "headerCellDef", first: true, predicate: FreyHeaderCellDefDirective, descendants: true, isSignal: true }, { propertyName: "cellDef", first: true, predicate: FreyCellDefDirective, descendants: true, isSignal: true }, { propertyName: "sort", first: true, predicate: FreyColumnSortDirective, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyColumnDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyColumnDef]',
                    standalone: true,
                }]
        }], propDecorators: { columnName: [{ type: i0.Input, args: [{ isSignal: true, alias: "freyColumnDef", required: false }] }], headerCellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyHeaderCellDefDirective), { isSignal: true }] }], cellDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyCellDefDirective), { isSignal: true }] }], sort: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FreyColumnSortDirective), { isSignal: true }] }] } });

/**
 * Freya Table Component - A flexible and lightweight data table.
 *
 * Styles are completely optional and must be imported separately.
 * To use the default styles, import:
 * @import 'freya/styles/table/table.scss';
 *
 * @example
 * ```html
 * <!-- Show 10 records per page -->
 * <frey-table [dataSource]="data" [itemsPerPage]="10">
 *   <ng-container freyColumnDef="name">
 *     <th *freyHeaderCellDef>
 *       <span>Name</span>
 *     </th>
 *     <td *freyCellDef="let row">
 *       <div>{{ row.name }}</div>
 *     </td>
 *   </ng-container>
 * </frey-table>
 *
 * <!-- Show all records (no pagination) -->
 * <frey-table [dataSource]="data" [itemsPerPage]="null">
 *   <!-- columns -->
 * </frey-table>
 * ```
 */
class FreyTableComponent {
    // Inputs (using model() for programmatic access)
    columnDefs = contentChildren(FreyColumnDefDirective, ...(ngDevMode ? [{ debugName: "columnDefs" }] : []));
    dataSource = model([], ...(ngDevMode ? [{ debugName: "dataSource" }] : []));
    searchTerm = model('', ...(ngDevMode ? [{ debugName: "searchTerm" }] : []));
    itemsPerPage = model(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    currentPage = model(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    selectable = model(false, ...(ngDevMode ? [{ debugName: "selectable" }] : []));
    // Outputs
    searchResults = output();
    clickRow = output();
    // Computed columns from column definitions
    columns = computed(() => this.columnDefs().map((colDef) => ({
        name: colDef.columnName(),
        headerCellDef: colDef.headerCellDef(),
        cellDef: colDef.cellDef(),
    })), ...(ngDevMode ? [{ debugName: "columns" }] : []));
    // Computed filtered data based on search term
    filteredDataBySearch = computed(() => {
        const data = this.dataSource();
        const search = this.searchTerm().trim().toLowerCase();
        if (!search) {
            return [...data];
        }
        return data.filter((row) => Object.keys(row).some((key) => row[key]?.toString().toLowerCase().includes(search)));
    }, ...(ngDevMode ? [{ debugName: "filteredDataBySearch" }] : []));
    // Computed paginated and sorted data
    paginatedData = computed(() => {
        const filtered = this.filteredDataBySearch();
        const sort = this.sortState();
        const sortedData = [...filtered];
        // Apply sorting if active
        if (sort) {
            sortedData.sort((a, b) => this.compareValues(a, b, sort.column, sort.direction));
        }
        // Apply pagination (if itemsPerPage is null, show all)
        const perPage = this.itemsPerPage();
        if (perPage === null) {
            return sortedData;
        }
        const page = this.currentPage();
        const startIndex = (page - 1) * perPage;
        const endIndex = startIndex + perPage;
        return sortedData.slice(startIndex, endIndex);
    }, ...(ngDevMode ? [{ debugName: "paginatedData" }] : []));
    // Selection state
    selectedRowIndex = signal(null, ...(ngDevMode ? [{ debugName: "selectedRowIndex" }] : []));
    selectedRow = signal(null, ...(ngDevMode ? [{ debugName: "selectedRow" }] : []));
    // Sort state
    sortState = signal(null, ...(ngDevMode ? [{ debugName: "sortState" }] : []));
    constructor() {
        // Effect to emit search results when filtered data changes
        effect(() => {
            const filtered = this.filteredDataBySearch();
            this.searchResults.emit(filtered.length);
        });
        // Effect to set up sort event listeners
        effect((onCleanup) => {
            const cols = this.columnDefs();
            const subscriptions = [];
            cols.forEach((colDef) => {
                const sortDirective = colDef.sort();
                if (sortDirective) {
                    const subscription = sortDirective.sortStatus.subscribe(() => {
                        this.onSort(colDef.columnName() ?? '');
                    });
                    subscriptions.push(subscription);
                }
            });
            onCleanup(() => {
                subscriptions.forEach((sub) => sub.unsubscribe());
            });
        });
    }
    selectRow(columnName, row, index) {
        if (!this.selectable()) {
            return;
        }
        if (this.selectedRow() === row) {
            this.selectedRowIndex.set(null);
            this.selectedRow.set(null);
            this.clickRow.emit(null);
            return;
        }
        this.selectedRowIndex.set(index);
        this.selectedRow.set(row);
        this.clickRow.emit({ name: columnName, data: row, rowIndex: index });
    }
    isRowSelected(row) {
        return this.selectedRow() === row;
    }
    onSort(column) {
        const currentSort = this.sortState();
        if (currentSort?.column === column) {
            this.sortState.set({
                column,
                direction: currentSort.direction === 'asc' ? 'desc' : 'asc',
            });
        }
        else {
            this.sortState.set({ column, direction: 'asc' });
        }
    }
    compareValues(a, b, column, direction) {
        const valueA = a[column];
        const valueB = b[column];
        if (typeof valueA === 'boolean' && typeof valueB === 'boolean') {
            return direction === 'asc'
                ? Number(valueA) - Number(valueB)
                : Number(valueB) - Number(valueA);
        }
        if (this.isNumeric(valueA) && this.isNumeric(valueB)) {
            return this.compareNumeric(valueA, valueB, direction);
        }
        return this.compareString((valueA ?? '').toString(), (valueB ?? '').toString(), direction);
    }
    compareNumeric(a, b, direction) {
        return direction === 'asc' ? a - b : b - a;
    }
    compareString(a, b, direction) {
        return a.localeCompare(b) * (direction === 'asc' ? 1 : -1);
    }
    isNumeric(value) {
        return typeof value === 'number' && !isNaN(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyTableComponent, isStandalone: true, selector: "frey-table", inputs: { dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, searchTerm: { classPropertyName: "searchTerm", publicName: "searchTerm", isSignal: true, isRequired: false, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dataSource: "dataSourceChange", searchTerm: "searchTermChange", itemsPerPage: "itemsPerPageChange", currentPage: "currentPageChange", selectable: "selectableChange", searchResults: "searchResults", clickRow: "clickRow" }, queries: [{ propertyName: "columnDefs", predicate: FreyColumnDefDirective, isSignal: true }], ngImport: i0, template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-table', standalone: true, imports: [NgTemplateOutlet], template: "<table>\n  <thead>\n    <tr>\n      @for (column of columns(); track column) {\n        @if (column.headerCellDef) {\n          <ng-container [ngTemplateOutlet]=\"column.headerCellDef.template\"></ng-container>\n        }\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of paginatedData(); let i = $index; track row) {\n      <tr\n        [class.selected-row]=\"isRowSelected(row)\"\n        [class.selectable]=\"selectable()\"\n        (click)=\"selectRow('', row, i)\"\n      >\n        @for (column of columns(); track column) {\n          @if (column.cellDef) {\n            <ng-container\n              [ngTemplateOutlet]=\"column.cellDef.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: row }\"\n            ></ng-container>\n          }\n        }\n      </tr>\n    }\n  </tbody>\n</table>\n\n@if (!dataSource().length) {\n  <div class=\"empty-message\">No se han encontrado datos</div>\n}\n@if (!paginatedData().length && dataSource().length) {\n  <div class=\"empty-message\">No se encontraron resultados para tu b\u00FAsqueda</div>\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { columnDefs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => FreyColumnDefDirective), { isSignal: true }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }, { type: i0.Output, args: ["dataSourceChange"] }], searchTerm: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchTerm", required: false }] }, { type: i0.Output, args: ["searchTermChange"] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }, { type: i0.Output, args: ["itemsPerPageChange"] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }, { type: i0.Output, args: ["currentPageChange"] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }, { type: i0.Output, args: ["selectableChange"] }], searchResults: [{ type: i0.Output, args: ["searchResults"] }], clickRow: [{ type: i0.Output, args: ["clickRow"] }] } });

/**
 * Public API Surface of Freya Table
 */

/**
 * Public API Surface of Freya UI Library
 * Primero deben ir las clases globales o compartidas
 */
// Clases
// Note: datepicker, form y timepicker NO se exportan desde el entry point principal
// Solo son accesibles vía entradas secundarias: 'freya/datepicker', 'freya/form', 'freya/timepicker'

/**
 * Generated bundle index. Do not edit.
 */

export { FreyButtonDirective, FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyControlForm, FreyControlValueAccessor, FreyHeaderCellDefDirective, FreyPaginatorComponent, FreyTableComponent, SubjectState, getRequestAsync, isDefined, isNullOrUndefined, wait };
//# sourceMappingURL=freya.mjs.map
