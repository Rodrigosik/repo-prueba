import * as i0 from '@angular/core';
import { input, output, signal, computed, effect, Component } from '@angular/core';

/**
 * Componente Paginador para Freya UI.
 *
 * Este componente proporciona controles de paginación para navegar a través de una colección de elementos.
 * Permite al usuario ver el número total de elementos, el número de elementos por página,
 * y navegar entre páginas utilizando botones de "anterior", "siguiente" y números de página.
 *
 * Los estilos son completamente opcionales.
 * Para usar los estilos por defecto:
 * @import 'freya/styles/paginator/paginator.scss';
 *
 * @example
 * ```html
 * <frey-paginator
 *   [totalItems]="100"
 *   [itemsPerPage]="10"
 *   [currentPage]="1"
 *   (pageChange)="onPageChange($event)"
 *   (itemsPerPageChange)="onItemsPerPageChange($event)"
 * ></frey-paginator>
 * ```
 */
class FreyPaginatorComponent {
    /**
     * El número total de elementos en la colección.
     */
    totalItems = input.required(...(ngDevMode ? [{ debugName: "totalItems" }] : []));
    /**
     * El número de elementos a mostrar por página.
     * Por defecto es 10.
     */
    itemsPerPage = input(10, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : []));
    /**
     * La página actual seleccionada.
     * Por defecto es 1.
     */
    currentPage = input(1, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    /**
     * Evento emitido cuando la página cambia.
     * Emite el nuevo número de página.
     */
    pageChange = output();
    /**
     * Evento emitido cuando cambia el número de elementos por página.
     * Emite el nuevo valor de elementos por página.
     */
    itemsPerPageChange = output();
    /** Señal interna para el estado mutable de currentPage */
    _currentPage = signal(1, ...(ngDevMode ? [{ debugName: "_currentPage" }] : []));
    /** Señal interna para el estado mutable de itemsPerPage */
    _itemsPerPage = signal(this.itemsPerPage(), ...(ngDevMode ? [{ debugName: "_itemsPerPage" }] : []));
    /** El número total de páginas calculadas. */
    totalPages = computed(() => Math.ceil(this.totalItems() / this._itemsPerPage()), ...(ngDevMode ? [{ debugName: "totalPages" }] : []));
    /** Array de números de página visibles en los controles. */
    visiblePages = computed(() => this.generateVisiblePages(this._currentPage(), this.totalPages()), ...(ngDevMode ? [{ debugName: "visiblePages" }] : []));
    constructor() {
        // Sincronizar la señal interna con el input
        effect(() => this._currentPage.set(this.currentPage()));
        effect(() => this._itemsPerPage.set(this.itemsPerPage()));
        // Validar y ajustar currentPage si es necesario
        effect(() => {
            if (this._currentPage() > this.totalPages() && this.totalPages() > 0) {
                this._currentPage.set(this.totalPages());
                this.pageChange.emit(this.totalPages());
            }
            else if (this._currentPage() < 1 && this.totalPages() > 0) {
                this._currentPage.set(1);
                this.pageChange.emit(1);
            }
        });
    }
    /**
     * Navega a la página especificada.
     * @param page El número de página al que navegar.
     */
    goToPage(page) {
        if (page >= 1 && page <= this.totalPages() && page !== this._currentPage()) {
            this._currentPage.set(page);
            this.pageChange.emit(page);
        }
    }
    /**
     * Navega a la página anterior.
     */
    prevPage() {
        if (this._currentPage() > 1) {
            this.goToPage(this._currentPage() - 1);
        }
    }
    /**
     * Navega a la página siguiente.
     */
    nextPage() {
        if (this._currentPage() < this.totalPages()) {
            this.goToPage(this._currentPage() + 1);
        }
    }
    /**
     * Actualiza el número de elementos por página basado en la entrada del usuario.
     * @param value El nuevo valor de elementos por página.
     */
    updateItemsPerPage(value) {
        const parsedValue = parseInt(value, 10);
        if (!isNaN(parsedValue) && parsedValue > 0) {
            this._itemsPerPage.set(parsedValue); // Actualizar la señal interna
            this.itemsPerPageChange.emit(parsedValue);
            this.pageChange.emit(this._currentPage());
        }
    }
    /**
     * Genera un array de números de página para mostrar en los controles.
     * @param currentPage La página actual.
     * @param totalPages El número total de páginas.
     * @returns Un array de números de página visibles.
     */
    generateVisiblePages(currentPage, totalPages) {
        const pages = [];
        const maxPagesToShow = 5; // Número máximo de páginas a mostrar directamente
        if (totalPages <= maxPagesToShow) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        }
        else {
            let startPage;
            let endPage;
            if (currentPage <= Math.floor(maxPagesToShow / 2) + 1) {
                startPage = 1;
                endPage = maxPagesToShow - 1;
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
            else if (currentPage >= totalPages - Math.floor(maxPagesToShow / 2)) {
                startPage = totalPages - maxPagesToShow + 2;
                endPage = totalPages;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
            }
            else {
                startPage = currentPage - Math.floor(maxPagesToShow / 2) + 1;
                endPage = currentPage + Math.floor(maxPagesToShow / 2) - 1;
                pages.push(1);
                pages.push('...');
                for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
        }
        return pages.filter((value, index, self) => self.indexOf(value) === index); // Eliminar duplicados si los hubiera
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyPaginatorComponent, isStandalone: true, selector: "frey-paginator", inputs: { totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: true, transformFunction: null }, itemsPerPage: { classPropertyName: "itemsPerPage", publicName: "itemsPerPage", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", itemsPerPageChange: "itemsPerPageChange" }, host: { classAttribute: "frey-paginator" }, ngImport: i0, template: "<div class=\"frey-paginator__summary\">\r\n  <span>Total: {{ totalItems() }} elementos</span>\r\n  <div>\r\n    <span>Elementos por p\u00E1gina: </span>\r\n\r\n    <input\r\n      type=\"number\"\r\n      [value]=\"itemsPerPage()\"\r\n      (input)=\"updateItemsPerPage($event.target.value)\"\r\n      class=\"frey-paginator__input\"\r\n      min=\"1\"\r\n    />\r\n  </div>\r\n</div>\r\n\r\n<div class=\"frey-paginator__controls\">\r\n  <button\r\n    class=\"frey-paginator__button frey-paginator__button--prev\"\r\n    (click)=\"prevPage()\"\r\n    [disabled]=\"_currentPage() === 1\"\r\n  >\r\n    <svg\r\n      xmlns=\"http://www.w3.org/2000/svg\"\r\n      width=\"48\"\r\n      height=\"48\"\r\n      viewBox=\"0 0 48 48\"\r\n      fill=\"none\"\r\n      class=\"frey-paginator__icon\"\r\n    >\r\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\r\n\r\n      <path\r\n        d=\"M26 16 L18 24 L26 32\"\r\n        stroke-width=\"3\"\r\n        stroke-linecap=\"round\"\r\n        stroke-linejoin=\"round\"\r\n      />\r\n    </svg>\r\n    <span>Anterior</span>\r\n  </button>\r\n\r\n  @for (page of visiblePages(); track $index) {\r\n    @if (page === '...') {\r\n      <span class=\"frey-paginator__ellipsis\">...</span>\r\n    } @else {\r\n      <button\r\n        class=\"frey-paginator__button\"\r\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\r\n        (click)=\"goToPage(page)\"\r\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\r\n      >\r\n        {{ page }}\r\n      </button>\r\n    }\r\n  }\r\n\r\n  <button\r\n    class=\"frey-paginator__button frey-paginator__button--next\"\r\n    (click)=\"nextPage()\"\r\n    [disabled]=\"_currentPage() === totalPages()\"\r\n  >\r\n    <span>Siguiente</span>\r\n\r\n    <svg\r\n      xmlns=\"http://www.w3.org/2000/svg\"\r\n      width=\"48\"\r\n      height=\"48\"\r\n      viewBox=\"0 0 48 48\"\r\n      fill=\"none\"\r\n      class=\"frey-paginator__icon\"\r\n    >\r\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\r\n\r\n      <path\r\n        d=\"M22 16 L30 24 L22 32\"\r\n        stroke-width=\"3\"\r\n        stroke-linecap=\"round\"\r\n        stroke-linejoin=\"round\"\r\n      />\r\n    </svg>\r\n  </button>\r\n</div>\r\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyPaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-paginator', standalone: true, imports: [], host: {
                        class: 'frey-paginator',
                    }, template: "<div class=\"frey-paginator__summary\">\r\n  <span>Total: {{ totalItems() }} elementos</span>\r\n  <div>\r\n    <span>Elementos por p\u00E1gina: </span>\r\n\r\n    <input\r\n      type=\"number\"\r\n      [value]=\"itemsPerPage()\"\r\n      (input)=\"updateItemsPerPage($event.target.value)\"\r\n      class=\"frey-paginator__input\"\r\n      min=\"1\"\r\n    />\r\n  </div>\r\n</div>\r\n\r\n<div class=\"frey-paginator__controls\">\r\n  <button\r\n    class=\"frey-paginator__button frey-paginator__button--prev\"\r\n    (click)=\"prevPage()\"\r\n    [disabled]=\"_currentPage() === 1\"\r\n  >\r\n    <svg\r\n      xmlns=\"http://www.w3.org/2000/svg\"\r\n      width=\"48\"\r\n      height=\"48\"\r\n      viewBox=\"0 0 48 48\"\r\n      fill=\"none\"\r\n      class=\"frey-paginator__icon\"\r\n    >\r\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\r\n\r\n      <path\r\n        d=\"M26 16 L18 24 L26 32\"\r\n        stroke-width=\"3\"\r\n        stroke-linecap=\"round\"\r\n        stroke-linejoin=\"round\"\r\n      />\r\n    </svg>\r\n    <span>Anterior</span>\r\n  </button>\r\n\r\n  @for (page of visiblePages(); track $index) {\r\n    @if (page === '...') {\r\n      <span class=\"frey-paginator__ellipsis\">...</span>\r\n    } @else {\r\n      <button\r\n        class=\"frey-paginator__button\"\r\n        [class.frey-paginator__button--active]=\"_currentPage() === page\"\r\n        (click)=\"goToPage(page)\"\r\n        [attr.aria-current]=\"_currentPage() === page ? 'page' : null\"\r\n      >\r\n        {{ page }}\r\n      </button>\r\n    }\r\n  }\r\n\r\n  <button\r\n    class=\"frey-paginator__button frey-paginator__button--next\"\r\n    (click)=\"nextPage()\"\r\n    [disabled]=\"_currentPage() === totalPages()\"\r\n  >\r\n    <span>Siguiente</span>\r\n\r\n    <svg\r\n      xmlns=\"http://www.w3.org/2000/svg\"\r\n      width=\"48\"\r\n      height=\"48\"\r\n      viewBox=\"0 0 48 48\"\r\n      fill=\"none\"\r\n      class=\"frey-paginator__icon\"\r\n    >\r\n      <circle cx=\"24\" cy=\"24\" r=\"22\" stroke-width=\"3\" fill=\"none\" />\r\n\r\n      <path\r\n        d=\"M22 16 L30 24 L22 32\"\r\n        stroke-width=\"3\"\r\n        stroke-linecap=\"round\"\r\n        stroke-linejoin=\"round\"\r\n      />\r\n    </svg>\r\n  </button>\r\n</div>\r\n" }]
        }], ctorParameters: () => [], propDecorators: { totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: true }] }], itemsPerPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPage", required: false }] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], itemsPerPageChange: [{ type: i0.Output, args: ["itemsPerPageChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyPaginatorComponent };
//# sourceMappingURL=freya-paginator.mjs.map
