import * as i0 from '@angular/core';
import { EventEmitter, HostListener, Output, ViewChild, Component, inject, ApplicationRef, RendererFactory2, createComponent, Injectable, NgModule } from '@angular/core';
import { isObjectEmpty } from 'freya/helpers';
import * as i1 from '@angular/common';
import { NgClass } from '@angular/common';
import { Subscription, Subject, delay } from 'rxjs';

class FreyModalComponent {
    modalbody;
    closeEvent = new EventEmitter();
    modalConfig;
    WidthModal;
    get shouldShowLastModal() {
        return this.modalConfig.shouldShowLastModal;
    }
    ngAfterContentInit() {
        this.onResizeModal();
    }
    closeMe() {
        if (!this.modalConfig.isCloseModalClickOutside) {
            return;
        }
        this.closeEvent.emit();
    }
    setModalClassConfig() {
        return this.positionZIndex() + this.positionX() + this.positionY();
    }
    onResize() {
        this.onResizeModal();
    }
    positionZIndex() {
        return `z-index: ${this.modalConfig.zIndex};`;
    }
    positionX() {
        const wordMap = {
            left: 'flex-start',
            rigth: 'flex-end',
            center: 'center',
        };
        return `align-items: ${wordMap[this.modalConfig.positionX]};`;
    }
    positionY() {
        const wordMap = {
            top: 'flex-start',
            bottom: 'flex-end',
            center: 'center',
        };
        return `justify-content: ${wordMap[this.modalConfig.positionY]};`;
    }
    onResizeModal() {
        if (isObjectEmpty(this.modalConfig?.customWidth)) {
            this.WidthModal = this.modalConfig.width;
            return;
        }
        const { small, medium, large } = this.modalConfig.customWidth;
        if (window.innerWidth <= 830) {
            this.WidthModal = small || medium || large;
        }
        else if (window.innerWidth <= 1024) {
            this.WidthModal = medium || small || large;
        }
        else {
            this.WidthModal = large || medium || small;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyModalComponent, isStandalone: false, selector: "frey-modal", outputs: { closeEvent: "closeEvent" }, host: { listeners: { "window:resize": "onResize()" } }, viewQueries: [{ propertyName: "modalbody", first: true, predicate: ["modalbody"], descendants: true, static: true }], ngImport: i0, template: "<div\n  class=\"modal\"\n  [style]=\"setModalClassConfig()\"\n  (click)=\"closeMe()\"\n  (keydown)=\"closeMe()\"\n  [attr.shouldShowLastModal]=\"shouldShowLastModal\"\n>\n  @if (modalConfig.hasButtonClose) {\n    <div\n      class=\"modal__cross\"\n      (click)=\"this.closeEvent.emit()\"\n      (keydown)=\"this.closeEvent.emit()\"\n      [style]=\"'width:' + WidthModal + '%'\"\n    ></div>\n  }\n  <div\n    class=\"modal__container\"\n    [ngClass]=\"{ 'modal__container--border': modalConfig.hasBorder }\"\n    [style]=\"'width:' + WidthModal + '%'\"\n  >\n    <div class=\"modal__body\">\n      <div #modalbody></div>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'frey-modal', template: "<div\n  class=\"modal\"\n  [style]=\"setModalClassConfig()\"\n  (click)=\"closeMe()\"\n  (keydown)=\"closeMe()\"\n  [attr.shouldShowLastModal]=\"shouldShowLastModal\"\n>\n  @if (modalConfig.hasButtonClose) {\n    <div\n      class=\"modal__cross\"\n      (click)=\"this.closeEvent.emit()\"\n      (keydown)=\"this.closeEvent.emit()\"\n      [style]=\"'width:' + WidthModal + '%'\"\n    ></div>\n  }\n  <div\n    class=\"modal__container\"\n    [ngClass]=\"{ 'modal__container--border': modalConfig.hasBorder }\"\n    [style]=\"'width:' + WidthModal + '%'\"\n  >\n    <div class=\"modal__body\">\n      <div #modalbody></div>\n    </div>\n  </div>\n</div>\n" }]
        }], propDecorators: { modalbody: [{
                type: ViewChild,
                args: ['modalbody', { static: true }]
            }], closeEvent: [{
                type: Output
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', []]
            }] } });

class ModalProps {
    modalComponent = null;
    componentRef = null;
    eventsSubscription = new Subscription();
    eventList = ['closeEvent', 'confirmEvent', 'otherEvent'];
    modalSubscription = new Subject();
}
class FreyModalService {
    totalModals = 0;
    renderer2;
    applicationRef = inject(ApplicationRef);
    rendererFactory = inject(RendererFactory2);
    constructor() {
        this.renderer2 = this.rendererFactory.createRenderer(null, null);
    }
    openModal(component, config) {
        if (this.totalModals === 0) {
            this.renderer2.setStyle(document.body, 'overflow', 'hidden');
        }
        console.log(config, 'CONFIG SERVICE');
        this.totalModals++;
        const modalProps = this.buildModal(component, config);
        return modalProps.modalSubscription.asObservable().pipe(delay(1));
    }
    buildModal(component, config) {
        const modalProps = this.buildComponents(component);
        modalProps.modalComponent.instance.modalConfig = config;
        const instance = modalProps.componentRef.instance;
        if ('dataSource' in instance) {
            modalProps.componentRef.instance['dataSource'] = config.dataSource;
        }
        this.addToBodyDOM(modalProps);
        this.buildEventsToModal(modalProps);
        return modalProps;
    }
    buildComponents(component) {
        const modalProps = new ModalProps();
        modalProps.modalComponent = createComponent(FreyModalComponent, {
            environmentInjector: this.applicationRef.injector,
        });
        modalProps.componentRef = createComponent(component, {
            hostElement: modalProps.modalComponent['instance']['modalbody'].nativeElement,
            environmentInjector: this.applicationRef.injector,
        });
        //📜📜📜 Importante para que angular detecte los ciclos de vida de los componetes creados 📜📜📜
        this.applicationRef.attachView(modalProps.modalComponent.hostView);
        this.applicationRef.attachView(modalProps.componentRef.hostView);
        return modalProps;
    }
    addToBodyDOM(modalProps) {
        const componentDom = modalProps.modalComponent.hostView.rootNodes[0];
        this.renderer2.appendChild(document.body, componentDom);
    }
    buildEventsToModal(modalProps) {
        const components = ['modalComponent', 'componentRef'];
        components.forEach((componentName) => {
            modalProps.eventList.forEach((eventName) => {
                if (modalProps[componentName].instance[eventName]) {
                    modalProps.eventsSubscription.add(modalProps[componentName].instance[eventName].subscribe((response) => {
                        this.setActionEvent(modalProps, eventName, response);
                    }));
                }
            });
        });
    }
    setActionEvent(modalProps, eventName, response) {
        const functionMap = {
            closeEvent: () => this.closeModal(modalProps, null),
            confirmEvent: () => this.closeModal(modalProps, response),
            otherEvent: () => this.otherEvent(modalProps, response),
        };
        if (functionMap[eventName]) {
            functionMap[eventName]();
        }
    }
    closeModal(modalProps, dataSource) {
        modalProps.eventsSubscription.unsubscribe();
        modalProps.modalSubscription.next(dataSource);
        modalProps.modalSubscription.complete();
        const components = ['modalComponent', 'componentRef'];
        components.forEach((componentName) => {
            this.applicationRef.detachView(modalProps[componentName].hostView);
            modalProps[componentName].destroy();
        });
        this.totalModals--;
        if (this.totalModals === 0) {
            this.renderer2.removeStyle(document.body, 'overflow');
        }
    }
    otherEvent(modalProps, dataSource) {
        modalProps.modalSubscription.next({
            otherEvent: dataSource,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class FreyModalModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: FreyModalModule, declarations: [FreyModalComponent], imports: [NgClass] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalModule, providers: [FreyModalService] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyModalModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [FreyModalComponent],
                    imports: [NgClass],
                    providers: [FreyModalService],
                }]
        }] });

class FreyModalConfigModel {
    positionX = 'center';
    positionY = 'center';
    isCloseModalClickOutside = false;
    hasBorder = true;
    dataSource = null;
    width = 50;
    customWidth = new FreyModalResponsiveModel();
    zIndex = 99999;
    shouldShowLastModal = true;
    hasButtonClose = true;
}
class FreyModalResponsiveModel {
    // xsmall: number = null;
    small = null; //830
    medium = null; //831 a 1024
    large = null; //1025
}

/**
 * Generated bundle index. Do not edit.
 */

export { FreyModalComponent, FreyModalConfigModel, FreyModalModule, FreyModalResponsiveModel, FreyModalService };
//# sourceMappingURL=freya-modal.mjs.map
