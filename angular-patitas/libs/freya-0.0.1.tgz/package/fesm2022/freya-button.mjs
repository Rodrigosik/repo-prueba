import * as i0 from '@angular/core';
import { HostBinding, Input, Directive } from '@angular/core';

/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant = 'solid';
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color = 'primary';
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size = 'medium';
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading = false;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled = false;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular = false;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly = false;
    /**
     * Clases computadas para el host
     */
    get hostClasses() {
        const classes = ['frey-button'];
        // Variante
        if (this.variant !== 'solid') {
            classes.push(`frey-button--${this.variant}`);
        }
        // Color
        classes.push(`frey-button--${this.color}`);
        // Tamaño
        if (this.size !== 'medium') {
            classes.push(`frey-button--${this.size}`);
        }
        // Estados
        if (this.loading) {
            classes.push('frey-button--loading');
        }
        if (this.disabled) {
            classes.push('frey-button--disabled');
        }
        // Modificadores
        if (this.circular) {
            classes.push('frey-button--circular');
        }
        if (this.iconOnly) {
            classes.push('frey-button--icon-only');
        }
        return classes.join(' ');
    }
    /**
     * Atributo disabled del botón
     */
    get isDisabled() {
        return this.disabled || this.loading ? true : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyButtonDirective, isStandalone: true, selector: "[freyButton]", inputs: { variant: "variant", color: "color", size: "size", loading: "loading", disabled: "disabled", circular: "circular", iconOnly: "iconOnly" }, host: { attributes: { "type": "button" }, properties: { "class": "this.hostClasses", "attr.disabled": "this.isDisabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyButton]',
                    standalone: true,
                    host: {
                        type: 'button',
                    },
                }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], loading: [{
                type: Input
            }], disabled: [{
                type: Input
            }], circular: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], isDisabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyButtonDirective };
//# sourceMappingURL=freya-button.mjs.map
