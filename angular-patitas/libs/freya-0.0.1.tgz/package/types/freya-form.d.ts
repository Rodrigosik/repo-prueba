import * as _angular_core from '@angular/core';
import { AfterContentInit, WritableSignal, ElementRef } from '@angular/core';
import { FreyControlForm, FreyControlValueAccessor } from 'freya/class';
import * as i12 from '@angular/common';

declare class FreyErrorComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyErrorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyErrorComponent, "frey-error", never, {}, {}, never, ["*"], false, never>;
}

declare class FreyInputDirective extends FreyControlForm {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyInputDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyInputDirective, "[freyInput]", never, {}, {}, never, never, false, never>;
}

declare class FreyTextareaDirective extends FreyControlForm {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTextareaDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyTextareaDirective, "[freyTextarea]", never, {}, {}, never, never, false, never>;
}

declare class FreyFieldComponent implements AfterContentInit {
    requiredText: _angular_core.InputSignal<string>;
    freyInput: _angular_core.Signal<FreyInputDirective | undefined>;
    freyTextarea: _angular_core.Signal<FreyTextareaDirective | undefined>;
    freySelect: _angular_core.Signal<FreyFieldComponent | undefined>;
    formControl: WritableSignal<any>;
    isRequired: _angular_core.Signal<any>;
    isDisabled: _angular_core.Signal<any>;
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyFieldComponent, "frey-field", never, { "requiredText": { "alias": "requiredText"; "required": false; "isSignal": true; }; }, {}, ["freyInput", "freyTextarea", "freySelect"], ["frey-label", "frey-prefix", "[freyInput], [freyTextarea], frey-select", "frey-suffix", "frey-hint", "frey-error", "frey-success"], false, never>;
}

declare class FreyHintComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyHintComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyHintComponent, "frey-hint", never, {}, {}, never, ["*"], false, never>;
}

declare class FreyLabelComponent {
    labelText: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyLabelComponent, "frey-label", never, {}, {}, never, ["*"], false, never>;
}

declare class FreyOptionComponent {
    description: _angular_core.Signal<ElementRef<any> | undefined>;
    clickOption: _angular_core.OutputEmitterRef<void>;
    value: _angular_core.InputSignal<unknown>;
    isDisabled: _angular_core.InputSignal<boolean>;
    isSelected: _angular_core.WritableSignal<boolean>;
    isVisible: _angular_core.WritableSignal<boolean>;
    readonly elementRef: ElementRef<any>;
    onClickOption(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyOptionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyOptionComponent, "frey-option", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "isDisabled": { "alias": "isDisabled"; "required": false; "isSignal": true; }; }, { "clickOption": "clickOption"; }, never, ["*"], false, never>;
}

declare class FreyPrefix {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyPrefix, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyPrefix, "frey-prefix", never, {}, {}, never, ["*"], false, never>;
}

declare class FreySelectComponent extends FreyControlValueAccessor implements AfterContentInit {
    freyOptions: _angular_core.Signal<readonly FreyOptionComponent[]>;
    searchInput: _angular_core.Signal<ElementRef<any> | undefined>;
    searchInputBackend: _angular_core.Signal<ElementRef<any> | undefined>;
    typeSearch: _angular_core.InputSignal<"frontend" | "backend" | "none">;
    backendSearchDebounceMs: _angular_core.InputSignal<number>;
    readonly: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    placeholder: _angular_core.InputSignal<string>;
    selectionChange: _angular_core.OutputEmitterRef<any>;
    backendSearchQuery: _angular_core.OutputEmitterRef<string>;
    currentText: _angular_core.WritableSignal<any>;
    currentValue: _angular_core.WritableSignal<any>;
    isSelectOpen: _angular_core.WritableSignal<boolean>;
    searchBackendValue: _angular_core.WritableSignal<string>;
    formControl: any;
    private debouncedBackendSearchQuery;
    private lastEmittedBackendSearchQuery;
    private readonly injector;
    private readonly elementRef;
    constructor();
    ngAfterContentInit(): void;
    selected(): void;
    onTouchedFn(): void;
    writeValue(value: any): void;
    onSearch(): void;
    onClearValues(): void;
    isNullOrUndefined(data: any): boolean;
    onClick(targetElement: any): void;
    private setPositionScroll;
    private setupBackendSearch;
    private subscribeToOptionClicks;
    private optionClicked;
    private setSelectedOption;
    private resetOptions;
    private normalizeText;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreySelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreySelectComponent, "frey-select", never, { "typeSearch": { "alias": "typeSearch"; "required": false; "isSignal": true; }; "backendSearchDebounceMs": { "alias": "backendSearchDebounceMs"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "backendSearchQuery": "backendSearchQuery"; }, ["freyOptions"], ["frey-option"], false, never>;
}

declare class FreySuccessComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreySuccessComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreySuccessComponent, "frey-success", never, {}, {}, never, ["*"], false, never>;
}

declare class FreySuffix {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreySuffix, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreySuffix, "frey-suffix", never, {}, {}, never, ["*"], false, never>;
}

declare class FreyFormModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyFormModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<FreyFormModule, [typeof FreyErrorComponent, typeof FreyFieldComponent, typeof FreyHintComponent, typeof FreyLabelComponent, typeof FreyPrefix, typeof FreySuccessComponent, typeof FreySuffix, typeof FreyOptionComponent, typeof FreySelectComponent, typeof FreyInputDirective, typeof FreyTextareaDirective], [typeof i12.NgClass], [typeof FreyErrorComponent, typeof FreyFieldComponent, typeof FreyHintComponent, typeof FreyLabelComponent, typeof FreyPrefix, typeof FreySuccessComponent, typeof FreySuffix, typeof FreyOptionComponent, typeof FreySelectComponent, typeof FreyInputDirective, typeof FreyTextareaDirective]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<FreyFormModule>;
}

export { FreyErrorComponent, FreyFieldComponent, FreyFormModule, FreyHintComponent, FreyInputDirective, FreyLabelComponent, FreyOptionComponent, FreyPrefix, FreySelectComponent, FreySuccessComponent, FreySuffix, FreyTextareaDirective };
