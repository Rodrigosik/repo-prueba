import * as i0 from '@angular/core';
import { AfterContentInit, ElementRef, EventEmitter, Type } from '@angular/core';
import * as i2 from '@angular/common';
import { Observable } from 'rxjs';

declare class FreyModalConfigModel {
    positionX: 'left' | 'center' | 'rigth';
    positionY: 'top' | 'center' | 'bottom';
    isCloseModalClickOutside: boolean;
    hasBorder: boolean;
    dataSource: any;
    width: number;
    customWidth: FreyModalResponsiveModel;
    zIndex: number;
    shouldShowLastModal: boolean;
    hasButtonClose: boolean;
}
declare class FreyModalResponsiveModel {
    small: number;
    medium: number;
    large: number;
}

declare class FreyModalComponent implements AfterContentInit {
    readonly modalbody: ElementRef;
    closeEvent: EventEmitter<any>;
    modalConfig: FreyModalConfigModel;
    WidthModal: number;
    get shouldShowLastModal(): boolean;
    ngAfterContentInit(): void;
    closeMe(): void;
    setModalClassConfig(): string;
    onResize(): void;
    private positionZIndex;
    private positionX;
    private positionY;
    private onResizeModal;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FreyModalComponent, "frey-modal", never, {}, { "closeEvent": "closeEvent"; }, never, never, false, never>;
}

declare class FreyModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FreyModalModule, [typeof FreyModalComponent], [typeof i2.NgClass], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FreyModalModule>;
}

declare class FreyModalService {
    private totalModals;
    private readonly renderer2;
    private readonly applicationRef;
    private readonly rendererFactory;
    constructor();
    openModal(component: Type<unknown>, config: FreyModalConfigModel): Observable<unknown>;
    private buildModal;
    private buildComponents;
    private addToBodyDOM;
    private buildEventsToModal;
    private setActionEvent;
    private closeModal;
    private otherEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FreyModalService>;
}

export { FreyModalComponent, FreyModalConfigModel, FreyModalModule, FreyModalResponsiveModel, FreyModalService };
