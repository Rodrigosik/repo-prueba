import * as _angular_core from '@angular/core';
import { AfterContentInit, OnDestroy, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
import * as freya from 'freya';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
declare class FreyControlForm implements AfterContentInit, OnDestroy {
    formControl: _angular_core.WritableSignal<any>;
    disabled: _angular_core.WritableSignal<boolean>;
    isRequired: _angular_core.Signal<any>;
    isValid: _angular_core.Signal<any>;
    isInvalid: _angular_core.Signal<any>;
    isTouched: _angular_core.Signal<any>;
    errors: _angular_core.Signal<any>;
    private readonly ngControl;
    private readonly subscription;
    constructor();
    ngOnDestroy(): void;
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyControlForm, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyControlForm, never, never, {}, {}, never, never, true, never>;
}

declare class FreyControlValueAccessor implements ControlValueAccessor {
    writeValue(value?: any): void;
    onChange: (value?: any) => void;
    registerOnChange(fn: any): void;
    onTouched: (value?: any) => void;
    registerOnTouched(fn: any): void;
    setDisabledState?(disabled?: boolean): void;
}

declare class SubjectState<T> {
    readonly $observable: Observable<T>;
    private _subject;
    constructor();
    update(value: T): void;
    complete(): void;
    error(error: any): void;
}

declare const wait: (ms: number) => Promise<void>;
declare const getRequestAsync: <T>(request: Observable<T>) => Promise<{
    status: boolean;
    data?: T;
    error?: unknown;
}>;

declare const isNullOrUndefined: (data: any) => boolean;
declare const isDefined: (data: any) => boolean;

/**
 * Tipo de variante del botón
 */
type ButtonVariant = 'solid' | 'outline' | 'ghost';
/**
 * Color del botón
 */
type ButtonColor = 'primary' | 'secondary' | 'success' | 'danger';
/**
 * Tamaño del botón
 */
type ButtonSize = 'small' | 'medium' | 'large';
/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
declare class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant: ButtonVariant;
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color: ButtonColor;
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size: ButtonSize;
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading: boolean;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled: boolean;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular: boolean;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly: boolean;
    /**
     * Clases computadas para el host
     */
    get hostClasses(): string;
    /**
     * Atributo disabled del botón
     */
    get isDisabled(): true | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyButtonDirective, "[freyButton]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "circular": { "alias": "circular"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Componente Paginador para Freya UI.
 *
 * Este componente proporciona controles de paginación para navegar a través de una colección de elementos.
 * Permite al usuario ver el número total de elementos, el número de elementos por página,
 * y navegar entre páginas utilizando botones de "anterior", "siguiente" y números de página.
 *
 * Los estilos son completamente opcionales.
 * Para usar los estilos por defecto:
 * @import 'freya/styles/paginator/paginator.scss';
 *
 * @example
 * ```html
 * <frey-paginator
 *   [totalItems]="100"
 *   [itemsPerPage]="10"
 *   [currentPage]="1"
 *   (pageChange)="onPageChange($event)"
 *   (itemsPerPageChange)="onItemsPerPageChange($event)"
 * ></frey-paginator>
 * ```
 */
declare class FreyPaginatorComponent {
    /**
     * El número total de elementos en la colección.
     */
    totalItems: _angular_core.InputSignal<number>;
    /**
     * El número de elementos a mostrar por página.
     * Por defecto es 10.
     */
    itemsPerPage: _angular_core.InputSignal<number>;
    /**
     * La página actual seleccionada.
     * Por defecto es 1.
     */
    currentPage: _angular_core.InputSignal<number>;
    /**
     * Evento emitido cuando la página cambia.
     * Emite el nuevo número de página.
     */
    pageChange: _angular_core.OutputEmitterRef<number>;
    /**
     * Evento emitido cuando cambia el número de elementos por página.
     * Emite el nuevo valor de elementos por página.
     */
    itemsPerPageChange: _angular_core.OutputEmitterRef<number>;
    /** Señal interna para el estado mutable de currentPage */
    _currentPage: _angular_core.WritableSignal<number>;
    /** Señal interna para el estado mutable de itemsPerPage */
    _itemsPerPage: _angular_core.WritableSignal<number>;
    /** El número total de páginas calculadas. */
    totalPages: _angular_core.Signal<number>;
    /** Array de números de página visibles en los controles. */
    visiblePages: _angular_core.Signal<(number | "...")[]>;
    constructor();
    /**
     * Navega a la página especificada.
     * @param page El número de página al que navegar.
     */
    goToPage(page: number): void;
    /**
     * Navega a la página anterior.
     */
    prevPage(): void;
    /**
     * Navega a la página siguiente.
     */
    nextPage(): void;
    /**
     * Actualiza el número de elementos por página basado en la entrada del usuario.
     * @param value El nuevo valor de elementos por página.
     */
    updateItemsPerPage(value: string): void;
    /**
     * Genera un array de números de página para mostrar en los controles.
     * @param currentPage La página actual.
     * @param totalPages El número total de páginas.
     * @returns Un array de números de página visibles.
     */
    private generateVisiblePages;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyPaginatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyPaginatorComponent, "frey-paginator", never, { "totalItems": { "alias": "totalItems"; "required": true; "isSignal": true; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; "itemsPerPageChange": "itemsPerPageChange"; }, never, never, true, never>;
}

/**
 * Directive to define a cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
declare class FreyCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyCellDefDirective, "[freyCellDef]", never, {}, {}, never, never, true, never>;
}

/**
 * Directive to add sorting functionality to table columns.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef freyColumnSort>
 *     <span>Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
declare class FreyColumnSortDirective implements AfterContentInit {
    freyColumnSort: _angular_core.InputSignal<string>;
    sortStatus: _angular_core.OutputEmitterRef<boolean>;
    private isArrowUp;
    private readonly elementRef;
    private readonly renderer2;
    ngAfterContentInit(): void;
    private getArrowText;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnSortDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnSortDirective, "[freyColumnSort]", never, { "freyColumnSort": { "alias": "freyColumnSort"; "required": false; "isSignal": true; }; }, { "sortStatus": "sortStatus"; }, never, never, true, never>;
}

/**
 * Directive to define a header cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Column Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
declare class FreyHeaderCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyHeaderCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyHeaderCellDefDirective, "[freyHeaderCellDef]", never, {}, {}, never, never, true, never>;
}

/**
 * Directive to define a column in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Name</span>
 *   </th>
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
declare class FreyColumnDefDirective {
    columnName: _angular_core.InputSignal<string>;
    headerCellDef: _angular_core.Signal<FreyHeaderCellDefDirective>;
    cellDef: _angular_core.Signal<FreyCellDefDirective>;
    sort: _angular_core.Signal<FreyColumnSortDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnDefDirective, "[freyColumnDef]", never, { "columnName": { "alias": "freyColumnDef"; "required": false; "isSignal": true; }; }, {}, ["headerCellDef", "cellDef", "sort"], never, true, never>;
}

interface ClickRowModel {
    name: string;
    data: any;
    rowIndex: number;
}
/**
 * Freya Table Component - A flexible and lightweight data table.
 *
 * Styles are completely optional and must be imported separately.
 * To use the default styles, import:
 * @import 'freya/styles/table/table.scss';
 *
 * @example
 * ```html
 * <!-- Show 10 records per page -->
 * <frey-table [dataSource]="data" [itemsPerPage]="10">
 *   <ng-container freyColumnDef="name">
 *     <th *freyHeaderCellDef>
 *       <span>Name</span>
 *     </th>
 *     <td *freyCellDef="let row">
 *       <div>{{ row.name }}</div>
 *     </td>
 *   </ng-container>
 * </frey-table>
 *
 * <!-- Show all records (no pagination) -->
 * <frey-table [dataSource]="data" [itemsPerPage]="null">
 *   <!-- columns -->
 * </frey-table>
 * ```
 */
declare class FreyTableComponent {
    columnDefs: _angular_core.Signal<readonly FreyColumnDefDirective[]>;
    dataSource: _angular_core.ModelSignal<any[]>;
    searchTerm: _angular_core.ModelSignal<string>;
    itemsPerPage: _angular_core.ModelSignal<number>;
    currentPage: _angular_core.ModelSignal<number>;
    selectable: _angular_core.ModelSignal<boolean>;
    searchResults: _angular_core.OutputEmitterRef<number>;
    clickRow: _angular_core.OutputEmitterRef<ClickRowModel>;
    columns: _angular_core.Signal<{
        name: string;
        headerCellDef: freya.FreyHeaderCellDefDirective;
        cellDef: freya.FreyCellDefDirective;
    }[]>;
    filteredDataBySearch: _angular_core.Signal<any[]>;
    paginatedData: _angular_core.Signal<any[]>;
    selectedRowIndex: _angular_core.WritableSignal<number>;
    selectedRow: _angular_core.WritableSignal<any>;
    private sortState;
    constructor();
    selectRow(columnName: string, row: any, index: number): void;
    isRowSelected(row: any): boolean;
    private onSort;
    private compareValues;
    private compareNumeric;
    private compareString;
    private isNumeric;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyTableComponent, "frey-table", never, { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "searchTerm": { "alias": "searchTerm"; "required": false; "isSignal": true; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; }, { "dataSource": "dataSourceChange"; "searchTerm": "searchTermChange"; "itemsPerPage": "itemsPerPageChange"; "currentPage": "currentPageChange"; "selectable": "selectableChange"; "searchResults": "searchResults"; "clickRow": "clickRow"; }, ["columnDefs"], never, true, never>;
}

export { FreyButtonDirective, FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyControlForm, FreyControlValueAccessor, FreyHeaderCellDefDirective, FreyPaginatorComponent, FreyTableComponent, SubjectState, getRequestAsync, isDefined, isNullOrUndefined, wait };
export type { ButtonColor, ButtonSize, ButtonVariant, ClickRowModel };
