import * as _angular_core from '@angular/core';
import { AfterContentInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
declare class FreyControlForm implements AfterContentInit, OnDestroy {
    formControl: _angular_core.WritableSignal<any>;
    disabled: _angular_core.WritableSignal<boolean>;
    isRequired: _angular_core.Signal<any>;
    isValid: _angular_core.Signal<any>;
    isInvalid: _angular_core.Signal<any>;
    isTouched: _angular_core.Signal<any>;
    errors: _angular_core.Signal<any>;
    private readonly ngControl;
    private readonly subscription;
    constructor();
    ngOnDestroy(): void;
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyControlForm, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyControlForm, never, never, {}, {}, never, never, true, never>;
}

declare class FreyControlValueAccessor implements ControlValueAccessor {
    writeValue(value?: any): void;
    onChange: (value?: any) => void;
    registerOnChange(fn: any): void;
    onTouched: (value?: any) => void;
    registerOnTouched(fn: any): void;
    setDisabledState?(disabled?: boolean): void;
}

declare class SubjectState<T> {
    readonly $observable: Observable<T>;
    private _subject;
    constructor();
    update(value: T): void;
    complete(): void;
    error(error: any): void;
}

declare const wait: (ms: number) => Promise<void>;
declare const getRequestAsync: <T>(request: Observable<T>) => Promise<{
    status: boolean;
    data?: T;
    error?: unknown;
}>;

declare const isNullOrUndefined: (data: any) => boolean;
declare const isDefined: (data: any) => boolean;

declare const isObjectEmpty: (obj: any) => boolean;
declare const getObjectNestedProperty: (obj: any, path: string) => any;

/**
 * Tipo de variante del botón
 */
type ButtonVariant = 'solid' | 'outline' | 'ghost';
/**
 * Color del botón
 */
type ButtonColor = 'primary' | 'secondary' | 'success' | 'danger';
/**
 * Tamaño del botón
 */
type ButtonSize = 'small' | 'medium' | 'large';
/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
declare class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant: ButtonVariant;
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color: ButtonColor;
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size: ButtonSize;
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading: boolean;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled: boolean;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular: boolean;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly: boolean;
    /**
     * Clases computadas para el host
     */
    get hostClasses(): string;
    /**
     * Atributo disabled del botón
     */
    get isDisabled(): true | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyButtonDirective, "[freyButton]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "circular": { "alias": "circular"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; }, {}, never, never, true, never>;
}

export { FreyButtonDirective, FreyControlForm, FreyControlValueAccessor, SubjectState, getObjectNestedProperty, getRequestAsync, isDefined, isNullOrUndefined, isObjectEmpty, wait };
export type { ButtonColor, ButtonSize, ButtonVariant };
