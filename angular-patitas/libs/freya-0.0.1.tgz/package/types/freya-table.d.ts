import * as _angular_core from '@angular/core';
import { TemplateRef, AfterContentInit } from '@angular/core';
import * as freya_table from 'freya/table';

/**
 * Directive to define a cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
declare class FreyCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyCellDefDirective, "[freyCellDef]", never, {}, {}, never, never, true, never>;
}

/**
 * Directive to add sorting functionality to table columns.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef freyColumnSort>
 *     <span>Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
declare class FreyColumnSortDirective implements AfterContentInit {
    freyColumnSort: _angular_core.InputSignal<string | undefined>;
    sortStatus: _angular_core.OutputEmitterRef<boolean>;
    private isArrowUp;
    private readonly elementRef;
    private readonly renderer2;
    ngAfterContentInit(): void;
    private getArrowText;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnSortDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnSortDirective, "[freyColumnSort]", never, { "freyColumnSort": { "alias": "freyColumnSort"; "required": false; "isSignal": true; }; }, { "sortStatus": "sortStatus"; }, never, never, true, never>;
}

/**
 * Directive to define a header cell template in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Column Name</span>
 *   </th>
 * </ng-container>
 * ```
 */
declare class FreyHeaderCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyHeaderCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyHeaderCellDefDirective, "[freyHeaderCellDef]", never, {}, {}, never, never, true, never>;
}

/**
 * Directive to define a column in Freya Table.
 *
 * @example
 * ```html
 * <ng-container freyColumnDef="name">
 *   <th *freyHeaderCellDef>
 *     <span>Name</span>
 *   </th>
 *   <td *freyCellDef="let row">
 *     <div>{{ row.name }}</div>
 *   </td>
 * </ng-container>
 * ```
 */
declare class FreyColumnDefDirective {
    columnName: _angular_core.InputSignal<string | undefined>;
    headerCellDef: _angular_core.Signal<FreyHeaderCellDefDirective | undefined>;
    cellDef: _angular_core.Signal<FreyCellDefDirective | undefined>;
    sort: _angular_core.Signal<FreyColumnSortDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnDefDirective, "[freyColumnDef]", never, { "columnName": { "alias": "freyColumnDef"; "required": false; "isSignal": true; }; }, {}, ["headerCellDef", "cellDef", "sort"], never, true, never>;
}

interface ClickRowModel {
    name: string;
    data: any;
    rowIndex: number;
}
/**
 * Freya Table Component - A flexible and lightweight data table.
 *
 * Styles are completely optional and must be imported separately.
 * To use the default styles, import:
 * @import 'freya/styles/table/table.scss';
 *
 * @example
 * ```html
 * <!-- Show 10 records per page -->
 * <frey-table [dataSource]="data" [itemsPerPage]="10">
 *   <ng-container freyColumnDef="name">
 *     <th *freyHeaderCellDef>
 *       <span>Name</span>
 *     </th>
 *     <td *freyCellDef="let row">
 *       <div>{{ row.name }}</div>
 *     </td>
 *   </ng-container>
 * </frey-table>
 *
 * <!-- Show all records (no pagination) -->
 * <frey-table [dataSource]="data" [itemsPerPage]="null">
 *   <!-- columns -->
 * </frey-table>
 * ```
 */
declare class FreyTableComponent {
    columnDefs: _angular_core.Signal<readonly FreyColumnDefDirective[]>;
    dataSource: _angular_core.ModelSignal<any[]>;
    searchTerm: _angular_core.ModelSignal<string>;
    itemsPerPage: _angular_core.ModelSignal<number | null>;
    currentPage: _angular_core.ModelSignal<number>;
    selectable: _angular_core.ModelSignal<boolean>;
    searchResults: _angular_core.OutputEmitterRef<number>;
    clickRow: _angular_core.OutputEmitterRef<ClickRowModel | null>;
    columns: _angular_core.Signal<{
        name: string | undefined;
        headerCellDef: freya_table.FreyHeaderCellDefDirective | undefined;
        cellDef: freya_table.FreyCellDefDirective | undefined;
    }[]>;
    filteredDataBySearch: _angular_core.Signal<any[]>;
    paginatedData: _angular_core.Signal<any[]>;
    selectedRowIndex: _angular_core.WritableSignal<number | null>;
    selectedRow: _angular_core.WritableSignal<any>;
    private sortState;
    constructor();
    selectRow(columnName: string, row: any, index: number): void;
    isRowSelected(row: any): boolean;
    private onSort;
    private compareValues;
    private compareNumeric;
    private compareString;
    private isNumeric;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyTableComponent, "frey-table", never, { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "searchTerm": { "alias": "searchTerm"; "required": false; "isSignal": true; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; }, { "dataSource": "dataSourceChange"; "searchTerm": "searchTermChange"; "itemsPerPage": "itemsPerPageChange"; "currentPage": "currentPageChange"; "selectable": "selectableChange"; "searchResults": "searchResults"; "clickRow": "clickRow"; }, ["columnDefs"], never, true, never>;
}

export { FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyHeaderCellDefDirective, FreyTableComponent };
export type { ClickRowModel };
