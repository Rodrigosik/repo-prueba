import { HttpInterceptorFn } from '@angular/common/http';
import * as i0 from '@angular/core';
import { WritableSignal } from '@angular/core';

declare const FreyLoaderInterceptor: HttpInterceptorFn;

declare class FreyLoaderService {
    statusLoader: WritableSignal<boolean>;
    loaderChange(statusLoader: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FreyLoaderService>;
}

export { FreyLoaderInterceptor, FreyLoaderService };
