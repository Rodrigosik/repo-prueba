import * as _angular_core from '@angular/core';
import { AfterContentInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

/**
 * Clase base para componentes de formulario de Freya UI.
 *
 * Proporciona acceso signal-based al FormControl y sus propiedades.
 *
 * @example
 * ```typescript
 * export class FreyInputComponent extends FreyControlForm {
 *   isRequired = computed(() => this.formControl()?.hasValidator?.(Validators.required) || false);
 * }
 * ```
 */
declare class FreyControlForm implements AfterContentInit, OnDestroy {
    formControl: _angular_core.WritableSignal<any>;
    disabled: _angular_core.WritableSignal<boolean>;
    isRequired: _angular_core.Signal<any>;
    isValid: _angular_core.Signal<any>;
    isInvalid: _angular_core.Signal<any>;
    isTouched: _angular_core.Signal<any>;
    errors: _angular_core.Signal<any>;
    private readonly ngControl;
    private readonly subscription;
    constructor();
    ngOnDestroy(): void;
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyControlForm, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyControlForm, never, never, {}, {}, never, never, true, never>;
}

declare class FreyControlValueAccessor implements ControlValueAccessor {
    writeValue(value?: any): void;
    onChange: (value?: any) => void;
    registerOnChange(fn: any): void;
    onTouched: (value?: any) => void;
    registerOnTouched(fn: any): void;
    setDisabledState?(disabled?: boolean): void;
}

export { FreyControlForm, FreyControlValueAccessor };
