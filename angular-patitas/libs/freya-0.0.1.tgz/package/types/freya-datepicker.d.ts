import * as i0 from '@angular/core';
import { WritableSignal, Signal, OnDestroy, AfterViewInit, OnChanges, ElementRef, SimpleChanges, EventEmitter } from '@angular/core';
import { FormControl, NgControl } from '@angular/forms';
import { SubjectState, FreyControlValueAccessor } from 'freya/class';
import * as i7 from '@angular/common';

declare class FreyDatePickerService {
    calendarChange$$: SubjectState<Date>;
    inputElement: HTMLInputElement;
    inputElementControl: FormControl;
    startView$$: WritableSignal<'multi-year' | 'default'>;
    statusCalendar$$: WritableSignal<'days' | 'months' | 'years'>;
    calendarfilter: (d: Date | null) => boolean;
    isOpen$$: WritableSignal<boolean>;
    locale$$: WritableSignal<string>;
    minDate: Date;
    maxDate: Date;
    isDateValid: boolean;
    selectedDate$$: WritableSignal<Date>;
    selectedDay$$: Signal<string>;
    selectedMonth$$: WritableSignal<number>;
    selectedYear$$: Signal<number>;
    cacheSelectedDate: Date;
    renderedDays$$: WritableSignal<string[]>;
    renderedYears$$: WritableSignal<number[]>;
    prevSelectedYear$$: WritableSignal<number>;
    prevSelectedMonth$$: WritableSignal<number>;
    prevRenderedDays$$: WritableSignal<string[]>;
    prevRenderedYears$$: WritableSignal<number[]>;
    yearsToRender$$: Signal<number[]>;
    readonly currentYear: number;
    readonly currentMonth: number;
    readonly currentDay: string;
    validSelectedDate(): boolean;
    isInvalidMinMaxDate(date: Date): boolean;
    initDate(startDate?: Date): void;
    clearAuxData(): void;
    isValidDate(inputValue?: string): void;
    generateDaysArray(date: Date): Array<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyDatePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FreyDatePickerService>;
}

declare class DatepickerControlsComponent {
    prevSelectedMonthText$$: Signal<string | null>;
    selectedMonthText$$: Signal<string | null>;
    dateService: FreyDatePickerService;
    configNavigate(): Promise<void>;
    previousOrNext(navigate: 'prev' | 'next'): void;
    private navigateForDays;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerControlsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerControlsComponent, "datepicker-controls", never, {}, {}, never, never, false, never>;
}

declare class DatepickerRenderDaysComponent {
    weekDayLetters$$: Signal<string[]>;
    daysToRendered$$: Signal<string[]>;
    isSelectedDay$$: Signal<(day: string) => any>;
    isCurrentDay$$: Signal<(day: string) => any>;
    isDisabledDay$$: Signal<(day: string) => any>;
    dateService: FreyDatePickerService;
    onSelectedDay(day: string | number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerRenderDaysComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerRenderDaysComponent, "datepicker-render-days", never, {}, {}, never, never, false, never>;
}

declare class MonthList {
    id: number | null;
    name: string | null;
}

declare class DatepickerRenderMonthsComponent {
    renderedMonths$$: Signal<MonthList[]>;
    isSelectedMonth$$: Signal<(monthId: number) => any>;
    isCurrentMonth$$: Signal<(monthId: number) => any>;
    isDisabledMonth$$: Signal<(month: MonthList) => any>;
    dateService: FreyDatePickerService;
    onSelectedMonth(month: MonthList): Promise<void>;
    private isValidMinMaxMonth;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerRenderMonthsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerRenderMonthsComponent, "datepicker-render-months", never, {}, {}, never, never, false, never>;
}

declare class DatepickerRenderYearsComponent {
    dateService: FreyDatePickerService;
    isSelectedYear(year: number): boolean;
    isCurrentYear(year: number): boolean;
    isDisabledYear(year: number): boolean;
    onSelectedYear(year: number): Promise<void>;
    private isValidMinMaxYear;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerRenderYearsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerRenderYearsComponent, "datepicker-render-years", never, {}, {}, never, never, false, never>;
}

declare class FreyDatepickerComponent implements OnDestroy, AfterViewInit, OnChanges {
    calendar: ElementRef;
    startView: 'multi-year' | 'default';
    calendarfilter: (d: Date | null) => boolean;
    positionY$$: WritableSignal<number>;
    positionX$$: WritableSignal<number>;
    positionCalendar$$: Signal<string>;
    isReadonly$$: WritableSignal<boolean>;
    dateService: FreyDatePickerService;
    private observer;
    private removeClickListener;
    private inputListener;
    private keydownListener;
    private readonly renderer;
    private readonly elementRef;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    open(): Promise<void>;
    onWindowScroll(): Promise<void>;
    private setTargetElement;
    private onClick;
    private onInput;
    private onKeyDown;
    private resetControlValue;
    private setPositionCalendar;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyDatepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FreyDatepickerComponent, "frey-datepicker", never, { "startView": { "alias": "startView"; "required": false; }; "calendarfilter": { "alias": "calendarfilter"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FreyDatepickerInputDirective extends FreyControlValueAccessor implements OnChanges, AfterViewInit, OnDestroy {
    locale: string;
    picker: FreyDatepickerComponent;
    calendarChange: EventEmitter<Date>;
    ngControl: NgControl;
    private elementRef;
    private calendarControlAux;
    private subscription;
    get calendarControl(): FormControl;
    get isReadonly(): boolean;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    writeValue(value: Date): void;
    onBlur(event: FocusEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyDatepickerInputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FreyDatepickerInputDirective, "[freyDatepicker]", never, { "locale": { "alias": "locale"; "required": false; }; "picker": { "alias": "freyDatepicker"; "required": false; }; }, { "calendarChange": "calendarChange"; }, never, never, false, never>;
}

declare class FreyDatepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyDatepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FreyDatepickerModule, [typeof FreyDatepickerComponent, typeof DatepickerRenderDaysComponent, typeof DatepickerRenderMonthsComponent, typeof DatepickerRenderYearsComponent, typeof DatepickerControlsComponent, typeof FreyDatepickerInputDirective], [typeof i7.NgClass, typeof i7.AsyncPipe], [typeof FreyDatepickerComponent, typeof FreyDatepickerInputDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FreyDatepickerModule>;
}

export { FreyDatepickerComponent, FreyDatepickerInputDirective, FreyDatepickerModule };
