import * as _angular_core from '@angular/core';
import { OnDestroy } from '@angular/core';

type TooltipPosition = 'top' | 'bottom' | 'left' | 'right' | 'auto';
declare class FreyTooltipDirective implements OnDestroy {
    freyTooltip: _angular_core.InputSignal<string>;
    tooltipPosition: _angular_core.InputSignal<TooltipPosition>;
    private tooltipElement;
    private readonly elementRef;
    private readonly renderer;
    ngOnDestroy(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    private showTooltip;
    private hideTooltip;
    private createTooltipElement;
    private positionTooltip;
    private calculateBestPosition;
    private calculatePosition;
    private adjustPositionIfNeeded;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyTooltipDirective, "[freyTooltip]", never, { "freyTooltip": { "alias": "freyTooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { FreyTooltipDirective };
export type { TooltipPosition };
