import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type InputValidationType = 'number' | 'number:string' | 'name' | 'email' | 'alphanumeric' | 'default';
declare class FreyInputValidationDirective implements ControlValueAccessor {
    freyInputValidation: InputValidationType | string;
    allowSpaces: boolean;
    isUppercase: boolean;
    maxAmount: number;
    spInputValidationChange: EventEmitter<string>;
    private readonly element;
    constructor();
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    handleInputChange(): void;
    onBlur(): void;
    private isValidInput;
    private validaRegex;
    private getRegexString;
    private buildValue;
    private convertToSafeInt;
    private onChange;
    private onTouched;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyInputValidationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FreyInputValidationDirective, "[freyInputValidation]", never, { "freyInputValidation": { "alias": "freyInputValidation"; "required": false; }; "allowSpaces": { "alias": "allowSpaces"; "required": false; }; "isUppercase": { "alias": "isUppercase"; "required": false; }; "maxAmount": { "alias": "maxAmount"; "required": false; }; }, { "spInputValidationChange": "spInputValidationChange"; }, never, never, true, never>;
}

export { FreyInputValidationDirective };
