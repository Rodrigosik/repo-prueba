import { Observable } from 'rxjs';

declare const wait: (ms: number) => Promise<void>;
declare const getRequestAsync: <T>(request: Observable<T>) => Promise<{
    status: boolean;
    data?: T;
    error?: unknown;
}>;

declare const isNullOrUndefined: (data: any) => boolean;
declare const isDefined: (data: any) => boolean;

declare const isObjectEmpty: (obj: any) => boolean;
declare const getObjectNestedProperty: (obj: any, path: string) => any;

export { getObjectNestedProperty, getRequestAsync, isDefined, isNullOrUndefined, isObjectEmpty, wait };
