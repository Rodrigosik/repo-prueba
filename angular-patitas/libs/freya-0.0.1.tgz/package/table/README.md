# Freya Table Component

A lightweight, flexible data table component for Angular.

## Features

- 🔍 **Search/Filter**: Built-in search functionality
- 📄 **Pagination**: Support for paginated data
- 🔄 **Sorting**: Column sorting capabilities
- ✅ **Row Selection**: Optional row selection
- 🎨 **Customizable**: Fully customizable templates
- 📦 **Standalone**: No module imports required
- 🎯 **Signals-based**: Uses Angular's modern signals API

## Installation

```typescript
import { FreyTableComponent } from 'freya/table';
```

## Basic Usage

```html
<frey-table [dataSource]="users" [recordsPerPage]="10">
  <ng-container freyColumnDef="name">
    <th *freyHeaderCellDef>
      <span>Name</span>
    </th>
    <td *freyCellDef="let row">
      <div>{{ row.name }}</div>
    </td>
  </ng-container>

  <ng-container freyColumnDef="email">
    <th *freyHeaderCellDef>
      <span>Email</span>
    </th>
    <td *freyCellDef="let row">
      <div>{{ row.email }}</div>
    </td>
  </ng-container>
</frey-table>
```

## With Sorting

```html
<ng-container freyColumnDef="name">
  <th *freyHeaderCellDef freyColumnSort>
    <span>Name</span>
  </th>
  <td *freyCellDef="let row">
    <div>{{ row.name }}</div>
  </td>
</ng-container>
```

## With Search

```html
<input 
  type="text" 
  [(ngModel)]="searchTerm"
  placeholder="Search..."
/>

<frey-table 
  [dataSource]="users" 
  [searchTerm]="searchTerm"
  [recordsPerPage]="10"
>
  <!-- columns -->
</frey-table>
```

## API

### Inputs

| Input | Type | Default | Description |
|-------|------|---------|-------------|
| `dataSource` | `any[]` | `[]` | Array of data to display |
| `searchTerm` | `string` | `''` | Search/filter term |
| `recordsPerPage` | `number` | `10` | Number of records per page |
| `visiblePage` | `number` | `1` | Current visible page |
| `selectable` | `boolean` | `false` | Enable row selection |

### Outputs

| Output | Type | Description |
|--------|------|-------------|
| `searchResults` | `number` | Emits the count of filtered results |
| `clickRow` | `ClickRowModel \| null` | Emits when a row is clicked (only if selectable=true) |

### ClickRowModel Interface

```typescript
interface ClickRowModel {
  name: string;      // Column name
  data: any;         // Row data
  rowIndex: number;  // Row index
}
```

## Styling

The table component comes with **optional** styles. To use them:

```scss
// In your styles.scss
@import 'freya/styles/table/table.scss';
```

Or add to `angular.json`:

```json
{
  "styles": [
    "node_modules/freya/styles/table/table.scss"
  ]
}
```

## Directives

### `freyColumnDef`

Defines a column in the table. Use with `<ng-container>`.

```html
<ng-container freyColumnDef="columnName">
  <!-- header and cell templates -->
</ng-container>
```

### `freyHeaderCellDef`

Structural directive to define the header cell template for a column.

```html
<th *freyHeaderCellDef>
  <span>Header</span>
</th>
```

### `freyCellDef`

Structural directive to define the cell template for a column.

```html
<td *freyCellDef="let row">
  <div>{{ row.value }}</div>
</td>
```

### `freyColumnSort`

Adds sorting functionality to a column header.

```html
<th *freyHeaderCellDef freyColumnSort>
  <span>Sortable Header</span>
</th>
```

## Complete Example

```html
<frey-table 
  [dataSource]="users" 
  [searchTerm]="searchTerm"
  [recordsPerPage]="10"
  [visiblePage]="currentPage"
  [selectable]="true"
  (searchResults)="onSearchResults($event)"
  (clickRow)="onRowClick($event)"
>
  <ng-container freyColumnDef="id">
    <th *freyHeaderCellDef freyColumnSort>
      <span>ID</span>
    </th>
    <td *freyCellDef="let row">
      <div>{{ row.id }}</div>
    </td>
  </ng-container>

  <ng-container freyColumnDef="name">
    <th *freyHeaderCellDef freyColumnSort>
      <span>Name</span>
    </th>
    <td *freyCellDef="let row">
      <div>{{ row.name }}</div>
    </td>
  </ng-container>

  <ng-container freyColumnDef="email">
    <th *freyHeaderCellDef>
      <span>Email</span>
    </th>
    <td *freyCellDef="let row">
      <div>
        <a [href]="'mailto:' + row.email">{{ row.email }}</a>
      </div>
    </td>
  </ng-container>

  <ng-container freyColumnDef="status">
    <th *freyHeaderCellDef>
      <span>Status</span>
    </th>
    <td *freyCellDef="let row">
      <div>
        <span [class]="'badge-' + row.status">
          {{ row.status }}
        </span>
      </div>
    </td>
  </ng-container>
</frey-table>
```

## Notes

- All directives are **standalone** - no need to import modules
- The component uses **signals** for reactive state management
- Sorting and filtering are computed automatically when inputs change
- Row selection state is managed internally with signals
- The `*` syntax means these are **structural directives** that create templates
