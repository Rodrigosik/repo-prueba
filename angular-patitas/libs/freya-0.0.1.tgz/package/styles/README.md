# Estilos Opcionales de Freya

Esta carpeta contiene los **estilos opcionales** de los componentes/directivas de Freya.

## 🎯 Filosofía

En Freya, los estilos están **completamente separados** de la funcionalidad. Esto te permite:

1. ✅ **Usar los estilos de Freya** - Simplemente impórtalos
2. ✅ **Usar tus propios estilos** - Ignora los nuestros y crea los tuyos
3. ✅ **Mezclar ambos** - Importa los de Freya y sobrescríbelos

## 📦 Cómo importar estilos

### Opción 1: En `angular.json` (Recomendado para toda la app)

```json
{
  "projects": {
    "your-app": {
      "architect": {
        "build": {
          "options": {
            "styles": [
              "src/styles.scss",
              "node_modules/freya/styles/button/button.scss"
            ]
          }
        }
      }
    }
  }
}
```

### Opción 2: En tu `styles.scss` principal

```scss
// Importar todos los componentes de Freya
@import 'freya/styles/button/button.scss';
// Agrega más según los componentes que uses...
```

### Opción 3: Importar solo un componente específico

```scss
// Solo el botón
@import 'freya/styles/button/button.scss';
```

### ✍️ Tipografía

Freya incluye una tipografía global (Poppins) que puedes optar por usar. Al importarla, la fuente se aplicará al `body` de tu aplicación. También se provee la clase `.frey-typography` para aplicar la fuente de forma selectiva.

```scss
// Importar la tipografía global de Freya (Poppins)
@import 'freya/styles/typography/typography.scss';
```

### Opción 4: Sobrescribir estilos de Freya

```scss
// Primero importa los estilos de Freya
@import 'freya/styles/button/button.scss';

// Luego sobrescríbelos
.freya-button {
  border-radius: 4px; // Sobrescribe el border-radius de Freya
  background: blue;   // Sobrescribe el background
}
```

## 📁 Estructura

```
styles/
├── button/
│   └── button.scss          # Estilos del botón
├── input/                   # (futuro)
│   └── input.scss
├── typography/
│   └── typography.scss      # Estilos de tipografía global
└── README.md               # Este archivo
```

## 🎨 Componentes/Estilos disponibles

| Característica/Componente | Archivo de estilos | Clase CSS |
|-------------------------|-------------------|-----------|
| FreyButton              | `button/button.scss` | `.frey-button` |
| **Tipografía Global**   | `typography/typography.scss` | `.frey-typography` (opcional) |

## 💡 Tips


1. **Tree-shaking**: Solo importa los estilos de los componentes que uses
2. **Personalización**: Todas las clases CSS usan el prefijo `frey-` para evitar conflictos
3. **Variables CSS**: Los estilos usan variables CSS cuando es posible para fácil personalización
4. **Sin dependencias**: Los estilos no dependen de frameworks CSS externos

## 📝 Ejemplo completo

```typescript
// app.component.ts
import { Component } from '@angular/core';
import { FreyButtonDirective } from 'freya/button';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FreyButtonDirective],
  template: `
    <button freyaButton label="Click me" (clicked)="handleClick()">
      Click me
    </button>
  `
})
export class AppComponent {
  handleClick(): void {
    console.log('Button clicked!');
  }
}
```

```scss
// styles.scss
@import 'freya/styles/button/button.scss';

// Personaliza si quieres
.frey-button {
  // Tus sobrescritos aquí
}
```

## 🚀 Storybook

Para ver todos los estilos en acción, ejecuta Storybook:

```bash
npm run storybook
```

Cada componente en Storybook muestra:
- ✅ Ejemplos con estilos de Freya
- ✅ Ejemplos sin estilos
- ✅ Ejemplos con estilos personalizados
